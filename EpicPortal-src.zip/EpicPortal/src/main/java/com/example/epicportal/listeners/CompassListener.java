package com.example.epicportal.listeners;

import com.example.epicportal.EpicPortal;
import com.example.epicportal.gui.PortalGUI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public class CompassListener implements Listener {

    private final EpicPortal plugin;
    private final NamespacedKey compassKey;

    public CompassListener(EpicPortal plugin) {
        this.plugin = plugin;
        this.compassKey = new NamespacedKey(plugin, "portal_compass");
    }

    // ── Events ────────────────────────────────────────────────────────────────

    /** เมื่อเข้า server: ถ้าอยู่ใน EPIC world ให้เข็มทิศ */
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (isEpicWorld(player.getWorld())) {
            giveCompassIfMissing(player);
        }
    }

    /** เมื่อเปลี่ยนโลก: ให้/เอาคืนเข็มทิศตามโลก */
    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        if (isEpicWorld(player.getWorld())) {
            giveCompassIfMissing(player);
        } else if (isEpicWorld(event.getFrom())) {
            removePortalCompass(player);
        }
    }

    /** เมื่อ respawn: ถ้า respawn ใน EPIC world ให้เข็มทิศหลัง 2 ticks */
    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (isEpicWorld(event.getRespawnLocation().getWorld())) {
            plugin.getServer().getScheduler()
                    .runTaskLater(plugin, () -> giveCompassIfMissing(player), 2L);
        }
    }

    /** คลิกขวาเข็มทิศพอร์ทัลใน EPIC world → เปิด GUI */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        // รับเฉพาะมือหลัก
        EquipmentSlot hand = event.getHand();
        if (hand == null || hand != EquipmentSlot.HAND) return;

        // รับเฉพาะคลิกขวา
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item == null || item.getType() != Material.COMPASS) return;
        if (!isPortalCompass(item)) return;
        if (!isEpicWorld(player.getWorld())) return;

        event.setCancelled(true);
        // เปิด GUI บน main thread (อยู่ใน main thread อยู่แล้ว แต่ runTask เพื่อความปลอดภัย)
        plugin.getServer().getScheduler().runTask(plugin, () ->
                player.openInventory(new PortalGUI(plugin, player).getInventory()));
    }

    /** เมื่อออก server: นำออกจากคิวอัตโนมัติ */
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        plugin.getQueueManager().removeFromQueue(event.getPlayer().getUniqueId());
    }

    // ── Helper Methods ────────────────────────────────────────────────────────

    private boolean isEpicWorld(World world) {
        if (world == null) return false;
        String epicName = plugin.getConfig().getString("worlds.epic", "EPIC");
        return world.getName().equalsIgnoreCase(epicName);
    }

    /** ให้เข็มทิศถ้ายังไม่มี */
    public void giveCompassIfMissing(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == Material.COMPASS && isPortalCompass(item)) {
                return; // มีแล้ว
            }
        }
        // เข็มทิศอยู่สล็อตแรกของแถบด่วน (slot 0) — ของเดิมในสล็อตนั้นย้ายไปช่องว่าง
        ItemStack old = player.getInventory().getItem(0);
        player.getInventory().setItem(0, createPortalCompass());
        if (old != null) player.getInventory().addItem(old).values()
                .forEach(left -> player.getWorld().dropItemNaturally(player.getLocation(), left));
        player.sendMessage(Component.text("✦ ").color(NamedTextColor.GOLD)
                .append(Component.text("คุณได้รับ").color(NamedTextColor.YELLOW))
                .append(Component.text(" เข็มทิศพอร์ทัล").color(NamedTextColor.GOLD))
                .append(Component.text("! คลิกขวาเพื่อเปิดเมนู").color(NamedTextColor.YELLOW)));
    }

    /** ลบเข็มทิศพอร์ทัลออกจาก inventory */
    public void removePortalCompass(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item != null && item.getType() == Material.COMPASS && isPortalCompass(item)) {
                player.getInventory().setItem(i, null);
            }
        }
    }

    /** สร้างเข็มทิศพอร์ทัลพร้อม PersistentData tag */
    public ItemStack createPortalCompass() {
        ItemStack compass = new ItemStack(Material.COMPASS);
        compass.editMeta(meta -> {
            meta.displayName(
                Component.text("✦ เข็มทิศพอร์ทัล ✦")
                    .color(NamedTextColor.GOLD)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                Component.text("คลิกขวาเพื่อเปิดเมนูพอร์ทัล")
                    .color(NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false),
                Component.text("เฉพาะโลก EPIC เท่านั้น")
                    .color(NamedTextColor.DARK_GRAY)
                    .decoration(TextDecoration.ITALIC, false)
            ));
            // Tag เพื่อระบุว่าเป็นเข็มทิศพอร์ทัล (ไม่ใช่เข็มทิศทั่วไป)
            meta.getPersistentDataContainer()
                    .set(compassKey, PersistentDataType.BOOLEAN, true);
        });
        return compass;
    }

    /** ตรวจสอบว่า ItemStack เป็นเข็มทิศพอร์ทัลหรือไม่ */
    public boolean isPortalCompass(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta()
                .getPersistentDataContainer()
                .has(compassKey, PersistentDataType.BOOLEAN);
    }
}
