package com.example.epicportal.listeners;

import com.example.epicportal.EpicPortal;
import com.example.epicportal.gui.PortalGUI;
import com.example.epicportal.managers.QueueManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public class GUIListener implements Listener {

    private final EpicPortal plugin;

    public GUIListener(EpicPortal plugin) {
        this.plugin = plugin;
    }

    /** จัดการการคลิก slot ใน Portal GUI */
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        // ตรวจสอบว่าเปิด Portal GUI อยู่
        if (!(event.getInventory().getHolder() instanceof PortalGUI)) return;

        // ยกเลิกเสมอ (ป้องกันการหยิบ item)
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;

        // ถ้าคลิก inventory ของผู้เล่นเอง (ส่วนล่าง) ให้ข้าม
        if (event.getClickedInventory() == null) return;
        if (!event.getClickedInventory().equals(event.getInventory())) return;

        int slot = event.getSlot();
        QueueManager qm = plugin.getQueueManager();
        boolean inQueue = qm.isInQueue(player.getUniqueId());

        if (slot == PortalGUI.SLOT_GRASS) {
            handleGrassClick(player, qm, inQueue, event.isRightClick());
            player.closeInventory();

        } else if (slot == PortalGUI.SLOT_SWORD) {
            // ดาบ → วาปเข้าโลก LP ทันที
            player.closeInventory();
            plugin.getSwordListener().teleportToLp(player);

        } else if (slot == PortalGUI.SLOT_ACTION && inQueue) {
            // BARRIER button → ออกจากคิว
            leaveQueue(player, qm);
            player.closeInventory();
        }
    }

    /** ป้องกันการลากของเข้า Portal GUI */
    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getInventory().getHolder() instanceof PortalGUI)) return;
        event.setCancelled(true);
    }

    // ── Handlers ─────────────────────────────────────────────────────────────

    private void handleGrassClick(Player player, QueueManager qm, boolean inQueue, boolean isRightClick) {
        if (inQueue) {
            // คลิกขวาบนหญ้าขณะอยู่ในคิว = ออกจากคิว
            if (isRightClick) leaveQueue(player, qm);
            // คลิกซ้ายขณะอยู่ในคิว = แจ้งตำแหน่ง
            else {
                int pos = qm.getPosition(player.getUniqueId());
                player.sendMessage(Component.text("⏳ คุณอยู่ในคิว ตำแหน่ง: ").color(NamedTextColor.YELLOW)
                        .append(Component.text("#" + pos + " / " + qm.getQueueSize(player.getUniqueId()))
                                .color(NamedTextColor.WHITE)));
            }
        } else {
            // ยังไม่ได้อยู่ในคิว = เข้าคิว
            joinQueue(player, qm);
        }
    }

    private void joinQueue(Player player, QueueManager qm) {
        if (qm.addToQueue(player)) {
            int pos = qm.getPosition(player.getUniqueId());
            int total = qm.getQueueSize(player.getUniqueId());
            player.sendMessage(
                Component.text("✔ เข้าคิวสำเร็จ! ตำแหน่ง: ").color(NamedTextColor.GREEN)
                    .append(Component.text("#" + pos + " / " + total).color(NamedTextColor.YELLOW)));
            player.sendMessage(
                Component.text("พิมพ์ ").color(NamedTextColor.GRAY)
                    .append(Component.text("/queueleave").color(NamedTextColor.WHITE))
                    .append(Component.text(" เพื่อออกจากคิว").color(NamedTextColor.GRAY)));
        } else {
            // กรณีที่เข้ามาในคิวแล้ว (ไม่ควรเกิดจาก GUI ปกติ)
            int pos = qm.getPosition(player.getUniqueId());
            player.sendMessage(Component.text("! คุณอยู่ในคิวแล้ว ตำแหน่ง: #" + pos)
                    .color(NamedTextColor.YELLOW));
        }
    }

    private void leaveQueue(Player player, QueueManager qm) {
        if (qm.removeFromQueue(player.getUniqueId())) {
            player.sendMessage(Component.text("✘ คุณออกจากคิวแล้ว").color(NamedTextColor.RED));
        }
    }
}
