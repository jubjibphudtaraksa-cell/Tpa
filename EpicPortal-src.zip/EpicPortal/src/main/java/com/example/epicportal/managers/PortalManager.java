package com.example.epicportal.managers;

import com.example.epicportal.EpicPortal;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;

/**
 * วาปผู้เล่นไปยังโลกปลายทางทันที (ไม่มีระบบคิว)
 * "smp" -> โลก SMP, "lp" -> โลก LP (PVP)
 */
public class PortalManager {

    public static final String TARGET_SMP = "smp";
    public static final String TARGET_LP  = "lp";

    private final EpicPortal plugin;

    public PortalManager(EpicPortal plugin) {
        this.plugin = plugin;
    }

    /** วาปผู้เล่นไปปลายทางที่ระบุ — คืนค่า true ถ้าวาปสำเร็จ */
    public boolean teleport(Player player, String target) {
        String label = getDisplayName(target);
        String worldName = getWorldName(target);

        if (player.getWorld().getName().equalsIgnoreCase(worldName)) {
            player.sendMessage(Component.text("✔ คุณอยู่ในโลก " + label + " แล้ว!").color(NamedTextColor.GREEN));
            return false;
        }

        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            player.sendMessage(Component.text("✘ ไม่พบโลก " + label + " (" + worldName + ")").color(NamedTextColor.RED));
            return false;
        }

        player.closeInventory();
        player.sendMessage(Component.text("✈ กำลังพาคุณไปยังโลก " + label + "...").color(NamedTextColor.GREEN));
        player.teleport(world.getSpawnLocation());
        return true;
    }

    public String getWorldName(String target) {
        return plugin.getConfig().getString("worlds." + target,
                TARGET_LP.equals(target) ? "lp" : "world");
    }

    public String getDisplayName(String target) {
        return TARGET_LP.equals(target) ? "PVP" : "SMP";
    }
}
