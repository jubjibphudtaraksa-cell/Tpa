package com.example.epicportal.listeners;

import com.example.epicportal.EpicPortal;
import com.example.epicportal.managers.QueueManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;

/**
 * บอท (NPC) ที่มีชื่อลอยเหนือหัว
 *  - SMP → กดแล้วเข้าคิวโลก SMP
 *  - PVP → กดแล้วเข้าคิวโลก LP
 * NPC เก็บ tag ใน PersistentData ของ entity จึงอยู่ถาวรหลังรีสตาร์ทเซิร์ฟเวอร์
 */
public class NpcListener implements Listener {

    private final EpicPortal plugin;
    private final NamespacedKey npcKey;

    public NpcListener(EpicPortal plugin) {
        this.plugin = plugin;
        this.npcKey = new NamespacedKey(plugin, "portal_npc");
    }

    // ── Spawn / lookup ───────────────────────────────────────────────────────

    public Villager spawnNpc(Location loc, String target) {
        boolean lp = QueueManager.TARGET_LP.equals(target);
        String title = lp ? "PVP" : "SMP";
        NamedTextColor color = lp ? NamedTextColor.RED : NamedTextColor.GREEN;

        return loc.getWorld().spawn(loc, Villager.class, v -> {
            v.customName(Component.text(title).color(color)
                    .decoration(TextDecoration.BOLD, true)
                    .decoration(TextDecoration.ITALIC, false));
            v.setCustomNameVisible(true);
            v.setAI(false);
            v.setInvulnerable(true);
            v.setSilent(true);
            v.setCollidable(false);
            v.setPersistent(true);
            v.setRemoveWhenFarAway(false);
            v.setProfession(Villager.Profession.NONE);
            v.getPersistentDataContainer().set(npcKey, PersistentDataType.STRING, target);
        });
    }

    public String getNpcTarget(Entity entity) {
        if (entity == null) return null;
        return entity.getPersistentDataContainer().get(npcKey, PersistentDataType.STRING);
    }

    // ── Events ────────────────────────────────────────────────────────────────

    /** คลิกขวาที่บอท */
    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEntityEvent event) {
        String target = getNpcTarget(event.getRightClicked());
        if (target == null) return;
        event.setCancelled(true); // กันเปิดหน้าต่างเทรด
        if (event.getHand() != EquipmentSlot.HAND) return;
        handleClick(event.getPlayer(), target);
    }

    /** ตีบอท = กดเหมือนกัน (ไม่ทำดาเมจ) */
    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent event) {
        String target = getNpcTarget(event.getEntity());
        if (target == null) return;
        event.setCancelled(true);
        if (event instanceof EntityDamageByEntityEvent byEntity
                && byEntity.getDamager() instanceof Player player) {
            handleClick(player, target);
        }
    }

    // ── Logic ─────────────────────────────────────────────────────────────────

    private void handleClick(Player player, String target) {
        QueueManager qm = plugin.getQueueManager();
        String label = qm.getDisplayName(target);
        String worldName = qm.getWorldName(target);

        if (player.getWorld().getName().equalsIgnoreCase(worldName)) {
            player.sendMessage(Component.text("✔ คุณอยู่ในโลก " + label + " แล้ว!").color(NamedTextColor.GREEN));
            return;
        }

        if (qm.isInQueue(player.getUniqueId())) {
            int pos = qm.getPosition(player.getUniqueId());
            player.sendMessage(Component.text("! คุณอยู่ในคิวแล้ว ตำแหน่ง: ").color(NamedTextColor.YELLOW)
                    .append(Component.text("#" + pos + " / " + qm.getQueueSize(player.getUniqueId()))
                            .color(NamedTextColor.WHITE)));
            player.sendMessage(Component.text("พิมพ์ ").color(NamedTextColor.GRAY)
                    .append(Component.text("/queueleave").color(NamedTextColor.WHITE))
                    .append(Component.text(" เพื่อออกจากคิว").color(NamedTextColor.GRAY)));
            return;
        }

        if (qm.addToQueue(player, target)) {
            player.sendMessage(Component.text("✔ เข้าคิว " + label + " สำเร็จ! ตำแหน่ง: ").color(NamedTextColor.GREEN)
                    .append(Component.text("#" + qm.getPosition(player.getUniqueId())
                            + " / " + qm.getQueueSize(target)).color(NamedTextColor.YELLOW)));
            player.sendMessage(Component.text("พิมพ์ ").color(NamedTextColor.GRAY)
                    .append(Component.text("/queueleave").color(NamedTextColor.WHITE))
                    .append(Component.text(" เพื่อออกจากคิว").color(NamedTextColor.GRAY)));
        }
    }
}
