package com.example.epicportal.listeners;

import com.example.epicportal.EpicPortal;
import com.example.epicportal.managers.QueueManager;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.event.NPCLeftClickEvent;
import net.citizensnpcs.api.event.NPCRightClickEvent;
import net.citizensnpcs.api.npc.NPC;
import net.citizensnpcs.trait.LookClose;
import net.citizensnpcs.trait.SkinTrait;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

/**
 * บอทเป็นผู้เล่นจริง (ผ่านปลั๊กอิน Citizens) มีชื่อลอยเหนือหัว
 *  - SMP → กดแล้วเข้าคิวโลก SMP
 *  - PVP → กดแล้วเข้าคิวโลก LP
 * Citizens เก็บ NPC ไว้ให้เอง จึงอยู่ถาวรหลังรีสตาร์ท
 */
public class NpcListener implements Listener {

    private static final String DATA_KEY = "epicportal_target";

    private final EpicPortal plugin;

    public NpcListener(EpicPortal plugin) {
        this.plugin = plugin;
    }

    // ── Spawn / remove ───────────────────────────────────────────────────────

    public NPC spawnNpc(Location loc, String target) {
        boolean lp = QueueManager.TARGET_LP.equals(target);
        String name = lp ? "\u00a7c\u00a7lPVP" : "\u00a7a\u00a7lSMP";
        String skin = plugin.getConfig().getString("npc.skins." + target, lp ? "jeb_" : "Notch");

        NPC npc = CitizensAPI.getNPCRegistry().createNPC(EntityType.PLAYER, name);
        npc.data().setPersistent(DATA_KEY, target);
        npc.getOrAddTrait(SkinTrait.class).setSkinName(skin);
        npc.getOrAddTrait(LookClose.class).lookClose(true);   // หันมองผู้เล่นที่เข้าใกล้
        npc.setProtected(true);                                // ไม่โดนทำร้าย
        npc.spawn(loc);
        return npc;
    }

    /** ลบบอทของ EpicPortal ในรัศมี 3 บล็อก — คืนจำนวนที่ลบ */
    public int removeNearby(Player player) {
        int count = 0;
        for (Entity e : player.getNearbyEntities(3, 3, 3)) {
            NPC npc = CitizensAPI.getNPCRegistry().getNPC(e);
            if (npc != null && getTarget(npc) != null) {
                npc.destroy();
                count++;
            }
        }
        return count;
    }

    private String getTarget(NPC npc) {
        if (npc == null || !npc.data().has(DATA_KEY)) return null;
        Object v = npc.data().get(DATA_KEY);
        return v == null ? null : v.toString();
    }

    // ── Events ────────────────────────────────────────────────────────────────

    @EventHandler
    public void onRightClick(NPCRightClickEvent event) {
        String target = getTarget(event.getNPC());
        if (target != null) handleClick(event.getClicker(), target);
    }

    @EventHandler
    public void onLeftClick(NPCLeftClickEvent event) {
        String target = getTarget(event.getNPC());
        if (target != null) handleClick(event.getClicker(), target);
    }

    // ── Logic ─────────────────────────────────────────────────────────────────

    private void handleClick(Player player, String target) {
        QueueManager qm = plugin.getQueueManager();
        String label = qm.getDisplayName(target);
        String worldName = qm.getWorldName(target);

        if (player.getWorld().getName().equalsIgnoreCase(worldName)) {
            player.sendMessage(Component.text("\u2714 \u0e04\u0e38\u0e13\u0e2d\u0e22\u0e39\u0e48\u0e43\u0e19\u0e42\u0e25\u0e01 " + label + " \u0e41\u0e25\u0e49\u0e27!").color(NamedTextColor.GREEN));
            return;
        }

        if (qm.isInQueue(player.getUniqueId())) {
            int pos = qm.getPosition(player.getUniqueId());
            player.sendMessage(Component.text("! \u0e04\u0e38\u0e13\u0e2d\u0e22\u0e39\u0e48\u0e43\u0e19\u0e04\u0e34\u0e27\u0e41\u0e25\u0e49\u0e27 \u0e15\u0e33\u0e41\u0e2b\u0e19\u0e48\u0e07: ").color(NamedTextColor.YELLOW)
                    .append(Component.text("#" + pos + " / " + qm.getQueueSize(player.getUniqueId()))
                            .color(NamedTextColor.WHITE)));
            player.sendMessage(Component.text("\u0e1e\u0e34\u0e21\u0e1e\u0e4c ").color(NamedTextColor.GRAY)
                    .append(Component.text("/queueleave").color(NamedTextColor.WHITE))
                    .append(Component.text(" \u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e2d\u0e2d\u0e01\u0e08\u0e32\u0e01\u0e04\u0e34\u0e27").color(NamedTextColor.GRAY)));
            return;
        }

        if (qm.addToQueue(player, target)) {
            player.sendMessage(Component.text("\u2714 \u0e40\u0e02\u0e49\u0e32\u0e04\u0e34\u0e27 " + label + " \u0e2a\u0e33\u0e40\u0e23\u0e47\u0e08! \u0e15\u0e33\u0e41\u0e2b\u0e19\u0e48\u0e07: ").color(NamedTextColor.GREEN)
                    .append(Component.text("#" + qm.getPosition(player.getUniqueId())
                            + " / " + qm.getQueueSize(target)).color(NamedTextColor.YELLOW)));
            player.sendMessage(Component.text("\u0e1e\u0e34\u0e21\u0e1e\u0e4c ").color(NamedTextColor.GRAY)
                    .append(Component.text("/queueleave").color(NamedTextColor.WHITE))
                    .append(Component.text(" \u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e2d\u0e2d\u0e01\u0e08\u0e32\u0e01\u0e04\u0e34\u0e27").color(NamedTextColor.GRAY)));
        }
    }
}
