package com.example.epicportal.managers;

import com.example.epicportal.EpicPortal;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.UUID;

/**
 * ระบบคิวแยกตามปลายทาง: "smp" -> โลก SMP, "lp" -> โลก LP (PVP)
 * ผู้เล่นอยู่ได้ทีละคิวเท่านั้น
 */
public class QueueManager {

    public static final String TARGET_SMP = "smp";
    public static final String TARGET_LP  = "lp";

    private final EpicPortal plugin;
    private final Map<String, LinkedList<QueueEntry>> queues = new LinkedHashMap<>();
    private BukkitTask queueTask;
    private BukkitTask actionBarTask;

    public QueueManager(EpicPortal plugin) {
        this.plugin = plugin;
        queues.put(TARGET_SMP, new LinkedList<>());
        queues.put(TARGET_LP, new LinkedList<>());
    }

    // ── Public API ──────────────────────────────────────────────────────────

    /** เพิ่มผู้เล่นเข้าคิว SMP (ใช้กับ GUI เข็มทิศ) */
    public boolean addToQueue(Player player) {
        return addToQueue(player, TARGET_SMP);
    }

    /** เพิ่มผู้เล่นเข้าคิวปลายทางที่ระบุ — คืนค่า false ถ้าอยู่ในคิวใดคิวหนึ่งแล้ว */
    public boolean addToQueue(Player player, String target) {
        LinkedList<QueueEntry> q = queues.get(target);
        if (q == null || isInQueue(player.getUniqueId())) return false;
        q.add(new QueueEntry(player.getUniqueId(), player.getName(), target));
        notifyAll(q, player, true);
        return true;
    }

    /** นำผู้เล่นออกจากคิว — คืนค่า true ถ้าเอาออกได้ */
    public boolean removeFromQueue(UUID uuid) {
        for (LinkedList<QueueEntry> q : queues.values()) {
            if (q.removeIf(e -> e.getPlayerUUID().equals(uuid))) {
                notifyAll(q, null, false);
                return true;
            }
        }
        return false;
    }

    public boolean isInQueue(UUID uuid) {
        return getTarget(uuid) != null;
    }

    /** คืนค่าปลายทางของคิวที่ผู้เล่นอยู่ หรือ null */
    public String getTarget(UUID uuid) {
        for (Map.Entry<String, LinkedList<QueueEntry>> en : queues.entrySet()) {
            for (QueueEntry e : en.getValue()) {
                if (e.getPlayerUUID().equals(uuid)) return en.getKey();
            }
        }
        return null;
    }

    /** คืนค่าตำแหน่งในคิว (1-based) หรือ -1 ถ้าไม่ได้อยู่ในคิว */
    public int getPosition(UUID uuid) {
        for (LinkedList<QueueEntry> q : queues.values()) {
            int pos = 1;
            for (QueueEntry entry : q) {
                if (entry.getPlayerUUID().equals(uuid)) return pos;
                pos++;
            }
        }
        return -1;
    }

    /** ขนาดคิวของปลายทางที่ระบุ */
    public int getQueueSize(String target) {
        LinkedList<QueueEntry> q = queues.get(target);
        return q == null ? 0 : q.size();
    }

    /** ขนาดคิวที่ผู้เล่นคนนั้นอยู่ (0 ถ้าไม่ได้อยู่ในคิว) */
    public int getQueueSize(UUID uuid) {
        String t = getTarget(uuid);
        return t == null ? 0 : getQueueSize(t);
    }

    public String getWorldName(String target) {
        return plugin.getConfig().getString("worlds." + target,
                TARGET_LP.equals(target) ? "lp" : "world");
    }

    public String getDisplayName(String target) {
        return TARGET_LP.equals(target) ? "PVP" : "SMP";
    }

    // ── Task Management ─────────────────────────────────────────────────────

    public void startTask() {
        int interval = plugin.getConfig().getInt("queue.process-interval", 60);
        queueTask = Bukkit.getScheduler().runTaskTimer(plugin, this::processQueues, interval, interval);
        actionBarTask = Bukkit.getScheduler().runTaskTimer(plugin, this::updateActionBars, 40L, 40L);
    }

    public void stopTask() {
        if (queueTask != null && !queueTask.isCancelled()) queueTask.cancel();
        if (actionBarTask != null && !actionBarTask.isCancelled()) actionBarTask.cancel();
    }

    // ── Private Queue Processing ─────────────────────────────────────────────

    private void processQueues() {
        for (Map.Entry<String, LinkedList<QueueEntry>> en : queues.entrySet()) {
            processQueue(en.getKey(), en.getValue());
        }
    }

    private void processQueue(String target, LinkedList<QueueEntry> queue) {
        queue.removeIf(e -> Bukkit.getPlayer(e.getPlayerUUID()) == null);
        if (queue.isEmpty()) return;

        QueueEntry entry = queue.peek();
        Player player = Bukkit.getPlayer(entry.getPlayerUUID());
        if (player == null) {
            queue.poll();
            notifyAll(queue, null, false);
            return;
        }

        String label = getDisplayName(target);
        String worldName = getWorldName(target);
        int maxAttempts = plugin.getConfig().getInt("queue.max-attempts", 5);
        World world = Bukkit.getWorld(worldName);

        // ── โลกปลายทางยังไม่โหลด ──
        if (world == null) {
            entry.incrementAttempts();
            player.sendMessage(Component.text("⚠ ไม่พบโลก " + label + " — กำลังลองใหม่ (ความพยายาม: ")
                    .color(NamedTextColor.YELLOW)
                    .append(Component.text(entry.getAttempts() + "/" + maxAttempts)
                            .color(NamedTextColor.RED))
                    .append(Component.text(")").color(NamedTextColor.YELLOW)));

            if (entry.getAttempts() >= maxAttempts) {
                queue.poll();
                player.sendMessage(Component.text("✘ ไม่สามารถเข้าโลก " + label + " ได้หลังจาก ")
                        .color(NamedTextColor.RED)
                        .append(Component.text(maxAttempts + " ความพยายาม").color(NamedTextColor.YELLOW))
                        .append(Component.text(" — ถูกนำออกจากคิว").color(NamedTextColor.RED)));
                notifyAll(queue, null, false);
            }
            return;
        }

        // ── อยู่ในโลกปลายทางแล้ว ──
        if (player.getWorld().getName().equalsIgnoreCase(worldName)) {
            queue.poll();
            player.sendMessage(Component.text("✔ คุณอยู่ในโลก " + label + " แล้ว!").color(NamedTextColor.GREEN));
            notifyAll(queue, null, false);
            return;
        }

        // ── Teleport! ──
        queue.poll();
        player.closeInventory();
        player.sendMessage(Component.text("✈ กำลังพาคุณไปยังโลก " + label + "...").color(NamedTextColor.GREEN));
        player.teleport(world.getSpawnLocation());
        notifyAll(queue, null, false);
    }

    private void notifyAll(LinkedList<QueueEntry> queue, Player joiner, boolean joining) {
        int pos = 1;
        int total = queue.size();
        for (QueueEntry entry : queue) {
            Player p = Bukkit.getPlayer(entry.getPlayerUUID());
            if (p == null) { pos++; continue; }
            if (joining && p.equals(joiner)) { pos++; continue; }
            p.sendMessage(Component.text("↕ ตำแหน่งคิวของคุณ: ").color(NamedTextColor.GRAY)
                    .append(Component.text("#" + pos + " / " + total).color(NamedTextColor.YELLOW)));
            pos++;
        }
    }

    private void updateActionBars() {
        int maxAttempts = plugin.getConfig().getInt("queue.max-attempts", 5);
        for (Map.Entry<String, LinkedList<QueueEntry>> en : queues.entrySet()) {
            LinkedList<QueueEntry> queue = en.getValue();
            if (queue.isEmpty()) continue;
            String label = getDisplayName(en.getKey());
            int pos = 1;
            int total = queue.size();
            for (QueueEntry entry : queue) {
                Player p = Bukkit.getPlayer(entry.getPlayerUUID());
                if (p == null) { pos++; continue; }
                boolean hasAttempts = entry.getAttempts() > 0;
                p.sendActionBar(
                    Component.text("⏳ คิว " + label + ": ").color(NamedTextColor.YELLOW)
                        .append(Component.text("#" + pos + "/" + total).color(NamedTextColor.WHITE))
                        .append(Component.text("  |  ความพยายาม: ").color(NamedTextColor.GRAY))
                        .append(Component.text(entry.getAttempts() + "/" + maxAttempts)
                                .color(hasAttempts ? NamedTextColor.RED : NamedTextColor.GREEN))
                );
                pos++;
            }
        }
    }
}
