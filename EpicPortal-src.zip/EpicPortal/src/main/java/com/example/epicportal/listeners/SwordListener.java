package com.example.epicportal.listeners;

import com.example.epicportal.EpicPortal;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/** ดาบวาป: คลิกขวาใน EPIC world → วาปเข้าโลก lp ทันที */
public class SwordListener implements Listener {

    private final EpicPortal plugin;
    private final NamespacedKey swordKey;

    public SwordListener(EpicPortal plugin) {
        this.plugin = plugin;
        this.swordKey = new NamespacedKey(plugin, "portal_sword");
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (isEpicWorld(player.getWorld())) giveSwordIfMissing(player);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        if (isEpicWorld(player.getWorld())) {
            giveSwordIfMissing(player);
        } else if (isEpicWorld(event.getFrom())) {
            removeSword(player);
        }
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (isEpicWorld(event.getRespawnLocation().getWorld())) {
            plugin.getServer().getScheduler()
                    .runTaskLater(plugin, () -> giveSwordIfMissing(player), 2L);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (!isPortalSword(item)) return;
        if (!isEpicWorld(player.getWorld())) return;

        event.setCancelled(true);

        String lpName = plugin.getQueueManager().getWorldName("lp");
        World lp = plugin.getServer().getWorld(lpName);
        if (lp == null) {
            player.sendMessage(Component.text("✘ ไม่พบโลก " + lpName).color(NamedTextColor.RED));
            return;
        }
        plugin.getQueueManager().removeFromQueue(player.getUniqueId());
        player.sendMessage(Component.text("⚔ กำลังวาปเข้าโลก LP...").color(NamedTextColor.RED));
        player.teleport(lp.getSpawnLocation());
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private boolean isEpicWorld(World world) {
        if (world == null) return false;
        return world.getName().equalsIgnoreCase(plugin.getConfig().getString("worlds.epic", "EPIC"));
    }

    public void giveSwordIfMissing(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (isPortalSword(item)) return;
        }
        // ดาบอยู่สล็อตที่สองของแถบด่วน (slot 1) — ของเดิมในสล็อตนั้นย้ายไปช่องว่าง
        ItemStack old = player.getInventory().getItem(1);
        player.getInventory().setItem(1, createPortalSword());
        if (old != null) player.getInventory().addItem(old).values()
                .forEach(left -> player.getWorld().dropItemNaturally(player.getLocation(), left));
        player.sendMessage(Component.text("⚔ คุณได้รับ ").color(NamedTextColor.YELLOW)
                .append(Component.text("ดาบวาป").color(NamedTextColor.RED))
                .append(Component.text("! คลิกขวาเพื่อเข้าโลก LP").color(NamedTextColor.YELLOW)));
    }

    public void removeSword(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isPortalSword(contents[i])) player.getInventory().setItem(i, null);
        }
    }

    public ItemStack createPortalSword() {
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        sword.editMeta(meta -> {
            meta.displayName(Component.text("⚔ ดาบวาป LP ⚔")
                    .color(NamedTextColor.RED)
                    .decoration(TextDecoration.BOLD, true)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                    Component.text("คลิกขวาเพื่อวาปเข้าโลก LP")
                            .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                    Component.text("เฉพาะโลก EPIC เท่านั้น")
                            .color(NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)));
            meta.setUnbreakable(true);
            meta.getPersistentDataContainer().set(swordKey, PersistentDataType.BOOLEAN, true);
        });
        return sword;
    }

    public boolean isPortalSword(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_SWORD || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(swordKey, PersistentDataType.BOOLEAN);
    }
}
