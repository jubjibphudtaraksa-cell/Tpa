package com.example.epicportal.listeners;

import com.example.epicportal.EpicPortal;
import org.bukkit.GameRule;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

/**
 * โลกที่ป้องกัน (config: protected-worlds, ค่าเริ่มต้น lp):
 * เลือดไม่ลด / หลอดอาหารไม่ลด / ตีไม่ได้ / ทุบ-วางบล็อกไม่ได้ / เป็นเวลาเช้าตลอด
 * มีแค่เข็มทิศในตัว — ยกเว้น OP
 */
public class ProtectionListener implements Listener {

    private final EpicPortal plugin;

    public ProtectionListener(EpicPortal plugin) {
        this.plugin = plugin;
    }

    // ── Setup (เรียกตอน onEnable) ─────────────────────────────────────────────

    public void start() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, this::keepMorning, 20L, 100L);
    }

    private void keepMorning() {
        for (World w : plugin.getServer().getWorlds()) {
            if (!isProtected(w)) continue;
            w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            w.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
            w.setTime(1000L);
            w.setStorm(false);
            w.setThundering(false);
        }
    }

    public boolean isProtected(World world) {
        if (world == null) return false;
        return plugin.getConfig().getStringList("protected-worlds").stream()
                .anyMatch(n -> n.equalsIgnoreCase(world.getName()));
    }

    private boolean applies(Player player) {
        return isProtected(player.getWorld()) && !player.isOp();
    }

    // ── Damage / Hunger / Combat ──────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player p && applies(p)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHit(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player p && applies(p)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHunger(FoodLevelChangeEvent event) {
        if (event.getEntity() instanceof Player p && applies(p)) {
            event.setCancelled(true);
            p.setFoodLevel(20);
        }
    }

    // ── Blocks ────────────────────────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent event) {
        if (applies(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent event) {
        if (applies(event.getPlayer())) event.setCancelled(true);
    }

    // ── เข้าโลกป้องกัน: เหลือแค่เข็มทิศ ───────────────────────────────────────

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        prepare(event.getPlayer());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        prepare(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (isProtected(event.getRespawnLocation().getWorld())) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> prepare(player), 2L);
        }
    }

    private void prepare(Player player) {
        if (!applies(player)) return;
        player.setHealth(player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue());
        player.setFoodLevel(20);
        player.getInventory().clear();
        player.getInventory().setItem(0, plugin.getCompassListener().createPortalCompass());
    }
}
