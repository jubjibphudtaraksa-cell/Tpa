package com.example.epicportal.gui;

import com.example.epicportal.EpicPortal;
import com.example.epicportal.managers.QueueManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * GUI 54-slot (6 แถว) ที่แสดงบล็อกหญ้าตรงกลาง
 *
 * Layout (slot index):
 *  Row 1 [ 0- 8]: border (gray glass)
 *  Row 2 [ 9-17]: col 0,8 = border | col 1-7 = black glass
 *  Row 3 [18-26]: col 0,8 = border | 20=info | 22=GRASS | 24=SWORD | 31=action | rest = black glass
 *  Row 4 [27-35]: col 0,8 = border | col 1-7 = black glass
 *  Row 5 [36-44]: col 0,8 = border | col 1-7 = black glass
 *  Row 6 [45-53]: border (gray glass)
 */
public class PortalGUI implements InventoryHolder {

    // Slot constants
    public static final int SLOT_INFO   = 20;   // แสดงข้อมูล SMP / สถานะคิว
    public static final int SLOT_GRASS  = 22;   // บล็อกหญ้า (ตรงกลาง)
    public static final int SLOT_SWORD  = 24;   // ดาบ (วาปเข้าโลก LP ทันที)
    public static final int SLOT_ACTION = 31;   // ออกจากคิว (เมื่ออยู่ในคิว)

    private final Inventory inventory;
    private final EpicPortal plugin;

    public PortalGUI(EpicPortal plugin, Player player) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, 54,
                Component.text("✦ Gateway — โลก SMP ✦")
                        .color(NamedTextColor.GOLD)
                        .decoration(TextDecoration.ITALIC, false));
        build(player);
    }

    // ── Build ────────────────────────────────────────────────────────────────

    private void build(Player player) {
        QueueManager qm = plugin.getQueueManager();
        boolean inQueue = qm.isInQueue(player.getUniqueId());
        int pos   = inQueue ? qm.getPosition(player.getUniqueId()) : -1;
        int total = inQueue ? qm.getQueueSize(player.getUniqueId()) : qm.getQueueSize(QueueManager.TARGET_SMP);

        // 1. ใส่ black glass ทั้งหมด
        ItemStack black = pane(Material.BLACK_STAINED_GLASS_PANE);
        for (int i = 0; i < 54; i++) inventory.setItem(i, black);

        // 2. ขอบ gray glass (row 1, row 6, col 0, col 8)
        ItemStack gray = pane(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < 9; i++)  inventory.setItem(i, gray);        // Row 1
        for (int i = 45; i < 54; i++) inventory.setItem(i, gray);       // Row 6
        for (int r = 1; r <= 4; r++) {
            inventory.setItem(r * 9,     gray);   // Col 0 (left border)
            inventory.setItem(r * 9 + 8, gray);   // Col 8 (right border)
        }

        // 3. Items กลาง
        inventory.setItem(SLOT_GRASS,  buildGrassItem(inQueue, pos, total));
        inventory.setItem(SLOT_INFO,   buildInfoItem(inQueue, pos, total));
        inventory.setItem(SLOT_SWORD,  plugin.getSwordListener().createPortalSword());
        inventory.setItem(SLOT_ACTION, buildActionItem(inQueue));
    }

    // ── Item Builders ─────────────────────────────────────────────────────────

    private ItemStack buildGrassItem(boolean inQueue, int pos, int total) {
        ItemStack item = new ItemStack(Material.GRASS_BLOCK);
        item.editMeta(meta -> {
            if (inQueue) {
                meta.displayName(
                    Component.text("✦ อยู่ในคิว — ตำแหน่ง #" + pos + " ✦")
                        .color(NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false));
                meta.lore(List.of(
                    Component.empty(),
                    Component.text("ตำแหน่งของคุณ: ")
                        .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)
                        .append(Component.text("#" + pos + " / " + total).color(NamedTextColor.YELLOW)),
                    Component.text("กำลังรอการประมวลผล...")
                        .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                    Component.empty(),
                    Component.text("► คลิกขวาเพื่อออกจากคิว")
                        .color(NamedTextColor.RED).decoration(TextDecoration.ITALIC, false)
                ));
            } else {
                meta.displayName(
                    Component.text("✦ เข้าสู่โลก SMP ✦")
                        .color(NamedTextColor.GREEN)
                        .decoration(TextDecoration.BOLD, true)
                        .decoration(TextDecoration.ITALIC, false));
                meta.lore(List.of(
                    Component.empty(),
                    Component.text("คลิกเพื่อเข้าคิว SMP")
                        .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                    Component.text("ผู้รอในคิว: ").color(NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
                        .append(Component.text(total + " คน").color(NamedTextColor.AQUA)),
                    Component.empty(),
                    Component.text("► คลิกเพื่อเข้าคิว!")
                        .color(NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false)
                ));
            }
        });
        return item;
    }

    private ItemStack buildInfoItem(boolean inQueue, int pos, int total) {
        ItemStack item = new ItemStack(inQueue ? Material.CLOCK : Material.MAP);
        item.editMeta(meta -> {
            if (inQueue) {
                meta.displayName(Component.text("⏳ สถานะคิว")
                        .color(NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false));
                meta.lore(List.of(
                    Component.empty(),
                    Component.text("ตำแหน่ง: ").color(NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
                        .append(Component.text("#" + pos).color(NamedTextColor.YELLOW)),
                    Component.text("คิวรวม: ").color(NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
                        .append(Component.text(total + " คน").color(NamedTextColor.AQUA))
                ));
            } else {
                meta.displayName(Component.text("ℹ ข้อมูล SMP")
                        .color(NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false));
                meta.lore(List.of(
                    Component.empty(),
                    Component.text("Survival Multiplayer World")
                        .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                    Component.text("ผู้รอในคิว: ").color(NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
                        .append(Component.text(total + " คน").color(NamedTextColor.AQUA))
                ));
            }
        });
        return item;
    }

    private ItemStack buildActionItem(boolean inQueue) {
        if (!inQueue) return pane(Material.BLACK_STAINED_GLASS_PANE);

        ItemStack item = new ItemStack(Material.BARRIER);
        item.editMeta(meta -> {
            meta.displayName(Component.text("✘ ออกจากคิว")
                    .color(NamedTextColor.RED).decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                Component.empty(),
                Component.text("คลิกเพื่อออกจากคิว SMP")
                    .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)
            ));
        });
        return item;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** สร้าง stained glass pane ที่ไม่มีชื่อแสดง */
    private ItemStack pane(Material material) {
        ItemStack item = new ItemStack(material);
        item.editMeta(meta ->
            meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false)));
        return item;
    }

    @Override
    public Inventory getInventory() { return inventory; }
}
