package com.example.epicportal.gui;

import com.example.epicportal.EpicPortal;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * GUI 54-slot (6 แถว) ที่แสดงบล็อกหญ้าตรงกลาง
 *
 * Layout (slot index):
 *  Row 1 [ 0- 8]: border (gray glass)
 *  Row 2 [ 9-17]: col 0,8 = border | col 1-7 = black glass
 *  Row 3 [18-26]: col 0,8 = border | 20=info | 22=GRASS | rest = black glass
 *  Row 4 [27-35]: col 0,8 = border | col 1-7 = black glass
 *  Row 5 [36-44]: col 0,8 = border | col 1-7 = black glass
 *  Row 6 [45-53]: border (gray glass)
 */
public class PortalGUI implements InventoryHolder {

    // Slot constants
    public static final int SLOT_INFO   = 20;   // แสดงข้อมูล SMP
    public static final int SLOT_GRASS  = 22;   // บล็อกหญ้า (ตรงกลาง)

    private final Inventory inventory;
    private final EpicPortal plugin;

    public PortalGUI(EpicPortal plugin, Player player) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, 54,
                Component.text("✦ Gateway — โลก SMP ✦")
                        .color(NamedTextColor.GOLD)
                        .decoration(TextDecoration.ITALIC, false));
        build(player);
    }

    // ── Build ────────────────────────────────────────────────────────────────

    private void build(Player player) {
        // 1. ใส่ black glass ทั้งหมด
        ItemStack black = pane(Material.BLACK_STAINED_GLASS_PANE);
        for (int i = 0; i < 54; i++) inventory.setItem(i, black);

        // 2. ขอบ gray glass (row 1, row 6, col 0, col 8)
        ItemStack gray = pane(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < 9; i++)  inventory.setItem(i, gray);        // Row 1
        for (int i = 45; i < 54; i++) inventory.setItem(i, gray);       // Row 6
        for (int r = 1; r <= 4; r++) {
            inventory.setItem(r * 9,     gray);   // Col 0 (left border)
            inventory.setItem(r * 9 + 8, gray);   // Col 8 (right border)
        }

        // 3. Items กลาง
        inventory.setItem(SLOT_GRASS, buildGrassItem());
        inventory.setItem(SLOT_INFO,  buildInfoItem());
    }

    // ── Item Builders ─────────────────────────────────────────────────────────

    private ItemStack buildGrassItem() {
        ItemStack item = new ItemStack(Material.GRASS_BLOCK);
        item.editMeta(meta -> {
            meta.displayName(
                Component.text("✦ เข้าสู่โลก SMP ✦")
                    .color(NamedTextColor.GREEN)
                    .decoration(TextDecoration.BOLD, true)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                Component.empty(),
                Component.text("คลิกเพื่อวาปเข้าโลก SMP")
                    .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Component.text("► คลิกเพื่อเข้าโลก!")
                    .color(NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false)
            ));
        });
        return item;
    }

    private ItemStack buildInfoItem() {
        ItemStack item = new ItemStack(Material.MAP);
        item.editMeta(meta -> {
            meta.displayName(Component.text("ℹ ข้อมูล SMP")
                    .color(NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                Component.empty(),
                Component.text("Survival Multiplayer World")
                    .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)
            ));
        });
        return item;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** สร้าง stained glass pane ที่ไม่มีชื่อแสดง */
    private ItemStack pane(Material material) {
        ItemStack item = new ItemStack(material);
        item.editMeta(meta ->
            meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false)));
        return item;
    }

    @Override
    public Inventory getInventory() { return inventory; }
}
