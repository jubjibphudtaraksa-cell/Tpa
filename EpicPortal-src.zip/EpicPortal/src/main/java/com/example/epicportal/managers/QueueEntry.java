package com.example.epicportal.managers;

import java.util.UUID;

/**
 * Holds the data for one player's position in a destination queue.
 */
public class QueueEntry {

    private final UUID playerUUID;
    private final String playerName;
    private final String target;   // "smp" หรือ "lp"
    private int attempts;
    private final long joinTime;

    public QueueEntry(UUID playerUUID, String playerName, String target) {
        this.playerUUID = playerUUID;
        this.playerName = playerName;
        this.target = target;
        this.attempts = 0;
        this.joinTime = System.currentTimeMillis();
    }

    public UUID getPlayerUUID()   { return playerUUID; }
    public String getPlayerName() { return playerName; }
    public String getTarget()     { return target; }
    public int getAttempts()      { return attempts; }
    public long getJoinTime()     { return joinTime; }
    public void incrementAttempts() { attempts++; }
}
