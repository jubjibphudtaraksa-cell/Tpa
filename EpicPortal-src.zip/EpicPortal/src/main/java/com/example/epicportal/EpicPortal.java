package com.example.epicportal;

import com.example.epicportal.listeners.CompassListener;
import com.example.epicportal.listeners.GUIListener;
import com.example.epicportal.listeners.ProtectionListener;
import com.example.epicportal.listeners.SwordListener;
import com.example.epicportal.managers.QueueManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public final class EpicPortal extends JavaPlugin {

    private static EpicPortal instance;
    private QueueManager queueManager;
    private CompassListener compassListener;
    private SwordListener swordListener;
    private ProtectionListener protectionListener;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        queueManager = new QueueManager(this);
        compassListener = new CompassListener(this);

        swordListener = new SwordListener(this);

        protectionListener = new ProtectionListener(this);
        getServer().getPluginManager().registerEvents(compassListener, this);
        getServer().getPluginManager().registerEvents(protectionListener, this);
        getServer().getPluginManager().registerEvents(swordListener, this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);

        // /queueleave command
        Objects.requireNonNull(getCommand("queueleave")).setExecutor(this::cmdQueueLeave);
        // /epicnpc command
        Objects.requireNonNull(getCommand("epicnpc")).setExecutor(this::cmdNpc);
        Objects.requireNonNull(getCommand("epicqueue")).setExecutor(this::cmdEpicQueue);
        // /queuepos command
        Objects.requireNonNull(getCommand("queuepos")).setExecutor(this::cmdQueuePos);

        queueManager.startTask();
        protectionListener.start();

        getLogger().info("EpicPortal enabled! EPIC=" + getConfig().getString("worlds.epic", "EPIC")
                + " -> SMP=" + getConfig().getString("worlds.smp", "world"));
    }

    @Override
    public void onDisable() {
        if (queueManager != null) queueManager.stopTask();
        getLogger().info("EpicPortal disabled.");
    }

    // ── Commands ────────────────────────────────────────────────────────────

    private boolean cmdQueueLeave(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command."));
            return true;
        }
        if (queueManager.removeFromQueue(player.getUniqueId())) {
            player.sendMessage(Component.text("✘ คุณออกจากคิวแล้ว").color(NamedTextColor.RED));
        } else {
            player.sendMessage(Component.text("คุณไม่ได้อยู่ในคิว").color(NamedTextColor.GRAY));
        }
        return true;
    }

    private boolean cmdQueuePos(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command."));
            return true;
        }
        int pos = queueManager.getPosition(player.getUniqueId());
        if (pos == -1) {
            player.sendMessage(Component.text("คุณไม่ได้อยู่ในคิว").color(NamedTextColor.GRAY));
        } else {
            player.sendMessage(Component.text("ตำแหน่งคิวของคุณ: ").color(NamedTextColor.GRAY)
                    .append(Component.text("#" + pos + " / " + queueManager.getQueueSize(player.getUniqueId()))
                            .color(NamedTextColor.YELLOW)));
        }
        return true;
    }

    /** /epicnpc <smp|pvp|remove> — สร้าง/ลบบอท โดยสั่งผ่านคำสั่งของ Citizens */
    private boolean cmdNpc(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command."));
            return true;
        }
        if (!player.hasPermission("epicportal.admin")) {
            player.sendMessage(Component.text("✘ คุณไม่มีสิทธิ์").color(NamedTextColor.RED));
            return true;
        }
        if (getServer().getPluginManager().getPlugin("Citizens") == null) {
            player.sendMessage(Component.text("✘ ต้องติดตั้งปลั๊กอิน Citizens ก่อนถึงจะใช้บอทได้").color(NamedTextColor.RED));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(Component.text("ใช้: /epicnpc <smp|pvp|remove>").color(NamedTextColor.YELLOW));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "smp" -> createBot(player, QueueManager.TARGET_SMP, "&a&lSMP");
            case "pvp", "lp" -> createBot(player, QueueManager.TARGET_LP, "&c&lPVP");
            case "remove" -> {
                player.performCommand("npc select");
                player.performCommand("npc remove");
            }
            default -> player.sendMessage(Component.text("ใช้: /epicnpc <smp|pvp|remove>").color(NamedTextColor.YELLOW));
        }
        return true;
    }

    private void createBot(Player player, String target, String title) {
        String skin = getConfig().getString("npc.skins." + target,
                QueueManager.TARGET_LP.equals(target) ? "jeb_" : "Notch");
        player.performCommand("npc create " + title + " --type player");
        player.performCommand("npc skin " + skin);
        player.performCommand("npc lookclose");
        // เมื่อกดบอท Citizens จะรันคำสั่งนี้ (<p> = ชื่อผู้เล่นที่กด)
        player.performCommand("npc command add epicqueue <p> " + target);
        player.sendMessage(Component.text("✔ สร้างบอท " + target.toUpperCase() + " แล้ว").color(NamedTextColor.GREEN));
    }

    /** /epicqueue <player> <smp|lp> — Citizens เรียกใช้ตอนผู้เล่นกดบอท */
    private boolean cmdEpicQueue(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length < 2) return true;
        Player player = getServer().getPlayerExact(args[0]);
        String target = args[1].toLowerCase();
        if (player == null || !(target.equals(QueueManager.TARGET_SMP) || target.equals(QueueManager.TARGET_LP))) return true;

        QueueManager qm = getQueueManager();
        String name = qm.getDisplayName(target);

        if (player.getWorld().getName().equalsIgnoreCase(qm.getWorldName(target))) {
            player.sendMessage(Component.text("✔ คุณอยู่ในโลก " + name + " แล้ว!").color(NamedTextColor.GREEN));
            return true;
        }
        if (qm.isInQueue(player.getUniqueId())) {
            player.sendMessage(Component.text("! คุณอยู่ในคิวแล้ว ตำแหน่ง: ").color(NamedTextColor.YELLOW)
                    .append(Component.text("#" + qm.getPosition(player.getUniqueId()) + " / "
                            + qm.getQueueSize(player.getUniqueId())).color(NamedTextColor.WHITE)));
            player.sendMessage(Component.text("พิมพ์ /queueleave เพื่อออกจากคิว").color(NamedTextColor.GRAY));
            return true;
        }
        if (qm.addToQueue(player, target)) {
            player.sendMessage(Component.text("✔ เข้าคิว " + name + " สำเร็จ! ตำแหน่ง: ").color(NamedTextColor.GREEN)
                    .append(Component.text("#" + qm.getPosition(player.getUniqueId()) + " / "
                            + qm.getQueueSize(target)).color(NamedTextColor.YELLOW)));
            player.sendMessage(Component.text("พิมพ์ /queueleave เพื่อออกจากคิว").color(NamedTextColor.GRAY));
        }
        return true;
    }

    // ── Getters ─────────────────────────────────────────────────────────────

    public static EpicPortal getInstance() { return instance; }
    public QueueManager getQueueManager() { return queueManager; }
    public SwordListener getSwordListener() { return swordListener; }
    public ProtectionListener getProtectionListener() { return protectionListener; }
    public CompassListener getCompassListener() { return compassListener; }
}
