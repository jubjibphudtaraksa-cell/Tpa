package com.example.epicportal;

import com.example.epicportal.listeners.CompassListener;
import com.example.epicportal.listeners.GUIListener;
import com.example.epicportal.listeners.NpcListener;
import com.example.epicportal.listeners.ProtectionListener;
import com.example.epicportal.listeners.SwordListener;
import com.example.epicportal.managers.PortalManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public final class EpicPortal extends JavaPlugin {

    private static EpicPortal instance;
    private PortalManager portalManager;
    private CompassListener compassListener;
    private NpcListener npcListener;
    private SwordListener swordListener;
    private ProtectionListener protectionListener;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        portalManager = new PortalManager(this);
        compassListener = new CompassListener(this);

        npcListener = new NpcListener(this);
        swordListener = new SwordListener(this);

        protectionListener = new ProtectionListener(this);
        getServer().getPluginManager().registerEvents(compassListener, this);
        getServer().getPluginManager().registerEvents(protectionListener, this);
        getServer().getPluginManager().registerEvents(npcListener, this);
        getServer().getPluginManager().registerEvents(swordListener, this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);

        // /epicnpc command
        Objects.requireNonNull(getCommand("epicnpc")).setExecutor(this::cmdNpc);

        protectionListener.start();

        getLogger().info("EpicPortal enabled! EPIC=" + getConfig().getString("worlds.epic", "EPIC")
                + " -> SMP=" + getConfig().getString("worlds.smp", "world"));
    }

    @Override
    public void onDisable() {
        getLogger().info("EpicPortal disabled.");
    }

    // ── Commands ────────────────────────────────────────────────────────────

    /** /epicnpc <smp|pvp|remove> — วาง/ลบบอท (แอดมิน) */
    private boolean cmdNpc(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command."));
            return true;
        }
        if (!player.hasPermission("epicportal.admin")) {
            player.sendMessage(Component.text("✘ คุณไม่มีสิทธิ์").color(NamedTextColor.RED));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(Component.text("ใช้: /epicnpc <smp|pvp|remove>").color(NamedTextColor.YELLOW));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "smp" -> {
                npcListener.spawnNpc(player.getLocation(), PortalManager.TARGET_SMP);
                player.sendMessage(Component.text("✔ วางบอท SMP แล้ว").color(NamedTextColor.GREEN));
            }
            case "pvp", "lp" -> {
                npcListener.spawnNpc(player.getLocation(), PortalManager.TARGET_LP);
                player.sendMessage(Component.text("✔ วางบอท PVP แล้ว").color(NamedTextColor.GREEN));
            }
            case "remove" -> {
                int count = 0;
                for (Entity e : player.getNearbyEntities(3, 3, 3)) {
                    if (npcListener.getNpcTarget(e) != null) { e.remove(); count++; }
                }
                player.sendMessage(Component.text("✔ ลบบอท " + count + " ตัว").color(NamedTextColor.YELLOW));
            }
            default -> player.sendMessage(Component.text("ใช้: /epicnpc <smp|pvp|remove>").color(NamedTextColor.YELLOW));
        }
        return true;
    }

    // ── Getters ─────────────────────────────────────────────────────────────

    public static EpicPortal getInstance() { return instance; }
    public PortalManager getPortalManager() { return portalManager; }
    public ProtectionListener getProtectionListener() { return protectionListener; }
    public CompassListener getCompassListener() { return compassListener; }
}
