package com.seihub.seihubplugin.managers;

import com.seihub.seihubplugin.SeiHubPlugin;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.OperatingSystemMXBean;
import java.util.List;

/**
 * AutoRestartManager ตรวจสอบ TPS, Memory (Heap), และ RAM จริง (OS-level)
 * แล้ว trigger restart อัตโนมัติถ้าสูงเกินกำหนด
 *
 * กฎ: Lobby จะ **ไม่ถูก auto-restart** ไม่ว่าจะตั้งค่าอะไร
 */
public class AutoRestartManager {

    private final SeiHubPlugin plugin;
    private BukkitTask monitorTask;

    // นับจำนวนครั้งที่ TPS ต่ำติดต่อกัน
    private int lowTpsCount = 0;
    // นับจำนวนครั้งที่ Memory สูงติดต่อกัน
    private int highMemCount = 0;

    public AutoRestartManager(SeiHubPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        int interval = plugin.getConfig().getInt("auto-restart.check-interval", 30);

        monitorTask = Bukkit.getScheduler().runTaskTimer(plugin, this::check, interval * 20L, interval * 20L);
        plugin.getLogger().info("[SeiHub] AutoRestart monitor started (interval: " + interval + "s)");
    }

    public void stop() {
        if (monitorTask != null) {
            monitorTask.cancel();
            monitorTask = null;
        }
    }

    private void check() {
        // =========================================================
        // หาว่าเซิร์ฟเวอร์นี้ชื่ออะไร (จาก config)
        // =========================================================
        String selfServer = plugin.getConfig().getString("self-server-name", "").toLowerCase();

        // =============================================
        // HARD LOCK: ห้าม auto-restart Lobby เด็ดขาด
        // =============================================
        if (selfServer.equals("lobby")) {
            return;
        }

        // ตรวจว่า server นี้อยู่ใน allowed-servers list
        List<String> allowed = plugin.getConfig().getStringList("auto-restart.allowed-servers");
        if (!selfServer.isEmpty() && !allowed.contains(selfServer)) {
            return;
        }

        // ถ้า restart กำลัง countdown อยู่แล้ว ไม่ต้อง trigger ซ้ำ
        if (plugin.getRestartManager().isRestarting(selfServer)) {
            return;
        }

        double tpsThreshold = plugin.getConfig().getDouble("auto-restart.tps-threshold", 12.0);
        int lowCountThreshold = plugin.getConfig().getInt("auto-restart.tps-low-count", 3);
        int heapThreshold = plugin.getConfig().getInt("auto-restart.memory-threshold", 90);
        int ramThreshold = plugin.getConfig().getInt("auto-restart.ram-threshold", 90);
        int highMemCountThreshold = plugin.getConfig().getInt("auto-restart.memory-high-count", 2);

        // ============= ตรวจ TPS =============
        // Paper API: Bukkit.getTPS() คืน double[] { 1min, 5min, 15min }
        double[] tps = Bukkit.getTPS();
        double currentTps = tps.length > 0 ? tps[0] : 20.0;

        if (currentTps < tpsThreshold) {
            lowTpsCount++;
            plugin.getLogger().warning("[SeiHub] Low TPS detected: " + String.format("%.1f", currentTps)
                    + " (count: " + lowTpsCount + "/" + lowCountThreshold + ")");

            if (lowTpsCount >= lowCountThreshold) {
                plugin.getLogger().warning("[SeiHub] TPS threshold breached! Triggering auto-restart for " + selfServer);
                triggerAutoRestart(selfServer, "Low TPS: " + String.format("%.1f", currentTps));
                lowTpsCount = 0;
                return;
            }
        } else {
            // TPS กลับมาปกติ reset counter
            if (lowTpsCount > 0) {
                plugin.getLogger().info("[SeiHub] TPS recovered: " + String.format("%.1f", currentTps));
                lowTpsCount = 0;
            }
        }

        // ============= ตรวจ JVM Heap Memory =============
        // วัด RAM ที่ Java process ใช้อยู่ (Xmx)
        MemoryMXBean memBean = ManagementFactory.getMemoryMXBean();
        long usedHeap = memBean.getHeapMemoryUsage().getUsed();
        long maxHeap = memBean.getHeapMemoryUsage().getMax();

        // ============= ตรวจ OS RAM (Physical Memory) =============
        // วัด RAM จริงของเครื่อง — ต้องใช้ com.sun API
        long usedRam = -1;
        long totalRam = -1;
        try {
            OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
            if (osBean instanceof com.sun.management.OperatingSystemMXBean sunOs) {
                totalRam = sunOs.getTotalMemorySize();
                long freeRam = sunOs.getFreeMemorySize();
                usedRam = totalRam - freeRam;
            }
        } catch (Exception ignored) {
            // ถ้า JVM ไม่รองรับ com.sun API ให้ข้ามไป
        }

        // รวมผล: trigger ถ้า heap หรือ OS RAM เกิน threshold
        boolean heapHigh = maxHeap > 0 && (int) ((usedHeap * 100) / maxHeap) >= heapThreshold;
        boolean ramHigh  = totalRam > 0 && (int) ((usedRam * 100) / totalRam) >= ramThreshold;

        if (heapHigh || ramHigh) {
            highMemCount++;
            String detail = buildMemDetail(usedHeap, maxHeap, usedRam, totalRam);
            plugin.getLogger().warning("[SeiHub] High memory detected: " + detail
                    + " (count: " + highMemCount + "/" + highMemCountThreshold + ")");

            if (highMemCount >= highMemCountThreshold) {
                plugin.getLogger().warning("[SeiHub] Memory threshold breached! Triggering auto-restart for " + selfServer);
                triggerAutoRestart(selfServer, "High RAM: " + detail);
                highMemCount = 0;
            }
        } else {
            if (highMemCount > 0) {
                plugin.getLogger().info("[SeiHub] Memory recovered.");
                highMemCount = 0;
            }
        }
    }

    /** สร้างข้อความสรุป memory usage สำหรับ log/broadcast */
    private String buildMemDetail(long usedHeap, long maxHeap, long usedRam, long totalRam) {
        StringBuilder sb = new StringBuilder();
        if (maxHeap > 0) {
            int heapPct = (int) ((usedHeap * 100) / maxHeap);
            sb.append("Heap ").append(heapPct).append("%")
              .append(" (").append(usedHeap / 1024 / 1024).append("MB/")
              .append(maxHeap / 1024 / 1024).append("MB)");
        }
        if (totalRam > 0) {
            int ramPct = (int) ((usedRam * 100) / totalRam);
            if (!sb.isEmpty()) sb.append(", ");
            sb.append("RAM ").append(ramPct).append("%")
              .append(" (").append(usedRam / 1024 / 1024).append("MB/")
              .append(totalRam / 1024 / 1024).append("MB)");
        }
        return sb.toString();
    }

    private void triggerAutoRestart(String serverName, String reason) {
        // broadcast เหตุผล
        Bukkit.broadcastMessage(
                "§c[SeiHub] §eAuto-restart triggered: §6" + reason);
        // ใช้ RestartManager เพื่อเริ่ม countdown ปกติ
        plugin.getRestartManager().initiateRestart(null, serverName);
    }
}
