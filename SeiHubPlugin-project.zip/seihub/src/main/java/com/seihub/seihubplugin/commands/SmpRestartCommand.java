package com.seihub.seihubplugin.commands;

import com.seihub.seihubplugin.SeiHubPlugin;
import com.seihub.seihubplugin.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * /smprestart — shortcut สำหรับ restart SMP โดยเฉพาะ
 * เทียบเท่า /restart smp
 */
public class SmpRestartCommand implements CommandExecutor, TabCompleter {

    private final SeiHubPlugin plugin;

    public SmpRestartCommand(SeiHubPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender,
                             @NotNull Command command,
                             @NotNull String label,
                             @NotNull String[] args) {

        // ตรวจสิทธิ์
        if (!sender.hasPermission("seihub.smprestart")) {
            sender.sendMessage(MessageUtil.color(
                    plugin.getConfig().getString("messages.no-permission",
                            "&c[SeiHub] คุณไม่มีสิทธิ์ใช้คำสั่งนี้")));
            return true;
        }

        // subcommand: /smprestart cancel
        if (args.length == 1 && args[0].equalsIgnoreCase("cancel")) {
            plugin.getRestartManager().cancelRestart("smp");
            return true;
        }

        // เริ่ม countdown restart SMP
        Player player = sender instanceof Player p ? p : null;
        plugin.getRestartManager().initiateRestart(player, "smp");
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender,
                                      @NotNull Command command,
                                      @NotNull String alias,
                                      @NotNull String[] args) {
        if (args.length == 1) {
            return List.of("cancel");
        }
        return List.of();
    }
}
