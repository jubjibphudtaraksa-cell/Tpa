package com.seihub.seihubplugin.commands;

import com.seihub.seihubplugin.SeiHubPlugin;
import com.seihub.seihubplugin.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * /seihub <subcommand>
 *
 * Subcommands:
 *   reload         — reload config.yml (ใช้แก้ชื่อโลก/เพิ่มโลกใหม่โดยไม่ต้อง restart server)
 *   worlds <server> — แสดงโลกที่ตั้งค่าไว้ใน config สำหรับ server นั้น
 *   worlds list    — แสดงโลกทั้งหมดที่โหลดอยู่ใน server นี้ (ใช้ copy ชื่อ)
 *   status         — แสดงสถานะ auto-restart และ countdown ที่กำลังทำงาน
 *
 * Permission: seihub.admin
 */
public class SeiHubCommand implements CommandExecutor, TabCompleter {

    private final SeiHubPlugin plugin;

    public SeiHubCommand(SeiHubPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender,
                             @NotNull Command command,
                             @NotNull String label,
                             @NotNull String[] args) {

        if (!sender.hasPermission("seihub.admin")) {
            sender.sendMessage(MessageUtil.color(
                    plugin.getConfig().getString("messages.no-permission",
                            "&c[SeiHub] คุณไม่มีสิทธิ์ใช้คำสั่งนี้")));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        return switch (args[0].toLowerCase()) {
            case "reload" -> handleReload(sender);
            case "worlds" -> handleWorlds(sender, args);
            case "status" -> handleStatus(sender);
            default -> {
                sendHelp(sender);
                yield true;
            }
        };
    }

    // =========================================================
    //  /seihub reload
    // =========================================================
    private boolean handleReload(CommandSender sender) {
        sender.sendMessage(MessageUtil.color("&e[SeiHub] กำลัง reload config..."));

        try {
            plugin.reloadConfig();
            sender.sendMessage(MessageUtil.color("&a[SeiHub] Reload สำเร็จ!"));
            sender.sendMessage(MessageUtil.color("&7Restart method: &f"
                    + plugin.getConfig().getString("restart-method", "shutdown")));
            sender.sendMessage(MessageUtil.color("&7Self server: &f"
                    + plugin.getConfig().getString("self-server-name", "(not set)")));

            // แสดงจำนวนโลกที่ตั้งค่าแต่ละ server
            for (String srv : List.of("smp", "pvp", "lobby")) {
                List<String> worlds = plugin.getConfig().getStringList("worlds." + srv);
                sender.sendMessage(MessageUtil.color(
                        "&7worlds." + srv + ": &f" + worlds.size() + " worlds &8" + worlds));
            }

        } catch (Exception e) {
            sender.sendMessage(MessageUtil.color("&c[SeiHub] Reload ล้มเหลว: " + e.getMessage()));
            plugin.getLogger().severe("[SeiHub] Reload failed: " + e.getMessage());
        }

        return true;
    }

    // =========================================================
    //  /seihub worlds [server|list]
    // =========================================================
    private boolean handleWorlds(CommandSender sender, String[] args) {
        // /seihub worlds list — แสดงโลกที่โหลดอยู่จริงในตอนนี้
        if (args.length >= 2 && args[1].equalsIgnoreCase("list")) {
            sender.sendMessage(MessageUtil.color("&e[SeiHub] &fโลกที่โหลดอยู่ใน server นี้:"));
            for (World w : Bukkit.getWorlds()) {
                String type = switch (w.getEnvironment()) {
                    case NETHER -> "&5[NETHER]";
                    case THE_END -> "&d[THE_END]";
                    default -> "&a[NORMAL]";
                };
                sender.sendMessage(MessageUtil.color("  " + type + " &f" + w.getName()));
            }
            sender.sendMessage(MessageUtil.color(
                    "&7เพิ่มชื่อโลกเหล่านี้ใน &fconfig.yml &7แล้วพิมพ์ &f/seihub reload"));
            return true;
        }

        // /seihub worlds <server> — แสดงโลกที่ตั้งค่าใน config
        if (args.length >= 2) {
            String srv = args[1].toLowerCase();
            List<String> configWorlds = plugin.getConfig().getStringList("worlds." + srv);

            if (configWorlds.isEmpty()) {
                sender.sendMessage(MessageUtil.color(
                        "&c[SeiHub] ไม่พบการตั้งค่าโลกสำหรับ &e" + srv
                        + " &cใน config.yml"));
                return true;
            }

            sender.sendMessage(MessageUtil.color("&e[SeiHub] &fโลกใน config สำหรับ &e" + srv.toUpperCase() + "&f:"));
            for (String worldName : configWorlds) {
                World w = Bukkit.getWorld(worldName);
                String status = w != null ? "&a[โหลดอยู่]" : "&c[ไม่พบ]";
                sender.sendMessage(MessageUtil.color("  " + status + " &f" + worldName));
            }
            return true;
        }

        // /seihub worlds — ไม่ระบุ server แสดง help
        sender.sendMessage(MessageUtil.color("&e[SeiHub] &fการใช้งาน:"));
        sender.sendMessage(MessageUtil.color("  &f/seihub worlds list &7— ดูโลกที่โหลดอยู่จริง (copy ชื่อได้)"));
        sender.sendMessage(MessageUtil.color("  &f/seihub worlds <smp|pvp|lobby> &7— ดูโลกใน config"));
        return true;
    }

    // =========================================================
    //  /seihub status
    // =========================================================
    private boolean handleStatus(CommandSender sender) {
        sender.sendMessage(MessageUtil.color("&e[SeiHub] &f=== Status ==="));
        sender.sendMessage(MessageUtil.color("&7Server: &f"
                + plugin.getConfig().getString("self-server-name", "(not set)")));
        sender.sendMessage(MessageUtil.color("&7Restart method: &f"
                + plugin.getConfig().getString("restart-method", "shutdown")));

        // TPS
        double[] tps = Bukkit.getTPS();
        String tpsColor = tps[0] >= 18 ? "&a" : tps[0] >= 14 ? "&e" : "&c";
        sender.sendMessage(MessageUtil.color("&7TPS: " + tpsColor + String.format("%.2f", tps[0])
                + " &81m &7/ " + String.format("%.2f", tps[1])
                + " &85m &7/ " + String.format("%.2f", tps[2]) + " &815m"));

        // Memory
        Runtime rt = Runtime.getRuntime();
        long usedMb = (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024;
        long maxMb = rt.maxMemory() / 1024 / 1024;
        int memPct = (int) ((usedMb * 100) / maxMb);
        String memColor = memPct < 70 ? "&a" : memPct < 85 ? "&e" : "&c";
        sender.sendMessage(MessageUtil.color("&7Heap: " + memColor + usedMb + "MB / " + maxMb + "MB"
                + " (" + memPct + "%)"));

        // Active countdown tasks
        sender.sendMessage(MessageUtil.color("&7Auto-restart: &f"
                + (plugin.getConfig().getBoolean("auto-restart.enabled") ? "&aเปิด" : "&cปิด")));

        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(MessageUtil.color("&e[SeiHub] &fคำสั่งทั้งหมด:"));
        sender.sendMessage(MessageUtil.color("  &f/seihub reload &7— reload config (เพิ่ม/แก้ชื่อโลกได้เลย)"));
        sender.sendMessage(MessageUtil.color("  &f/seihub worlds list &7— ดูโลกที่โหลดอยู่ใน server นี้"));
        sender.sendMessage(MessageUtil.color("  &f/seihub worlds <server> &7— ดูโลกใน config ของ server นั้น"));
        sender.sendMessage(MessageUtil.color("  &f/seihub status &7— ดู TPS, Memory, และสถานะ"));
        sender.sendMessage(MessageUtil.color("  &f/restart <smp|pvp|lobby> [cancel] &7— restart server"));
        sender.sendMessage(MessageUtil.color("  &f/smprestart [cancel] &7— restart SMP"));
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender,
                                      @NotNull Command command,
                                      @NotNull String alias,
                                      @NotNull String[] args) {
        if (args.length == 1) {
            return List.of("reload", "worlds", "status")
                    .stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("worlds")) {
            return List.of("list", "smp", "pvp", "lobby")
                    .stream()
                    .filter(s -> s.startsWith(args[1].toLowerCase()))
                    .toList();
        }
        return List.of();
    }
}
