package com.seihub.seihubplugin.utils;

import java.io.*;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/**
 * RconUtil — ส่งคำสั่งผ่าน RCON protocol (Source RCON)
 *
 * ใช้เมื่อ restart-method: "rcon" ใน config.yml
 * ต้องเปิด enable-rcon: true ใน server.properties ของ server ปลายทาง
 */
public class RconUtil {

    private static final int RCON_AUTHENTICATE = 3;
    private static final int RCON_COMMAND = 2;

    private RconUtil() {}

    /**
     * ส่งคำสั่งไปยัง RCON server
     * @throws IOException ถ้าเชื่อมต่อไม่ได้หรือ auth ผิด
     */
    public static String sendCommand(String host, int port, String password, String command)
            throws IOException {

        try (Socket socket = new Socket(host, port)) {
            socket.setSoTimeout(5000); // timeout 5 วินาที
            InputStream in = socket.getInputStream();
            OutputStream out = socket.getOutputStream();

            // Auth
            sendPacket(out, 1, RCON_AUTHENTICATE, password);
            RconPacket authResponse = readPacket(in);
            if (authResponse.id == -1) {
                throw new IOException("RCON authentication failed (wrong password?)");
            }

            // Send command
            sendPacket(out, 2, RCON_COMMAND, command);
            RconPacket cmdResponse = readPacket(in);
            return cmdResponse.body;
        }
    }

    private static void sendPacket(OutputStream out, int id, int type, String body)
            throws IOException {
        byte[] bodyBytes = body.getBytes(StandardCharsets.UTF_8);
        int length = 4 + 4 + bodyBytes.length + 2; // id + type + body + 2 null bytes

        ByteBuffer buf = ByteBuffer.allocate(4 + length);
        buf.order(ByteOrder.LITTLE_ENDIAN);
        buf.putInt(length);
        buf.putInt(id);
        buf.putInt(type);
        buf.put(bodyBytes);
        buf.put((byte) 0);
        buf.put((byte) 0);

        out.write(buf.array());
        out.flush();
    }

    private static RconPacket readPacket(InputStream in) throws IOException {
        byte[] lenBytes = in.readNBytes(4);
        if (lenBytes.length < 4) throw new IOException("RCON: short read on length");
        int length = ByteBuffer.wrap(lenBytes).order(ByteOrder.LITTLE_ENDIAN).getInt();

        byte[] data = in.readNBytes(length);
        ByteBuffer buf = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        int id = buf.getInt();
        buf.getInt(); // type (ignored)
        byte[] bodyBytes = new byte[length - 8 - 2];
        buf.get(bodyBytes);
        String body = new String(bodyBytes, StandardCharsets.UTF_8);
        return new RconPacket(id, body);
    }

    private record RconPacket(int id, String body) {}
}
