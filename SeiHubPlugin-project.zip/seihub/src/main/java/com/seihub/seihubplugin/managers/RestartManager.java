package com.seihub.seihubplugin.managers;

import com.seihub.seihubplugin.SeiHubPlugin;
import com.seihub.seihubplugin.utils.MessageUtil;
import com.seihub.seihubplugin.utils.RconUtil;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RestartManager จัดการ countdown และการรีสตาร์ทเซิร์ฟเวอร์
 *
 * restart-method ที่รองรับ:
 *  - "shutdown"  : เรียก Bukkit.shutdown() — ต้องใช้ wrapper script เพื่อให้เซิร์ฟเวอร์กลับมา
 *  - "command"   : รัน shell command ที่กำหนดใน config
 *  - "rcon"      : ส่งคำสั่ง "restart" ผ่าน RCON ไปยัง server อื่น
 */
public class RestartManager {

    private final SeiHubPlugin plugin;
    // เก็บ task ที่กำลัง countdown อยู่ (server name -> task id)
    private final Map<String, BukkitTask> activeTasks = new ConcurrentHashMap<>();

    /** เซิร์ฟเวอร์ที่เป็น "ตัวเอง" (เซิร์ฟเวอร์ที่รันปลั๊กอินนี้อยู่) */
    private final String selfServerName;

    public RestartManager(SeiHubPlugin plugin) {
        this.plugin = plugin;
        // อ่านชื่อตัวเองจาก config (ไม่บังคับ) เพื่อตรวจสอบ self-restart
        this.selfServerName = plugin.getConfig().getString("self-server-name", "").toLowerCase();
    }

    // =========================================================
    //  Public API
    // =========================================================

    /**
     * เริ่ม countdown รีสตาร์ทสำหรับ server ชื่อ serverName
     * @param initiator  Player ที่สั่ง (null = system/auto-restart)
     * @param serverName ชื่อ server: "smp", "pvp", "lobby"
     */
    public void initiateRestart(Player initiator, String serverName) {
        String key = serverName.toLowerCase();

        if (activeTasks.containsKey(key)) {
            if (initiator != null) {
                String msg = plugin.getConfig().getString(
                        "messages.already-restarting",
                        "&c[SeiHub] {server} กำลัง countdown รีสตาร์ทอยู่แล้ว!")
                        .replace("{server}", serverName.toUpperCase());
                initiator.sendMessage(MessageUtil.color(msg));
            }
            return;
        }

        // ดึง countdown list
        List<?> rawList = plugin.getConfig().getList("countdown." + key,
                Arrays.asList(60, 30, 10, 5, 4, 3, 2, 1));
        List<Integer> countdown = new ArrayList<>();
        for (Object o : rawList) {
            if (o instanceof Integer i) countdown.add(i);
            else if (o instanceof Number n) countdown.add(n.intValue());
        }
        Collections.sort(countdown, Collections.reverseOrder());
        int totalSeconds = countdown.isEmpty() ? 10 : countdown.get(0);

        plugin.getLogger().info("[SeiHub] Restart initiated for " + key
                + " by " + (initiator != null ? initiator.getName() : "system")
                + " — countdown " + totalSeconds + "s");

        // broadcast ข้อความเริ่ม countdown ไป Lobby ด้วย
        broadcastToLobby(key, totalSeconds);

        BukkitTask task = new BukkitRunnable() {
            int remaining = totalSeconds;
            final Iterator<Integer> warnIter = countdown.iterator();
            int nextWarn = warnIter.hasNext() ? warnIter.next() : -1;

            @Override
            public void run() {
                if (remaining <= 0) {
                    // ถึงเวลา — kick ผู้เล่น แล้ว restart
                    activeTasks.remove(key);
                    executeRestart(key);
                    cancel();
                    return;
                }

                if (remaining == nextWarn) {
                    broadcastCountdown(key, remaining);
                    nextWarn = warnIter.hasNext() ? warnIter.next() : -1;
                }
                remaining--;
            }
        }.runTaskTimer(plugin, 0L, 20L); // ทุก 1 วินาที

        activeTasks.put(key, task);
    }

    /** ยกเลิก countdown ของ server */
    public void cancelRestart(String serverName) {
        String key = serverName.toLowerCase();
        BukkitTask task = activeTasks.remove(key);
        if (task != null) {
            task.cancel();
            String msg = plugin.getConfig().getString(
                    "messages.restart-canceled",
                    "&a[SeiHub] การรีสตาร์ท {server} ถูกยกเลิก")
                    .replace("{server}", serverName.toUpperCase());
            Bukkit.broadcastMessage(MessageUtil.color(msg));
        }
    }

    /** ยกเลิกทั้งหมด (เรียกตอน onDisable) */
    public void cancelAll() {
        for (BukkitTask t : activeTasks.values()) t.cancel();
        activeTasks.clear();
    }

    /** ตรวจสอบว่า server กำลัง countdown อยู่ไหม */
    public boolean isRestarting(String serverName) {
        return activeTasks.containsKey(serverName.toLowerCase());
    }

    // =========================================================
    //  Private helpers
    // =========================================================

    /** broadcast ข้อความ countdown ไปยังผู้เล่นทุกคนใน server ปัจจุบัน */
    private void broadcastCountdown(String serverName, int seconds) {
        String template = plugin.getConfig().getString(
                "messages.restart-broadcast",
                "&c[SeiHub] &e{server} &cจะรีสตาร์ทใน &6{time} &cวินาที!");
        String msg = template
                .replace("{server}", serverName.toUpperCase())
                .replace("{time}", String.valueOf(seconds));
        Bukkit.broadcastMessage(MessageUtil.color(msg));
    }

    /**
     * ส่งข้อความไปยัง Lobby ผ่าน BungeeCord plugin messaging
     * ถ้าไม่มีผู้เล่นออนไลน์ข้อความจะส่งไม่ได้ (ข้อจำกัดของ plugin messaging)
     */
    private void broadcastToLobby(String serverName, int seconds) {
        // ต้องมีผู้เล่นอย่างน้อย 1 คนถึงจะส่ง plugin message ได้
        if (Bukkit.getOnlinePlayers().isEmpty()) return;
        Player carrier = Bukkit.getOnlinePlayers().iterator().next();

        // อ่านชื่อ lobby server จาก config (ค่า default: "lobby")
        String lobbyServerName = plugin.getConfig().getString("lobby-server-name", "lobby");

        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(bos);
            dos.writeUTF("Forward");
            dos.writeUTF(lobbyServerName); // ชื่อ server ใน BungeeCord/Velocity config
            dos.writeUTF("SeiHubRestart");

            // payload: "smp:60"
            ByteArrayOutputStream payload = new ByteArrayOutputStream();
            DataOutputStream payloadDos = new DataOutputStream(payload);
            payloadDos.writeUTF(serverName + ":" + seconds);

            dos.writeShort(payload.toByteArray().length);
            dos.write(payload.toByteArray());

            carrier.sendPluginMessage(plugin, "BungeeCord", bos.toByteArray());
        } catch (IOException e) {
            plugin.getLogger().warning("[SeiHub] Failed to send restart notice to Lobby: " + e.getMessage());
        }
    }

    /**
     * ดำเนินการรีสตาร์ทจริง — kick ผู้เล่น, save+unload worlds, แล้ว restart
     */
    private void executeRestart(String serverName) {
        // broadcast "กำลัง restart"
        String nowMsg = plugin.getConfig().getString(
                "messages.restart-now",
                "&c[SeiHub] {server} กำลังรีสตาร์ทแล้ว...")
                .replace("{server}", serverName.toUpperCase());
        Bukkit.broadcastMessage(MessageUtil.color(nowMsg));

        // บอก Lobby ว่าเริ่ม restart แล้ว + เวลาโดยประมาณที่จะเสร็จ
        notifyLobbyRestartNow(serverName);

        // ส่งผู้เล่นทุกคนไป Lobby (EPIC) ก่อน แทนการ kick ทันที
        String lobbyName = plugin.getConfig().getString("lobby-server-name", "EPIC");
        boolean sendToLobby = plugin.getConfig().getBoolean("send-to-lobby-on-restart", true);
        // lobby เองไม่มี lobby ให้ส่งไป
        if (sendToLobby && !serverName.equalsIgnoreCase("lobby")) {
            for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) {
                sendToServer(p, lobbyName);
            }
        }

        // รอ 2 วินาทีให้ proxy ย้ายผู้เล่นเสร็จ แล้วค่อย kick คนที่เหลือ + save + restart
        new BukkitRunnable() {
            @Override
            public void run() {
                String kickMsg = plugin.getConfig().getString(
                        "messages.kick-message",
                        "&c[SeiHub]\n&eเซิร์ฟเวอร์ {server} กำลังรีสตาร์ท\n&7กรุณากลับมาใหม่ในอีกสักครู่")
                        .replace("{server}", serverName.toUpperCase());
                String coloredKick = MessageUtil.color(kickMsg);

                // คนที่ย้ายไม่สำเร็จ (เช่น lobby ล่ม) ค่อย kick
                for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) {
                    p.kickPlayer(coloredKick);
                }

                saveAndUnloadWorlds(serverName);

                new BukkitRunnable() {
                    @Override
                    public void run() {
                        doRestart(serverName);
                    }
                }.runTaskLater(plugin, 40L);
            }
        }.runTaskLater(plugin, sendToLobby ? 40L : 1L);
    }

    /** ส่ง "SeiHubRestartNow" (server:eta วินาที) ไป Lobby ก่อนผู้เล่นจะถูกย้าย */
    private void notifyLobbyRestartNow(String serverName) {
        if (serverName.equalsIgnoreCase("lobby")) return;
        if (Bukkit.getOnlinePlayers().isEmpty()) return;
        Player carrier = Bukkit.getOnlinePlayers().iterator().next();
        String lobbyName = plugin.getConfig().getString("lobby-server-name", "EPIC");
        int eta = plugin.getConfig().getInt("restart-eta." + serverName.toLowerCase(), 90);

        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(bos);
            dos.writeUTF("Forward");
            dos.writeUTF(lobbyName);
            dos.writeUTF("SeiHubRestartNow");

            ByteArrayOutputStream payload = new ByteArrayOutputStream();
            DataOutputStream payloadDos = new DataOutputStream(payload);
            payloadDos.writeUTF(serverName + ":" + eta);

            dos.writeShort(payload.toByteArray().length);
            dos.write(payload.toByteArray());
            carrier.sendPluginMessage(plugin, "BungeeCord", bos.toByteArray());
        } catch (IOException e) {
            plugin.getLogger().warning("[SeiHub] Failed to notify Lobby: " + e.getMessage());
        }
    }

    /** ส่งผู้เล่นไป server อื่นผ่าน BungeeCord/Velocity "Connect" */
    private void sendToServer(Player player, String target) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(bos);
            dos.writeUTF("Connect");
            dos.writeUTF(target);
            player.sendPluginMessage(plugin, "BungeeCord", bos.toByteArray());
        } catch (IOException e) {
            plugin.getLogger().warning("[SeiHub] Failed to send " + player.getName()
                    + " to " + target + ": " + e.getMessage());
        }
    }

    /**
     * Save chunk + unload worlds ทั้งหมดของ server นี้ตาม config
     * ป้องกัน chunk corruption เมื่อ restart กะทันหัน
     *
     * SMP:   smp, smp_nether, smp_the_end
     * Lobby: EPIC, EPIC_nether, EPIC_the_end
     * PvP:   sworld1, sworld2, sworld3, lp
     */
    private void saveAndUnloadWorlds(String serverName) {
        List<String> worldNames = plugin.getConfig().getStringList("worlds." + serverName.toLowerCase());

        if (worldNames.isEmpty()) {
            // ถ้าไม่ได้ตั้งค่าใน config ให้ save ทุก world ที่โหลดอยู่แทน
            plugin.getLogger().warning("[SeiHub] No worlds configured for '" + serverName
                    + "' — saving all loaded worlds as fallback");
            for (World w : Bukkit.getWorlds()) {
                plugin.getLogger().info("[SeiHub] Saving world: " + w.getName());
                w.save();
            }
            return;
        }

        for (String worldName : worldNames) {
            World world = Bukkit.getWorld(worldName);
            if (world == null) {
                plugin.getLogger().warning("[SeiHub] World not found (already unloaded?): " + worldName);
                continue;
            }

            // Kick ผู้เล่นที่ยังอยู่ใน world นี้ออกก่อน (กรณีที่ kick all ไม่ได้ผล)
            if (!world.getPlayers().isEmpty()) {
                String kickMsg = MessageUtil.color("&c[SeiHub] Server กำลังรีสตาร์ท...");
                for (Player p : world.getPlayers()) {
                    p.kickPlayer(kickMsg);
                }
            }

            // Save world
            plugin.getLogger().info("[SeiHub] Saving world: " + worldName);
            world.save();
        }

        plugin.getLogger().info("[SeiHub] All worlds for '" + serverName + "' saved successfully.");
    }

    /**
     * เลือก restart method จาก config แล้วดำเนินการ
     */
    private void doRestart(String serverName) {
        String method = plugin.getConfig().getString("restart-method", "shutdown").toLowerCase();

        switch (method) {
            case "shutdown" -> {
                // ============================================================
                // METHOD: SHUTDOWN
                // เรียก Bukkit.shutdown() — เซิร์ฟเวอร์จะปิดตัว
                // wrapper script (start.sh) ต้องวนลูปเพื่อให้มันกลับขึ้นมาใหม่
                // ============================================================
                plugin.getLogger().info("[SeiHub] Executing SHUTDOWN restart for: " + serverName);
                Bukkit.shutdown();
            }
            case "command" -> {
                // ============================================================
                // METHOD: SHELL COMMAND
                // รัน shell command ที่กำหนดไว้ใน restart-commands.<server>
                // ============================================================
                String cmd = plugin.getConfig().getString("restart-commands." + serverName, "");
                if (cmd == null || cmd.isBlank()) {
                    plugin.getLogger().warning("[SeiHub] restart-commands." + serverName
                            + " is empty! Please set it in config.yml");
                    plugin.getLogger().warning("[SeiHub] Falling back to shutdown...");
                    Bukkit.shutdown();
                    return;
                }
                plugin.getLogger().info("[SeiHub] Running restart command for " + serverName + ": " + cmd);
                try {
                    Runtime.getRuntime().exec(cmd);
                } catch (IOException e) {
                    plugin.getLogger().severe("[SeiHub] Failed to run restart command: " + e.getMessage());
                }
            }
            case "rcon" -> {
                // ============================================================
                // METHOD: RCON
                // ส่ง "restart" command ผ่าน RCON ไปยัง server อื่น
                // ใช้เมื่อปลั๊กอินอยู่ใน Lobby แต่ต้องการ restart SMP
                // ============================================================
                boolean enabled = plugin.getConfig().getBoolean("rcon." + serverName + ".enabled", false);
                if (!enabled) {
                    plugin.getLogger().warning("[SeiHub] RCON not enabled for " + serverName + " in config.yml");
                    return;
                }
                String host = plugin.getConfig().getString("rcon." + serverName + ".host", "127.0.0.1");
                int port = plugin.getConfig().getInt("rcon." + serverName + ".port", 25575);
                String password = plugin.getConfig().getString("rcon." + serverName + ".password", "");

                plugin.getLogger().info("[SeiHub] Sending RCON restart to " + serverName
                        + " @ " + host + ":" + port);
                // รัน async เพื่อไม่ block main thread
                Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                    try {
                        RconUtil.sendCommand(host, port, password, "restart");
                        plugin.getLogger().info("[SeiHub] RCON restart sent to " + serverName);
                    } catch (Exception e) {
                        plugin.getLogger().severe("[SeiHub] RCON failed for " + serverName + ": " + e.getMessage());
                    }
                });
            }
            default -> plugin.getLogger().warning("[SeiHub] Unknown restart-method: " + method);
        }
    }
}
