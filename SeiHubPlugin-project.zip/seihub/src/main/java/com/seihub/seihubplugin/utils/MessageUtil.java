package com.seihub.seihubplugin.utils;

import org.bukkit.ChatColor;

public class MessageUtil {

    private MessageUtil() {}

    /**
     * แปลง & color codes เป็น § codes ของ Minecraft
     */
    public static String color(String message) {
        if (message == null) return "";
        return ChatColor.translateAlternateColorCodes('&', message);
    }

    /**
     * แปลงวินาทีเป็นรูปแบบอ่านง่าย เช่น "1 นาที 30 วินาที"
     */
    public static String formatTime(int seconds) {
        if (seconds >= 60) {
            int mins = seconds / 60;
            int secs = seconds % 60;
            if (secs == 0) return mins + " นาที";
            return mins + " นาที " + secs + " วินาที";
        }
        return seconds + " วินาที";
    }
}
