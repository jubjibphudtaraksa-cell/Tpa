package com.seihub.seihubplugin.commands;

import com.seihub.seihubplugin.SeiHubPlugin;
import com.seihub.seihubplugin.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * /restart <smp|pvp|lobby> [cancel]
 *
 * Permission แยกตามเซิร์ฟเวอร์:
 *   seihub.smprestart  → /restart smp
 *   seihub.pvprestart  → /restart pvp
 *   seihub.lobbyrestart → /restart lobby
 */
public class RestartCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SERVER_OPTIONS = List.of("smp", "pvp", "lobby");
    private final SeiHubPlugin plugin;

    public RestartCommand(SeiHubPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender,
                             @NotNull Command command,
                             @NotNull String label,
                             @NotNull String[] args) {

        // ต้องระบุชื่อ server
        if (args.length < 1) {
            sender.sendMessage(MessageUtil.color("&c[SeiHub] Usage: /restart <smp|pvp|lobby> [cancel]"));
            return true;
        }

        String serverName = args[0].toLowerCase();

        // ตรวจว่าเป็น server ที่รองรับ
        if (!SERVER_OPTIONS.contains(serverName)) {
            sender.sendMessage(MessageUtil.color("&c[SeiHub] ไม่รู้จักเซิร์ฟเวอร์: &e" + serverName
                    + " &c(รองรับ: smp, pvp, lobby)"));
            return true;
        }

        // ตรวจ permission ตามเซิร์ฟเวอร์
        String permission = "seihub." + serverName + "restart";
        if (!sender.hasPermission(permission)) {
            sender.sendMessage(MessageUtil.color(
                    plugin.getConfig().getString("messages.no-permission",
                            "&c[SeiHub] คุณไม่มีสิทธิ์ใช้คำสั่งนี้")));
            return true;
        }

        // subcommand cancel
        if (args.length >= 2 && args[1].equalsIgnoreCase("cancel")) {
            plugin.getRestartManager().cancelRestart(serverName);
            sender.sendMessage(MessageUtil.color("&a[SeiHub] ยกเลิก countdown &e" + serverName.toUpperCase() + "&a แล้ว"));
            return true;
        }

        // เริ่ม countdown
        Player player = sender instanceof Player p ? p : null;
        plugin.getRestartManager().initiateRestart(player, serverName);
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender,
                                      @NotNull Command command,
                                      @NotNull String alias,
                                      @NotNull String[] args) {

        if (args.length == 1) {
            List<String> options = new ArrayList<>();
            for (String s : SERVER_OPTIONS) {
                if (sender.hasPermission("seihub." + s + "restart")
                        && s.startsWith(args[0].toLowerCase())) {
                    options.add(s);
                }
            }
            return options;
        }

        if (args.length == 2 && SERVER_OPTIONS.contains(args[0].toLowerCase())) {
            if ("cancel".startsWith(args[1].toLowerCase())) {
                return List.of("cancel");
            }
        }

        return List.of();
    }
}
