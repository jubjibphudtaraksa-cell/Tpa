package com.seihub.seihubplugin.listeners;

import com.seihub.seihubplugin.SeiHubPlugin;
import org.bukkit.Bukkit;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

/**
 * รับ plugin message จาก server อื่นผ่าน BungeeCord channel
 *
 * ถ้าปลั๊กอินนี้อยู่ใน Lobby จะรับ message และ broadcast แจ้งผู้เล่น
 * ว่า SMP/PvP กำลังจะ restart
 */
public class PluginMessageListener implements org.bukkit.plugin.messaging.PluginMessageListener {

    private final SeiHubPlugin plugin;

    public PluginMessageListener(SeiHubPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void onPluginMessageReceived(@NotNull String channel,
                                        @NotNull org.bukkit.entity.Player player,
                                        byte @NotNull [] message) {

        if (!channel.equals("BungeeCord")) return;

        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(message));
            String subchannel = in.readUTF();

            boolean isNow = subchannel.equals("SeiHubRestartNow");
            if (!isNow && !subchannel.equals("SeiHubRestart")) return;

            // อ่าน payload: "serverName:seconds"
            short dataLen = in.readShort();
            byte[] data = new byte[dataLen];
            in.readFully(data);
            DataInputStream payload = new DataInputStream(new ByteArrayInputStream(data));
            String payloadStr = payload.readUTF();

            String[] parts = payloadStr.split(":", 2);
            if (parts.length != 2) return;

            String serverName = parts[0].toUpperCase();
            String seconds = parts[1];

            // restart เริ่มแล้ว — บอกเวลาที่เหลือ + แจ้งเมื่อเสร็จ
            if (isNow) {
                int eta;
                try {
                    eta = Integer.parseInt(seconds);
                } catch (NumberFormatException e) {
                    return;
                }
                plugin.getRestartNoticeManager().start(parts[0], eta);
                return;
            }

            // broadcast ให้ผู้เล่นใน Lobby ทราบ
            String msg = "§c[SeiHub] §e" + serverName
                    + " §cจะรีสตาร์ทใน §6" + seconds + " §cวินาที!";
            Bukkit.broadcastMessage(msg);

        } catch (IOException e) {
            plugin.getLogger().warning("[SeiHub] Error reading plugin message: " + e.getMessage());
        }
    }
}
