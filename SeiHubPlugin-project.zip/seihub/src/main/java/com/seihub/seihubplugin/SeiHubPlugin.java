package com.seihub.seihubplugin;

import com.seihub.seihubplugin.commands.RestartCommand;
import com.seihub.seihubplugin.commands.SeiHubCommand;
import com.seihub.seihubplugin.commands.SmpRestartCommand;
import com.seihub.seihubplugin.listeners.PluginMessageListener;
import com.seihub.seihubplugin.managers.RestartManager;
import com.seihub.seihubplugin.managers.RestartNoticeManager;
import com.seihub.seihubplugin.managers.AutoRestartManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.Messenger;

public class SeiHubPlugin extends JavaPlugin {

    private static SeiHubPlugin instance;
    private RestartManager restartManager;
    private AutoRestartManager autoRestartManager;
    private RestartNoticeManager restartNoticeManager;

    @Override
    public void onEnable() {
        instance = this;

        // Save default config
        saveDefaultConfig();

        // Init managers
        restartManager = new RestartManager(this);
        autoRestartManager = new AutoRestartManager(this);
        restartNoticeManager = new RestartNoticeManager(this);

        // Register commands
        SeiHubCommand seiHubCmd = new SeiHubCommand(this);
        getCommand("seihub").setExecutor(seiHubCmd);
        getCommand("seihub").setTabCompleter(seiHubCmd);

        SmpRestartCommand smpRestartCmd = new SmpRestartCommand(this);
        getCommand("smprestart").setExecutor(smpRestartCmd);
        getCommand("smprestart").setTabCompleter(smpRestartCmd);

        RestartCommand restartCmd = new RestartCommand(this);
        getCommand("restart").setExecutor(restartCmd);
        getCommand("restart").setTabCompleter(restartCmd);

        // Register BungeeCord/Velocity plugin messaging channel
        // ใช้สำหรับส่งข้อความแจ้ง Lobby ว่า SMP กำลัง restart
        Messenger messenger = getServer().getMessenger();
        messenger.registerOutgoingPluginChannel(this, "BungeeCord");
        messenger.registerIncomingPluginChannel(this, "BungeeCord", new PluginMessageListener(this));

        // Start auto-restart monitor
        if (getConfig().getBoolean("auto-restart.enabled", true)) {
            autoRestartManager.start();
        }

        getLogger().info("=================================");
        getLogger().info("  SeiHub Plugin v" + getDescription().getVersion() + " enabled!");
        getLogger().info("  Restart method: " + getConfig().getString("restart-method", "shutdown"));
        getLogger().info("=================================");
    }

    @Override
    public void onDisable() {
        // Cancel all pending restarts
        if (restartManager != null) {
            restartManager.cancelAll();
        }
        if (autoRestartManager != null) {
            autoRestartManager.stop();
        }
        if (restartNoticeManager != null) {
            restartNoticeManager.cancelAll();
        }

        // Unregister channels
        getServer().getMessenger().unregisterIncomingPluginChannel(this);
        getServer().getMessenger().unregisterOutgoingPluginChannel(this);

        getLogger().info("SeiHub Plugin disabled.");
    }

    public static SeiHubPlugin getInstance() {
        return instance;
    }

    public RestartManager getRestartManager() {
        return restartManager;
    }

    public RestartNoticeManager getRestartNoticeManager() {
        return restartNoticeManager;
    }

    public AutoRestartManager getAutoRestartManager() {
        return autoRestartManager;
    }
}
