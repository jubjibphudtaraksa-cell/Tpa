package com.seihub.seihubplugin.managers;

import com.seihub.seihubplugin.SeiHubPlugin;
import com.seihub.seihubplugin.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ทำงานฝั่ง Lobby: บอกผู้เล่นว่า server ที่ restart เหลืออีกกี่นาที
 * และแจ้งเมื่อ restart เสร็จ (เช็คจาก TCP port ของ server นั้น)
 */
public class RestartNoticeManager {

    private final SeiHubPlugin plugin;
    private final Map<String, BukkitTask> tasks = new ConcurrentHashMap<>();

    public RestartNoticeManager(SeiHubPlugin plugin) {
        this.plugin = plugin;
    }

    public void start(String serverName, int etaSeconds) {
        String key = serverName.toLowerCase();
        cancel(key);

        String host = plugin.getConfig().getString("server-addresses." + key + ".host", "127.0.0.1");
        int port = plugin.getConfig().getInt("server-addresses." + key + ".port", -1);
        boolean canPing = port > 0;
        int interval = Math.max(10, plugin.getConfig().getInt("restart-notice-interval", 60));
        String name = serverName.toUpperCase();

        say("messages.restart-lobby-start",
                "&c[SeiHub] &e{server} &cกำลังรีสตาร์ท &7— คาดว่าเสร็จใน &6~{minutes} นาที",
                name, etaSeconds);

        BukkitTask task = new BukkitRunnable() {
            int elapsed = 0;
            boolean wentDown = false;
            boolean slowSent = false;

            @Override
            public void run() {
                elapsed += 5;
                int remaining = Math.max(0, etaSeconds - elapsed);

                if (canPing) {
                    boolean up = isOpen(host, port);
                    if (!up) wentDown = true;

                    if (wentDown && up) {
                        say("messages.restart-lobby-done",
                                "&a[SeiHub] &e{server} &aรีสตาร์ทเสร็จแล้ว! เข้าเล่นได้เลย",
                                name, 0);
                        finish();
                        return;
                    }
                    // server ไม่เคยปิดเลย = restart ไม่เกิดขึ้น (เช่นถูกยกเลิก)
                    if (!wentDown && elapsed >= 60) {
                        finish();
                        return;
                    }
                } else if (elapsed >= etaSeconds) {
                    say("messages.restart-lobby-done",
                            "&a[SeiHub] &e{server} &aรีสตาร์ทเสร็จแล้ว! เข้าเล่นได้เลย",
                            name, 0);
                    finish();
                    return;
                }

                if (remaining > 0 && elapsed % interval == 0) {
                    say("messages.restart-lobby-remaining",
                            "&e[SeiHub] &f{server} &7เหลืออีกประมาณ &6{minutes} นาที",
                            name, remaining);
                } else if (remaining == 0 && !slowSent) {
                    slowSent = true;
                    say("messages.restart-lobby-slow",
                            "&e[SeiHub] &f{server} &7ใช้เวลานานกว่าปกติเล็กน้อย รอสักครู่...",
                            name, 0);
                }

                // เลิกรอถ้านานเกิน 15 นาที
                if (elapsed >= 900) finish();
            }

            private void finish() {
                tasks.remove(key);
                cancel();
            }
        }.runTaskTimerAsynchronously(plugin, 100L, 100L); // เช็คทุก 5 วินาที

        tasks.put(key, task);
    }

    public void cancel(String key) {
        BukkitTask t = tasks.remove(key.toLowerCase());
        if (t != null) t.cancel();
    }

    public void cancelAll() {
        for (BukkitTask t : tasks.values()) t.cancel();
        tasks.clear();
    }

    private boolean isOpen(String host, int port) {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), 1000);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** broadcast ใน main thread — {minutes} = ปัดวินาทีขึ้นเป็นนาที (อย่างน้อย 1) */
    private void say(String path, String def, String server, int seconds) {
        int minutes = Math.max(1, (int) Math.ceil(seconds / 60.0));
        String msg = plugin.getConfig().getString(path, def)
                .replace("{server}", server)
                .replace("{minutes}", String.valueOf(minutes));
        String colored = MessageUtil.color(msg);
        Bukkit.getScheduler().runTask(plugin, () -> Bukkit.broadcastMessage(colored));
    }
}
