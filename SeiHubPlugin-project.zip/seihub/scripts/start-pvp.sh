#!/bin/bash
# ============================================
# start-pvp.sh — Wrapper script สำหรับ PvP
# ============================================
JAR_NAME="paper-1.21.1.jar"
MEMORY="2G"
SERVER_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[SeiHub] Starting PvP server..."

while true; do
    echo "[SeiHub] PvP starting at $(date)"
    cd "$SERVER_DIR"
    java -Xms512M -Xmx${MEMORY} \
         -XX:+UseG1GC \
         -XX:+ParallelRefProcEnabled \
         -XX:MaxGCPauseMillis=200 \
         -XX:+UnlockExperimentalVMOptions \
         -XX:+DisableExplicitGC \
         -jar "$JAR_NAME" --nogui

    EXIT_CODE=$?
    echo "[SeiHub] PvP stopped with exit code: $EXIT_CODE at $(date)"

    if [ $EXIT_CODE -ne 0 ]; then
        echo "[SeiHub] Server crashed! Waiting 10 seconds before restart..."
        sleep 10
    else
        echo "[SeiHub] Restarting in 3 seconds..."
        sleep 3
    fi
done
