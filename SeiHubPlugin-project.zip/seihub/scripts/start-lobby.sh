#!/bin/bash
# ============================================
# start-lobby.sh — Wrapper script สำหรับ Lobby
# NOTE: Lobby จะไม่ถูก auto-restart จากปลั๊กอิน
#       แต่ wrapper script ยังวนลูปได้ถ้า crash
# ============================================
JAR_NAME="paper-1.21.1.jar"
MEMORY="2G"
SERVER_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[SeiHub] Starting Lobby server..."

while true; do
    echo "[SeiHub] Lobby starting at $(date)"
    cd "$SERVER_DIR"
    java -Xms512M -Xmx${MEMORY} \
         -XX:+UseG1GC \
         -XX:+ParallelRefProcEnabled \
         -XX:MaxGCPauseMillis=200 \
         -XX:+UnlockExperimentalVMOptions \
         -XX:+DisableExplicitGC \
         -jar "$JAR_NAME" --nogui

    EXIT_CODE=$?
    echo "[SeiHub] Lobby stopped with exit code: $EXIT_CODE at $(date)"

    # Lobby restart เมื่อ crash เท่านั้น
    if [ $EXIT_CODE -ne 0 ]; then
        echo "[SeiHub] Lobby crashed! Waiting 5 seconds before restart..."
        sleep 5
    else
        # shutdown ปกติ — รอนานกว่าเพื่อให้ admin สั่งได้
        echo "[SeiHub] Lobby shutdown. Restarting in 5 seconds..."
        sleep 5
    fi
done
