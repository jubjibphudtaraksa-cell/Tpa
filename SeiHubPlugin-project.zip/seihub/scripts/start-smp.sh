#!/bin/bash
# ============================================
# start-smp.sh — Wrapper script สำหรับ SMP
# วางไฟล์นี้ไว้ในโฟลเดอร์ SMP server
# ============================================
# วิธีใช้: เปลี่ยน JAR_NAME และ MEMORY ตามต้องการ
# แล้ว chmod +x start-smp.sh && ./start-smp.sh

JAR_NAME="paper-1.21.1.jar"
MEMORY="4G"
SERVER_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[SeiHub] Starting SMP server..."

# วนลูปไม่สิ้นสุด — เมื่อ server ปิดตัว (shutdown) จะกลับขึ้นมา restart
while true; do
    echo "[SeiHub] SMP starting at $(date)"
    cd "$SERVER_DIR"
    java -Xms512M -Xmx${MEMORY} \
         -XX:+UseG1GC \
         -XX:+ParallelRefProcEnabled \
         -XX:MaxGCPauseMillis=200 \
         -XX:+UnlockExperimentalVMOptions \
         -XX:+DisableExplicitGC \
         -XX:+AlwaysPreTouch \
         -XX:G1NewSizePercent=30 \
         -XX:G1MaxNewSizePercent=40 \
         -XX:G1HeapRegionSize=8M \
         -XX:G1ReservePercent=20 \
         -XX:G1HeapWastePercent=5 \
         -XX:G1MixedGCCountTarget=4 \
         -XX:InitiatingHeapOccupancyPercent=15 \
         -XX:G1MixedGCLiveThresholdPercent=90 \
         -XX:G1RSetUpdatingPauseTimePercent=5 \
         -XX:SurvivorRatio=32 \
         -XX:+PerfDisableSharedMem \
         -XX:MaxTenuringThreshold=1 \
         --add-opens java.base/sun.nio.ch=ALL-UNNAMED \
         -Dusing.aikars.flags=https://mcflags.emc.gs \
         -Daikars.new.flags=true \
         -jar "$JAR_NAME" --nogui

    EXIT_CODE=$?
    echo "[SeiHub] SMP stopped with exit code: $EXIT_CODE at $(date)"

    # ถ้า exit code ไม่ใช่ 0 อาจเป็น crash — รอก่อน restart
    if [ $EXIT_CODE -ne 0 ]; then
        echo "[SeiHub] Server crashed! Waiting 10 seconds before restart..."
        sleep 10
    else
        echo "[SeiHub] Restarting in 3 seconds..."
        sleep 3
    fi
done
