package hub.fiatx2.tpa;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class TpaPlugin extends JavaPlugin {

    private record Req(UUID from, boolean here) {}

    // target -> request
    private final Map<UUID, Req> requests = new HashMap<>();
    private final Map<UUID, BukkitTask> timers = new HashMap<>();
    private final Set<UUID> counting = new HashSet<>();

    private SettingsGui settings;
    private HomeGui homes;

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(new SpawnProtect(), this);
        settings = new SettingsGui(this);
        getServer().getPluginManager().registerEvents(settings, this);
        homes = new HomeGui(this);
        getServer().getPluginManager().registerEvents(homes, this);
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (!(s instanceof Player p)) {
            s.sendMessage("เฉพาะผู้เล่นเท่านั้น");
            return true;
        }
        switch (cmd.getName().toLowerCase()) {
            case "tpa" -> sendRequest(p, args, false);
            case "tpahere" -> sendRequest(p, args, true);
            case "tpaccept" -> handleAccept(p);
            case "tpdeny" -> handleDeny(p);
            case "spawn" -> startSpawn(p);
            case "settings" -> settings.open(p);
            case "sethome" -> homes.setHome(p, args);
            case "home" -> homes.open(p);
        }
        return true;
    }

    // ---------------- TPA / TPAHERE ----------------

    private void sendRequest(Player p, String[] args, boolean here) {
        String usage = here ? "/tpahere" : "/tpa";
        if (args.length != 1) {
            p.sendMessage(Component.text("ใช้: " + usage + " <ชื่อผู้เล่น>", NamedTextColor.RED));
            return;
        }
        Player t = Bukkit.getPlayerExact(args[0]);
        if (t == null || !t.isOnline()) {
            p.sendMessage(Component.text("ไม่พบผู้เล่นคนนี้", NamedTextColor.RED));
            return;
        }
        if (t.equals(p)) {
            p.sendMessage(Component.text("ขอตัวเองไม่ได้", NamedTextColor.RED));
            return;
        }

        UUID tid = t.getUniqueId();
        clear(tid);
        requests.put(tid, new Req(p.getUniqueId(), here));
        timers.put(tid, Bukkit.getScheduler().runTaskLater(this, () -> {
            requests.remove(tid);
            timers.remove(tid);
            if (p.isOnline()) p.sendMessage(Component.text("คำขอหมดอายุ", NamedTextColor.GRAY));
        }, 20L * 60));

        p.sendMessage(Component.text("ส่งคำขอไปหา " + t.getName() + " แล้ว", NamedTextColor.GREEN));

        Component accept = Component.text("[ตกลง]", NamedTextColor.GREEN, TextDecoration.BOLD)
                .clickEvent(ClickEvent.runCommand("/tpaccept"))
                .hoverEvent(HoverEvent.showText(Component.text("คลิกเพื่อตกลง")));
        Component deny = Component.text("[ปฏิเสธ]", NamedTextColor.RED, TextDecoration.BOLD)
                .clickEvent(ClickEvent.runCommand("/tpdeny"))
                .hoverEvent(HoverEvent.showText(Component.text("คลิกเพื่อปฏิเสธ")));

        String text = here ? " ได้ขอให้คุณ TP ไปหาเขา" : " ได้ขอ TP มาหาคุณ";

        t.sendMessage(Component.empty());
        t.sendMessage(Component.text(p.getName(), NamedTextColor.YELLOW, TextDecoration.BOLD)
                .append(Component.text(text, NamedTextColor.WHITE)));
        t.sendMessage(Component.text("⚠ คำเตือน: อาจเป็นกับดัก!", NamedTextColor.RED, TextDecoration.BOLD));
        t.sendMessage(accept.append(Component.text("  ")).append(deny));
        // สำหรับ Bedrock ที่กดปุ่มในแชทไม่ได้
        t.sendMessage(Component.text("พิมพ์ ", NamedTextColor.GRAY)
                .append(Component.text("/tpaccept", NamedTextColor.GREEN, TextDecoration.BOLD))
                .append(Component.text(" เพื่อตกลง | ", NamedTextColor.GRAY))
                .append(Component.text("/tpdeny", NamedTextColor.RED, TextDecoration.BOLD))
                .append(Component.text(" เพื่อปฏิเสธ", NamedTextColor.GRAY)));
        t.sendMessage(Component.empty());

        t.playSound(t.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
    }

    private void handleAccept(Player t) {
        Req req = requests.get(t.getUniqueId());
        if (req == null) {
            t.sendMessage(Component.text("ไม่มีคำขอ", NamedTextColor.RED));
            return;
        }
        clear(t.getUniqueId());
        Player r = Bukkit.getPlayer(req.from());
        if (r == null) {
            t.sendMessage(Component.text("ผู้ขอออฟไลน์แล้ว", NamedTextColor.RED));
            return;
        }
        r.sendMessage(Component.text(t.getName() + " ตกลงแล้ว", NamedTextColor.GREEN));
        t.sendMessage(Component.text("ตกลงคำขอแล้ว", NamedTextColor.GREEN));

        if (req.here()) {
            startCountdown(t, r); // t ถูกดึงไปหา r
        } else {
            r.teleportAsync(t.getLocation());
        }
    }

    private void handleDeny(Player t) {
        Req req = requests.get(t.getUniqueId());
        if (req == null) {
            t.sendMessage(Component.text("ไม่มีคำขอ", NamedTextColor.RED));
            return;
        }
        clear(t.getUniqueId());
        Player r = Bukkit.getPlayer(req.from());
        if (r != null) r.sendMessage(Component.text(t.getName() + " ปฏิเสธคำขอ", NamedTextColor.RED));
        t.sendMessage(Component.text("ปฏิเสธคำขอแล้ว", NamedTextColor.YELLOW));
    }

    private void clear(UUID target) {
        requests.remove(target);
        BukkitTask task = timers.remove(target);
        if (task != null) task.cancel();
    }

    // ---------------- countdown (tpahere) ----------------

    private void startCountdown(Player mover, Player dest) {
        UUID mid = mover.getUniqueId();
        if (!counting.add(mid)) return;

        Location start = mover.getLocation();
        mover.sendMessage(Component.text("อย่าขยับ! กำลังวาป...", NamedTextColor.YELLOW));

        new BukkitRunnable() {
            int sec = 3;

            @Override
            public void run() {
                if (!mover.isOnline() || !dest.isOnline()) {
                    stop();
                    return;
                }
                Location now = mover.getLocation();
                if (!now.getWorld().equals(start.getWorld()) || now.distanceSquared(start) > 0.1) {
                    mover.sendMessage(Component.text("ยกเลิกการวาป เพราะคุณขยับ", NamedTextColor.RED));
                    dest.sendMessage(Component.text(mover.getName() + " ขยับ การวาปถูกยกเลิก", NamedTextColor.RED));
                    stop();
                    return;
                }
                if (sec > 0) {
                    mover.sendMessage(Component.text(String.valueOf(sec), NamedTextColor.YELLOW, TextDecoration.BOLD));
                    mover.playSound(now, org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.2f);
                    sec--;
                    return;
                }
                stop();
                mover.teleportAsync(dest.getLocation());
            }

            private void stop() {
                counting.remove(mid);
                cancel();
            }
        }.runTaskTimer(this, 0L, 20L);
    }

    // ---------------- /spawn ----------------

    private void startSpawn(Player p) {
        UUID pid = p.getUniqueId();
        if (!counting.add(pid)) {
            p.sendMessage(Component.text("กำลังนับถอยหลังอยู่แล้ว", NamedTextColor.RED));
            return;
        }

        Location start = p.getLocation();
        Location spawn = new Location(Bukkit.getWorlds().get(0), 474.5, 90, 1077.5);
        p.sendMessage(Component.text("อย่าขยับ! กำลังวาปไปสปอน...", NamedTextColor.YELLOW));

        new BukkitRunnable() {
            int sec = 5;

            @Override
            public void run() {
                if (!p.isOnline()) {
                    stop();
                    return;
                }
                Location now = p.getLocation();
                if (!now.getWorld().equals(start.getWorld()) || now.distanceSquared(start) > 0.1) {
                    p.sendMessage(Component.text("ยกเลิกการวาป เพราะคุณขยับ", NamedTextColor.RED));
                    stop();
                    return;
                }
                if (sec > 0) {
                    p.sendMessage(Component.text(String.valueOf(sec), NamedTextColor.YELLOW, TextDecoration.BOLD));
                    p.playSound(now, org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.2f);
                    sec--;
                    return;
                }
                stop();
                p.teleportAsync(spawn);
            }

            private void stop() {
                counting.remove(pid);
                cancel();
            }
        }.runTaskTimer(this, 0L, 20L);
    }

    // ---------------- tab complete ----------------

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] args) {
        String n = cmd.getName().toLowerCase();
        if ((n.equals("tpa") || n.equals("tpahere")) && args.length == 1) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(x -> x.toLowerCase().startsWith(args[0].toLowerCase())).toList();
        }
        return List.of();
    }
}
