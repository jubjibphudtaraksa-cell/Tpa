package hub.fiatx2.tpa;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class HomeGui implements Listener {

    private enum Type { MAIN, CONFIRM }

    private static class Holder implements InventoryHolder {
        final Type type;
        final int slot;
        Inventory inv;

        Holder(Type type, int slot) {
            this.type = type;
            this.slot = slot;
        }

        @Override
        public @NotNull Inventory getInventory() { return inv; }
    }

    private static final int[] BED = {11, 13, 15};
    private static final int[] DYE = {20, 22, 24};

    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration data;
    private final Map<UUID, Integer> renaming = new HashMap<>();

    public HomeGui(JavaPlugin plugin) {
        this.plugin = plugin;
        plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "homes.yml");
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    // ---------- data ----------
    private boolean has(UUID id, int i) { return data.contains(id + "." + i + ".name"); }

    private String name(UUID id, int i) { return data.getString(id + "." + i + ".name", ""); }

    private Location loc(UUID id, int i) {
        String b = id + "." + i;
        World w = Bukkit.getWorld(data.getString(b + ".world", ""));
        if (w == null) return null;
        return new Location(w, data.getDouble(b + ".x"), data.getDouble(b + ".y"), data.getDouble(b + ".z"),
                (float) data.getDouble(b + ".yaw"), (float) data.getDouble(b + ".pitch"));
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("save failed: " + ex.getMessage());
        }
    }

    // ---------- /sethome ----------
    public void setHome(Player p, String[] args) {
        if (args.length == 0) {
            p.sendMessage(Component.text("ใช้: /sethome <ชื่อ>", NamedTextColor.RED));
            return;
        }
        String name = String.join(" ", args).trim();
        if (name.length() > 16) {
            p.sendMessage(Component.text("ชื่อยาวเกิน 16 ตัวอักษร", NamedTextColor.RED));
            return;
        }
        UUID id = p.getUniqueId();
        int slot = -1;
        for (int i = 0; i < 3; i++) if (has(id, i) && name(id, i).equalsIgnoreCase(name)) slot = i;
        if (slot < 0) for (int i = 0; i < 3; i++) if (!has(id, i)) { slot = i; break; }
        if (slot < 0) {
            p.sendMessage(Component.text("บ้านเต็ม 3 หลังแล้ว ลบอันเก่าใน /home ก่อน", NamedTextColor.RED));
            return;
        }
        Location l = p.getLocation();
        String b = id + "." + slot;
        data.set(b + ".name", name);
        data.set(b + ".world", l.getWorld().getName());
        data.set(b + ".x", l.getX());
        data.set(b + ".y", l.getY());
        data.set(b + ".z", l.getZ());
        data.set(b + ".yaw", l.getYaw());
        data.set(b + ".pitch", l.getPitch());
        save();
        p.sendMessage(Component.text("ตั้งบ้าน \"" + name + "\" แล้ว", NamedTextColor.GREEN));
    }

    // ---------- GUI ----------
    private ItemStack item(Material m, Component name, List<Component> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        if (lore != null) {
            meta.lore(lore.stream().map(c -> c.decoration(TextDecoration.ITALIC, false)).toList());
        }
        it.setItemMeta(meta);
        return it;
    }

    private Component t(String s, NamedTextColor c) { return Component.text(s, c); }

    public void open(Player p) {
        UUID id = p.getUniqueId();
        Holder h = new Holder(Type.MAIN, -1);
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("Homes | Menu", NamedTextColor.DARK_GRAY));
        h.inv = inv;
        for (int i = 0; i < 3; i++) {
            if (has(id, i)) {
                inv.setItem(BED[i], item(Material.RED_BED,
                        Component.text(name(id, i), NamedTextColor.RED, TextDecoration.BOLD),
                        List.of(t("คลิกเพื่อวาป", NamedTextColor.GRAY))));
                inv.setItem(DYE[i], item(Material.RED_DYE,
                        t("จัดการบ้าน", NamedTextColor.RED),
                        List.of(t("คลิกซ้าย: เปลี่ยนชื่อ", NamedTextColor.YELLOW),
                                t("คลิกขวา: ลบ", NamedTextColor.YELLOW))));
            } else {
                inv.setItem(BED[i], item(Material.WHITE_BED,
                        t("ยังไม่ได้ตั้ง", NamedTextColor.WHITE),
                        List.of(t("ใช้ /sethome <ชื่อ>", NamedTextColor.GRAY))));
                inv.setItem(DYE[i], item(Material.WHITE_DYE,
                        t("ว่าง", NamedTextColor.WHITE), null));
            }
        }
        p.openInventory(inv);
    }

    private void openConfirm(Player p, int slot) {
        Holder h = new Holder(Type.CONFIRM, slot);
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("ยืนยันการลบ", NamedTextColor.DARK_RED));
        h.inv = inv;
        inv.setItem(11, item(Material.RED_CONCRETE,
                Component.text("ยกเลิก", NamedTextColor.RED, TextDecoration.BOLD), null));
        inv.setItem(13, item(Material.RED_BED,
                Component.text(name(p.getUniqueId(), slot), NamedTextColor.RED), null));
        inv.setItem(15, item(Material.LIME_CONCRETE,
                Component.text("ยืนยันลบ", NamedTextColor.GREEN, TextDecoration.BOLD), null));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getView().getTopInventory())) return;
        UUID id = p.getUniqueId();
        int raw = e.getRawSlot();

        if (h.type == Type.MAIN) {
            for (int i = 0; i < 3; i++) {
                if (raw == BED[i] && has(id, i)) {
                    Location l = loc(id, i);
                    p.closeInventory();
                    if (l == null) {
                        p.sendMessage(Component.text("ไม่พบโลกของบ้านนี้", NamedTextColor.RED));
                    } else {
                        p.sendMessage(Component.text("กำลังวาปไป " + name(id, i), NamedTextColor.GREEN));
                        ((TpaPlugin) plugin).countdownTeleport(p, () -> l, null);
                    }
                    return;
                }
                if (raw == DYE[i] && has(id, i)) {
                    if (e.isLeftClick()) {
                        p.closeInventory();
                        renaming.put(id, i);
                        p.sendMessage(Component.text("พิมพ์ชื่อใหม่ในแชท (พิมพ์ cancel เพื่อยกเลิก)", NamedTextColor.YELLOW));
                    } else if (e.isRightClick()) {
                        openConfirm(p, i);
                    }
                    return;
                }
            }
        } else {
            if (raw == 11) {
                open(p);
            } else if (raw == 15) {
                data.set(id + "." + h.slot, null);
                save();
                p.sendMessage(Component.text("ลบบ้านแล้ว", NamedTextColor.YELLOW));
                open(p);
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    // ---------- rename via chat ----------
    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        Integer slot = renaming.remove(p.getUniqueId());
        if (slot == null) return;
        e.setCancelled(true);
        String msg = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
        Bukkit.getScheduler().runTask(plugin, () -> {
            UUID id = p.getUniqueId();
            if (msg.equalsIgnoreCase("cancel")) {
                p.sendMessage(Component.text("ยกเลิกแล้ว", NamedTextColor.GRAY));
            } else if (msg.isEmpty() || msg.length() > 16) {
                p.sendMessage(Component.text("ชื่อต้องยาว 1-16 ตัวอักษร", NamedTextColor.RED));
            } else if (has(id, slot)) {
                data.set(id + "." + slot + ".name", msg);
                save();
                p.sendMessage(Component.text("เปลี่ยนชื่อเป็น \"" + msg + "\" แล้ว", NamedTextColor.GREEN));
            }
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { renaming.remove(e.getPlayer().getUniqueId()); }
}
