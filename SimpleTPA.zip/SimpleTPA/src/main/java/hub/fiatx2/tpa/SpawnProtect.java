package hub.fiatx2.tpa;

import io.papermc.paper.event.entity.EntityMoveEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Phantom;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Slime;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.time.Duration;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class SpawnProtect implements Listener {

    private static final String BYPASS = "simpletpa.bypass";
    private static final int MIN_X = 456, MAX_X = 490;
    private static final int MIN_Y = -60, MAX_Y = 228;
    private static final int MIN_Z = 1055, MAX_Z = 1101;

    private final Set<UUID> inside = new HashSet<>();
    private final Set<UUID> firstTimers = new HashSet<>();

    private boolean in(Location l) {
        if (l == null || l.getWorld() == null) return false;
        if (!l.getWorld().equals(Bukkit.getWorlds().get(0))) return false;
        int x = l.getBlockX(), y = l.getBlockY(), z = l.getBlockZ();
        return x >= MIN_X && x <= MAX_X && y >= MIN_Y && y <= MAX_Y && z >= MIN_Z && z <= MAX_Z;
    }

    private boolean blocked(Player p, Location l) {
        return in(l) && !p.hasPermission(BYPASS);
    }

    // ---------------- titles ----------------

    private void title(Player p, String main, NamedTextColor c, String sub) {
        p.showTitle(Title.title(
                Component.text(main, c, TextDecoration.BOLD),
                Component.text(sub, NamedTextColor.GRAY),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(500))));
    }

    private void enter(Player p) {
        if (firstTimers.remove(p.getUniqueId())) {
            title(p, "Welcome To Vortex SMP", NamedTextColor.AQUA, "");
        } else {
            title(p, "เขตปลอดภัย", NamedTextColor.GREEN, "");
        }
    }

    private void track(Player p, Location to) {
        boolean nowIn = in(to);
        boolean wasIn = inside.contains(p.getUniqueId());
        if (nowIn && !wasIn) {
            inside.add(p.getUniqueId());
            enter(p);
        } else if (!nowIn && wasIn) {
            inside.remove(p.getUniqueId());
            title(p, "ตายของตก", NamedTextColor.RED, "คุณออกจากเขตปลอดภัยแล้ว");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        Location to = e.getTo();
        Location from = e.getFrom();
        if (from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY()
                || from.getBlockZ() != to.getBlockZ()) {
            track(p, to);
        }
        if (p.isGliding() && blocked(p, to)) p.setGliding(false);
    }

    // PlayerTeleportEvent ไม่เข้า PlayerMoveEvent handler ต้องดักแยก
    @EventHandler(ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        track(e.getPlayer(), e.getTo());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!p.hasPlayedBefore()) firstTimers.add(p.getUniqueId());
        if (in(p.getLocation())) {
            inside.add(p.getUniqueId());
            enter(p);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        inside.remove(e.getPlayer().getUniqueId());
        firstTimers.remove(e.getPlayer().getUniqueId());
    }

    // ---------------- protection ----------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (blocked(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (blocked(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (blocked(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    // ตี (รวมโพรเจกไทล์)
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        Entity d = e.getDamager();
        if (d instanceof Projectile pr && pr.getShooter() instanceof Entity s) d = s;
        if (d instanceof Player p && !p.hasPermission(BYPASS)
                && (in(p.getLocation()) || in(e.getEntity().getLocation()))) {
            e.setCancelled(true);
        }
    }

    // จุดพลุ
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (!blocked(p, p.getLocation())) return;
        Material main = p.getInventory().getItemInMainHand().getType();
        Material off = p.getInventory().getItemInOffHand().getType();
        if (main == Material.FIREWORK_ROCKET || off == Material.FIREWORK_ROCKET) {
            e.setUseItemInHand(Event.Result.DENY);
            e.setCancelled(true);
        }
    }

    // ปีก
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onGlide(EntityToggleGlideEvent e) {
        if (e.isGliding() && e.getEntity() instanceof Player p && blocked(p, p.getLocation())) {
            e.setCancelled(true);
        }
    }


    // ---------------- mobs ----------------

    private boolean hostile(Entity en) {
        return en instanceof Monster || en instanceof Slime || en instanceof Phantom;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMobSpawn(CreatureSpawnEvent e) {
        if (!hostile(e.getEntity()) || !in(e.getLocation())) return;
        CreatureSpawnEvent.SpawnReason r = e.getSpawnReason();
        if (r == CreatureSpawnEvent.SpawnReason.CUSTOM || r == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG) return;
        e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onMobMove(EntityMoveEvent e) {
        if (!e.hasChangedBlock()) return;
        if (!hostile(e.getEntity())) return;
        if (in(e.getTo()) && !in(e.getFrom())) e.setCancelled(true);
    }
}
