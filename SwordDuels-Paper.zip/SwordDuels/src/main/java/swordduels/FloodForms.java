package swordduels;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.CustomForm;
import org.geysermc.floodgate.api.FloodgateApi;

/** แยกคลาสนี้ไว้ เพื่อให้ปลั๊กอินยังรันได้แม้ไม่มี Floodgate */
final class FloodForms {
	private FloodForms() {}

	static boolean isBedrock(Player p) {
		return FloodgateApi.getInstance().isFloodgatePlayer(p.getUniqueId());
	}

	static void sendDuel(Main plugin, Player p, Player target, List<String> names, Main.DuelCallback cb) {
		CustomForm.Builder b = CustomForm.builder().title("§6Duel Settings");
		if (target != null) {
			b.label("§f" + p.getName() + " vs " + target.getName());
			b.label("Kit: §bSword");
		} else {
			b.label("Kit: §bSword");
			b.dropdown("Opponent:", names.toArray(new String[0]));
		}
		b.slider("Rounds", 1, Main.MAX_ROUNDS, 1, 1);
		b.dropdown("Please select an option:", "Send Duel", "Cancel");

		b.validResultHandler(r -> {
			String opp = null;
			if (target == null) {
				opp = names.get(r.asDropdown());
			}
			int rounds = (int) r.asSlider();
			int option = r.asDropdown(); // 0 = Send Duel, 1 = Cancel
			if (option != 0) return;
			final String o = opp;
			Bukkit.getScheduler().runTask(plugin, () -> cb.accept(p, o, rounds));
		});

		FloodgateApi.getInstance().sendForm(p.getUniqueId(), b.build());
	}

	static void sendFind(Main plugin, Player p, Main.DuelCallback cb) {
		CustomForm.Builder b = CustomForm.builder().title("§6Duel Settings");
		b.label("§f" + p.getName() + " vs ???");
		b.label("Kit: §bSword");
		b.slider("Rounds", 1, Main.MAX_ROUNDS, 1, 1);
		b.dropdown("Please select an option:", "Find Match", "Cancel");

		b.validResultHandler(r -> {
			int rounds = (int) r.asSlider();
			int option = r.asDropdown(); // 0 = Find Match, 1 = Cancel
			if (option != 0) return;
			Bukkit.getScheduler().runTask(plugin, () -> cb.accept(p, null, rounds));
		});

		FloodgateApi.getInstance().sendForm(p.getUniqueId(), b.build());
	}
}
