package swordduels;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

public final class Main extends JavaPlugin implements Listener {

	// ====== ตั้งค่า ======
	static final String LOBBY = "lp";        // โลกล็อบบี้
	static final String ARENA = "sworld1";   // โลกสนามดวล (Sword)
	static final double[] SPAWN_A = {137.5, 61, 44.5};  // 137 61 44 (หันไป +z)
	static final double[] SPAWN_B = {137.5, 61, 98.5};  // 137 61 98 (หันไป -z)

	// สนาม Crystal PvP: ทุกคู่ใช้พิกัดชุดนี้ร่วมกัน (โลกเดียวกัน) แต่แยกกันเด็ดขาด
	static final String CRYSTAL_ARENA = "cy1";
	static final double[] CRYSTAL_SPAWN_A = {-886.5, 64, -689.5};  // -887 64 -690 (หันไป -x)
	static final double[] CRYSTAL_SPAWN_B = {-920.5, 64, -689.5};  // -921 64 -690 (หันไป +x)
	static final float CRYSTAL_YAW_A = 90f, CRYSTAL_YAW_B = -90f;
	static final boolean CRATERS = true;        // ระเบิดแล้วพื้น/บล็อกเดิมของสนามเป็นหลุมด้วย (false = พังเฉพาะบล็อกที่ผู้เล่นวาง)
	static final boolean GIVE_OBSIDIAN = true;  // แจก obsidian ให้วางฐานคริสตัล
	static final int MAX_FAKE_BLOCKS = 4000;    // จำกัดจำนวนบล็อกที่วาง/พังต่อตา
	static final int MAX_CRYSTAL_STACKS = 8;

	static final int QUEUE_WINS = 3;         // ดาบเพชร: ชนะ 3 ตาก่อน
	static final int IRON_WINS = 2;          // ดาบเหล็ก: 2 ใน 3 ตา (ปรับไม่ได้)
	static final int MAX_ROUNDS = 20;
	static final int INVITE_SECONDS = 60;

	// ช่องในเมนู Select a Kit
	static final int BOOK_SLOT = 9;          // สมุด = Kit Editor
	static final int KIT_SLOT = 10;          // ดาบ
	static final int CRYSTAL_SLOT = 11;      // คริสตัล

	// ช่องปุ่มใน Kit Editor
	static final int ED_ROOM = 3;            // ธงเขียว  -> Kit Room
	static final int ED_OK = 4;              // ธงม่วง   -> ตกลง (บันทึก)
	static final int ED_CANCEL = 5;          // ธงแดง    -> ยกเลิก
	static final int ED_RESET = 6;           // ธงส้ม    -> รีเซต
	// =====================

	public interface DuelCallback { void accept(Player p, String opponentName, int rounds); }

	record Invite(UUID from, int rounds, boolean crystal, long time) {}
	record QEntry(Player player, int rounds, boolean crystal) {}
	record Cell(int x, int y, int z, BlockData data) {}

	static final class Match {
		final Player a, b;
		final int target;
		final boolean crystal;
		final int[] score = new int[2];
		/** บล็อก "ปลอม" ของคู่นี้ (วาง/พัง) — ส่งให้ 2 คนนี้เท่านั้น ไม่แตะโลกจริง */
		final Map<Long, Cell> fake = new HashMap<>();
		final Set<EnderCrystal> crystals = new HashSet<>();
		int round, token;
		boolean live, ended;
		Match(Player a, Player b, int target, boolean crystal) { this.a = a; this.b = b; this.target = target; this.crystal = crystal; }
		Player other(Player p) { return p == a ? b : a; }
		int idx(Player p) { return p == a ? 0 : 1; }
	}

	static final class KitMenu implements InventoryHolder {
		final String mode; final UUID target; Inventory inv;
		KitMenu(String mode, UUID target) { this.mode = mode; this.target = target; }
		@Override public Inventory getInventory() { return inv; }
	}

	static final class RoundsMenu implements InventoryHolder {
		final UUID target; final boolean crystal; Inventory inv;
		RoundsMenu(UUID target, boolean crystal) { this.target = target; this.crystal = crystal; }
		@Override public Inventory getInventory() { return inv; }
	}

	static final class PickMenu implements InventoryHolder {
		final Map<Integer, UUID> slots = new HashMap<>(); Inventory inv;
		@Override public Inventory getInventory() { return inv; }
	}

	/** เซสชันแก้ Kit (ทำงานบนสำเนา จนกว่าจะกดตกลง) */
	static final class EditSession {
		final String[] work; final String mode; final UUID target; int selected = -1;
		EditSession(String[] work, String mode, UUID target) { this.work = work; this.mode = mode; this.target = target; }
	}

	static final class EditorMenu implements InventoryHolder {
		final EditSession s; Inventory inv;
		EditorMenu(EditSession s) { this.s = s; }
		@Override public Inventory getInventory() { return inv; }
	}

	static final class RoomMenu implements InventoryHolder {
		final EditSession s; Inventory inv;
		RoomMenu(EditSession s) { this.s = s; }
		@Override public Inventory getInventory() { return inv; }
	}

	private NamespacedKey itemKey;
	private boolean floodgate;
	private boolean internalDamage;   // true ตอนเราสั่งดาเมจระเบิดเอง
	private File kitFile;
	private final Map<UUID, QEntry> queue = new LinkedHashMap<>();
	private final Map<UUID, Invite> invites = new HashMap<>();
	private final Map<UUID, Match> matches = new HashMap<>();
	private final Map<UUID, Long> lastUse = new HashMap<>();
	private final Map<UUID, String[]> kits = new HashMap<>();          // layout 36 ช่อง: null / "sword" / "crystal"
	private final Map<UUID, EditSession> sessions = new HashMap<>();
	private final Map<UUID, Match> crystalOwner = new HashMap<>();     // คริสตัลแต่ละอัน เป็นของแมตช์ไหน

	@Override
	public void onEnable() {
		itemKey = new NamespacedKey(this, "duel_item");
		floodgate = Bukkit.getPluginManager().getPlugin("floodgate") != null;
		loadKits();
		Bukkit.getPluginManager().registerEvents(this, this);
		Bukkit.getScheduler().runTaskTimer(this, () -> {
			for (QEntry q : queue.values()) {
				if (q.player().isOnline()) {
					q.player().sendActionBar(c("&eกำลังหาคู่... &7(" + kitName(q.crystal()) + ", " + q.rounds() + " rounds) กดดาบอีกครั้งเพื่อยกเลิก"));
				}
			}
		}, 20L, 40L);
		getLogger().info("Floodgate: " + (floodgate ? "พบ (ผู้เล่น Bedrock ใช้ฟอร์ม)" : "ไม่พบ"));
	}

	@Override
	public void onDisable() {
		for (Match m : new HashSet<>(matches.values())) {
			if (m.crystal) clearArena(m);
		}
	}

	// ---------- helpers ----------

	private Component c(String s) {
		return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
	}

	private Component itemName(String s) {
		return c(s).decoration(TextDecoration.ITALIC, false);
	}

	private String kitName(boolean crystal) { return crystal ? "Crystal PVP" : "Sword PVP"; }

	private void later(int ticks, Runnable r) {
		Bukkit.getScheduler().runTaskLater(this, r, Math.max(1, ticks));
	}

	private boolean throttle(Player p, long ms) {
		long now = System.currentTimeMillis();
		Long last = lastUse.get(p.getUniqueId());
		if (last != null && now - last < ms) return true;
		lastUse.put(p.getUniqueId(), now);
		return false;
	}

	private boolean inLobby(Player p) { return p.getWorld().getName().equals(LOBBY); }

	private boolean protectedWorld(Player p) {
		String w = p.getWorld().getName();
		return w.equals(LOBBY) || w.equals(ARENA) || w.equals(CRYSTAL_ARENA);
	}

	private boolean isFree(Player p) {
		return p != null && p.isOnline() && inLobby(p) && !matches.containsKey(p.getUniqueId());
	}

	private World arenaWorld(String name) {
		World w = Bukkit.getWorld(name);
		if (w == null) w = Bukkit.createWorld(new WorldCreator(name)); // โหลดโลกที่มีอยู่แล้ว
		return w;
	}

	private void title(Player p, String t, String sub, int stayMs) {
		p.showTitle(Title.title(c(t), c(sub),
			Title.Times.times(Duration.ZERO, Duration.ofMillis(stayMs), Duration.ZERO)));
	}

	private ItemStack tagged(Material m, String name, String tag) {
		ItemStack it = new ItemStack(m);
		ItemMeta meta = it.getItemMeta();
		meta.displayName(itemName(name));
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, tag);
		it.setItemMeta(meta);
		return it;
	}

	private ItemStack named(Material m, String name, String... lore) {
		ItemStack it = new ItemStack(m);
		ItemMeta meta = it.getItemMeta();
		meta.displayName(itemName(name));
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		if (lore.length > 0) {
			List<Component> l = new ArrayList<>();
			for (String s : lore) l.add(itemName(s));
			meta.lore(l);
		}
		it.setItemMeta(meta);
		return it;
	}

	private void giveLobbyItems(Player p) {
		p.getInventory().clear();
		p.getInventory().setArmorContents(new ItemStack[4]);
		p.getInventory().setItem(0, tagged(Material.DIAMOND_SWORD, "&bหาคู่สู้ &7(Queue)", "queue"));
		p.getInventory().setItem(1, tagged(Material.IRON_SWORD, "&7สุ่มหาคู่ &7(2 ใน 3 ตา)", "duel"));
		p.getInventory().setHeldItemSlot(0);
		p.updateInventory();
	}

	private void resetPlayer(Player p) {
		p.setGameMode(GameMode.SURVIVAL);
		p.setFlying(false);
		p.setAllowFlight(false);
		for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
		AttributeInstance maxHp = p.getAttribute(Attribute.MAX_HEALTH);
		p.setHealth(maxHp != null ? maxHp.getValue() : 20.0);
		p.addPotionEffect(new PotionEffect(PotionEffectType.INSTANT_HEALTH, 1, 5));
		p.setFoodLevel(20);
		p.setSaturation(20f);
		p.setFireTicks(0);
		p.setFallDistance(0f);
		p.setVelocity(new Vector(0, 0, 0));
	}

	// ---------- kit layout (บันทึกลงไฟล์ kits.yml) ----------

	private static String[] defaultLayout() {
		String[] d = new String[36];
		d[0] = "sword";
		d[1] = "crystal";
		return d;
	}

	private String[] layoutOf(Player p) {
		return kits.getOrDefault(p.getUniqueId(), defaultLayout());
	}

	private void loadKits() {
		kitFile = new File(getDataFolder(), "kits.yml");
		if (!kitFile.exists()) return;
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(kitFile);
		for (String k : cfg.getKeys(false)) {
			try {
				UUID id = UUID.fromString(k);
				List<String> l = cfg.getStringList(k);
				String[] a = new String[36];
				for (int i = 0; i < 36 && i < l.size(); i++) {
					String v = l.get(i);
					a[i] = ("sword".equals(v) || "crystal".equals(v)) ? v : null;
				}
				kits.put(id, a);
			} catch (IllegalArgumentException ignored) {}
		}
	}

	private void saveKits() {
		YamlConfiguration cfg = new YamlConfiguration();
		for (Map.Entry<UUID, String[]> en : kits.entrySet()) {
			List<String> l = new ArrayList<>();
			for (String s : en.getValue()) l.add(s == null ? "-" : s);
			cfg.set(en.getKey().toString(), l);
		}
		try {
			getDataFolder().mkdirs();
			cfg.save(kitFile);
		} catch (IOException ex) {
			getLogger().warning("เซฟ kits.yml ไม่ได้: " + ex.getMessage());
		}
	}

	// ---------- events: lobby ----------

	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		Player p = e.getPlayer();
		String w = p.getWorld().getName();
		if (w.equals(ARENA) || w.equals(CRYSTAL_ARENA)) {
			later(2, () -> toLobby(p));
		} else if (w.equals(LOBBY)) {
			giveLobbyItems(p);
		}
	}

	@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		Player p = e.getPlayer();
		UUID id = p.getUniqueId();
		queue.remove(id);
		invites.remove(id);
		lastUse.remove(id);
		sessions.remove(id);
		Match m = matches.get(id);
		if (m != null && !m.ended) endMatch(m, m.other(p));
	}

	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		if (!inLobby(p)) return;
		e.setCancelled(true);
		if (e.getHand() != EquipmentSlot.HAND) return;
		if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
		ItemStack it = e.getItem();
		if (it == null || !it.hasItemMeta()) return;
		String tag = it.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
		if (tag == null || throttle(p, 600)) return;

		if (queue.remove(p.getUniqueId()) != null) {
			p.sendMessage(c("&cออกจากคิวแล้ว"));
			return;
		}
		if (tag.equals("queue")) {
			openKitMenu(p, "queue", null);
		} else if (tag.equals("duel")) {
			openKitMenu(p, "random", null);
		}
	}

	@EventHandler(priority = EventPriority.HIGH)
	public void onDamage(EntityDamageEvent e) {
		if (!(e.getEntity() instanceof Player v)) return;
		Match m = matches.get(v.getUniqueId());

		if (m != null) {
			if (!m.live) { e.setCancelled(true); return; }
			if (m.crystal && e.getCause() == EntityDamageEvent.DamageCause.FALL) { e.setCancelled(true); return; }
			// ดาเมจที่ไม่ได้มาจากคู่ต่อสู้ (รวมถึงระเบิดจริงจากที่อื่น) ไม่นับ — ยกเว้นระเบิดที่เราคำนวณเอง
			if (!internalDamage) {
				if (e instanceof EntityDamageByEntityEvent be && be.getDamager() != m.other(v)) {
					e.setCancelled(true);
					return;
				}
				if (e.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION
					|| e.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) {
					e.setCancelled(true);
					return;
				}
			}
			if (e.getCause() == EntityDamageEvent.DamageCause.VOID || v.getHealth() - e.getFinalDamage() <= 0) {
				e.setCancelled(true);
				winRound(m, m.other(v));
			}
			return;
		}

		if (protectedWorld(v)) {
			e.setCancelled(true);
			// ตีตัวคนในล็อบบี้ = ท้าดวล
			if (e instanceof EntityDamageByEntityEvent be
				&& be.getDamager() instanceof Player d
				&& d != v && inLobby(v) && inLobby(d) && !throttle(d, 1000)) {
				openKitMenu(d, "duel", v.getUniqueId());
			}
		}
	}

	@EventHandler
	public void onMove(PlayerMoveEvent e) {
		Match m = matches.get(e.getPlayer().getUniqueId());
		if (m == null || m.live || m.ended) return;
		if (e.getPlayer().getGameMode() == GameMode.SPECTATOR) return;
		Location f = e.getFrom(), t = e.getTo();
		if (t == null) return;
		if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
			Location n = f.clone();
			n.setYaw(t.getYaw());
			n.setPitch(t.getPitch());
			e.setTo(n);
		}
	}

	@EventHandler public void onBreak(BlockBreakEvent e) { if (protectedWorld(e.getPlayer())) e.setCancelled(true); }
	@EventHandler public void onPlace(BlockPlaceEvent e) { if (protectedWorld(e.getPlayer())) e.setCancelled(true); }
	@EventHandler public void onDrop(PlayerDropItemEvent e) { if (protectedWorld(e.getPlayer())) e.setCancelled(true); }
	@EventHandler public void onSwap(PlayerSwapHandItemsEvent e) { if (protectedWorld(e.getPlayer())) e.setCancelled(true); }

	@EventHandler
	public void onFood(FoodLevelChangeEvent e) {
		if (e.getEntity() instanceof Player p && protectedWorld(p)) e.setCancelled(true);
	}

	/** บล็อกปลอมที่ผู้เล่นยืนอยู่ เซิร์ฟมองเป็นอากาศ -> เปิด allowFlight กันโดนเตะ แต่ห้ามบินจริง */
	@EventHandler
	public void onToggleFlight(PlayerToggleFlightEvent e) {
		Player p = e.getPlayer();
		Match m = matches.get(p.getUniqueId());
		if (m != null && m.crystal && p.getGameMode() == GameMode.SURVIVAL && e.isFlying()) e.setCancelled(true);
	}

	// ระเบิดจริงในสนามคริสตัลไม่ต้องมี (เราคำนวณเอง) กันไว้เผื่อมีอะไรหลุดมา
	@EventHandler public void onEntityExplode(EntityExplodeEvent e) { if (e.getEntity().getWorld().getName().equals(CRYSTAL_ARENA)) e.setCancelled(true); }
	@EventHandler public void onBlockExplode(BlockExplodeEvent e) { if (e.getBlock().getWorld().getName().equals(CRYSTAL_ARENA)) e.setCancelled(true); }

	@EventHandler
	public void onDrag(InventoryDragEvent e) {
		if (!(e.getWhoClicked() instanceof Player p)) return;
		InventoryHolder h = e.getView().getTopInventory().getHolder();
		if (h instanceof KitMenu || h instanceof RoundsMenu || h instanceof PickMenu
			|| h instanceof EditorMenu || h instanceof RoomMenu
			|| (protectedWorld(p) && p.getGameMode() != GameMode.CREATIVE)) {
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void onClick(InventoryClickEvent e) {
		if (!(e.getWhoClicked() instanceof Player p)) return;
		Inventory top = e.getView().getTopInventory();
		InventoryHolder h = top.getHolder();
		boolean inTop = e.getClickedInventory() == top;

		if (h instanceof KitMenu km) {
			e.setCancelled(true);
			if (!inTop) return;
			int s = e.getSlot();
			if (s == BOOK_SLOT) {
				p.closeInventory();
				later(2, () -> { if (isFree(p)) openEditor(p, km.mode, km.target); });
			} else if (s == KIT_SLOT || s == CRYSTAL_SLOT) {
				final boolean crystal = s == CRYSTAL_SLOT;
				p.closeInventory();
				later(5, () -> {
					if (!isFree(p)) return;
					if (km.mode.equals("queue")) {
						joinQueue(p, QUEUE_WINS, crystal);
					} else if (km.mode.equals("random")) {
						joinQueue(p, IRON_WINS, crystal);
					} else {
						Player t = km.target == null ? null : Bukkit.getPlayer(km.target);
						if (t != null) openDuelUi(p, t, crystal);
					}
				});
			}
			return;
		}
		if (h instanceof EditorMenu em) {
			e.setCancelled(true);
			if (inTop) clickEditor(p, em, e);
			return;
		}
		if (h instanceof RoomMenu rm) {
			e.setCancelled(true);
			if (inTop) clickRoom(p, rm, e.getSlot());
			return;
		}
		if (h instanceof PickMenu pm) {
			e.setCancelled(true);
			UUID tid = inTop ? pm.slots.get(e.getSlot()) : null;
			if (tid != null) {
				p.closeInventory();
				later(5, () -> {
					Player t = Bukkit.getPlayer(tid);
					if (!isFree(p)) return;
					if (!isFree(t)) { p.sendMessage(c("&cผู้เล่นไม่ว่าง")); return; }
					openDuelUi(p, t, false);
				});
			}
			return;
		}
		if (h instanceof RoundsMenu rm) {
			e.setCancelled(true);
			if (inTop && e.getSlot() >= 0 && e.getSlot() < MAX_ROUNDS) {
				int rounds = e.getSlot() + 1;
				p.closeInventory();
				Player t = rm.target == null ? null : Bukkit.getPlayer(rm.target);
				later(2, () -> {
					if (rm.target == null) { joinQueue(p, rounds, rm.crystal); return; }
					if (t == null) { p.sendMessage(c("&cหาผู้เล่นไม่เจอ")); return; }
					sendInvite(p, t, rounds, rm.crystal);
				});
			}
			return;
		}
		if (protectedWorld(p) && p.getGameMode() != GameMode.CREATIVE) e.setCancelled(true);
	}

	// ---------- menu + form ----------

	private void openKitMenu(Player p, String mode, UUID target) {
		KitMenu h = new KitMenu(mode, target);
		Inventory inv = Bukkit.createInventory(h, 54, c("Select a Kit"));
		h.inv = inv;
		inv.setItem(BOOK_SLOT, named(Material.BOOK, "&eKit Editor", "&7จัดตำแหน่งดาบ / คริสตัล"));
		inv.setItem(KIT_SLOT, named(Material.DIAMOND_SWORD, "&bSword"));
		inv.setItem(CRYSTAL_SLOT, named(Material.END_CRYSTAL, "&dCrystal PvP", "&7ระเบิดคริสตัล + วางบล็อก"));
		p.openInventory(inv);
	}

	private void openPlayerPicker(Player p) {
		PickMenu h = new PickMenu();
		Inventory inv = Bukkit.createInventory(h, 54, c("Select a Player"));
		h.inv = inv;
		int slot = 0;
		for (Player q : Bukkit.getOnlinePlayers()) {
			if (q == p || !isFree(q) || slot >= 54) continue;
			ItemStack head = new ItemStack(Material.PLAYER_HEAD);
			SkullMeta sm = (SkullMeta) head.getItemMeta();
			sm.setOwningPlayer(q);
			sm.displayName(itemName("&e" + q.getName()));
			sm.lore(List.of(itemName("&7กดเพื่อท้าดวล")));
			head.setItemMeta(sm);
			inv.setItem(slot, head);
			h.slots.put(slot, q.getUniqueId());
			slot++;
		}
		if (h.slots.isEmpty()) {
			p.sendMessage(c("&cไม่มีผู้เล่นให้ท้าตอนนี้"));
			return;
		}
		p.openInventory(inv);
	}

	private void openDuelUi(Player p, Player target, boolean crystal) {
		boolean bedrock = floodgate && FloodForms.isBedrock(p);

		if (bedrock) {
			List<String> names = new ArrayList<>();
			if (target == null) {
				for (Player q : Bukkit.getOnlinePlayers()) {
					if (q != p && isFree(q)) names.add(q.getName());
				}
				if (names.isEmpty()) {
					p.sendMessage(c("&cไม่มีผู้เล่นให้ท้าตอนนี้"));
					return;
				}
			}
			FloodForms.sendDuel(this, p, target, names, crystal ? "Crystal" : "Sword", (pl, opp, rounds) -> {
				Player t = target != null ? target : (opp == null ? null : Bukkit.getPlayerExact(opp));
				if (t == null) { pl.sendMessage(c("&cหาผู้เล่นไม่เจอ")); return; }
				sendInvite(pl, t, rounds, crystal);
			});
			return;
		}

		// ผู้เล่น Java: เลือก rounds ผ่านเมนูกล่อง (ต้องตีตัวผู้เล่นเพื่อท้า)
		if (target == null) {
			p.sendMessage(c("&eใช้ดาบตีตัวผู้เล่นที่ต้องการท้าได้เลย"));
			return;
		}
		RoundsMenu h = new RoundsMenu(target.getUniqueId(), crystal);
		Inventory inv = Bukkit.createInventory(h, 27, c("Rounds vs " + target.getName()));
		h.inv = inv;
		for (int i = 1; i <= MAX_ROUNDS; i++) {
			ItemStack it = new ItemStack(Material.PAPER, i);
			ItemMeta meta = it.getItemMeta();
			meta.displayName(itemName("&e" + i + " rounds"));
			it.setItemMeta(meta);
			inv.setItem(i - 1, it);
		}
		p.openInventory(inv);
	}

	// ---------- Kit Editor / Kit Room ----------

	private static int chestToLayout(int s) {
		if (s >= 9 && s <= 35) return s;        // แถว 2-4 = ช่องเก็บของ
		if (s >= 45 && s <= 53) return s - 45;  // แถวล่าง = hotbar
		return -1;
	}

	private static int layoutToChest(int l) { return l < 9 ? l + 45 : l; }

	private static int firstFree(String[] w) {
		for (int i = 0; i < 36; i++) if (w[i] == null) return i;   // hotbar ก่อน
		return -1;
	}

	private static int count(String[] w, String kind) {
		int n = 0;
		for (String s : w) if (kind.equals(s)) n++;
		return n;
	}

	private ItemStack layoutItem(String kind, boolean glow) {
		if (kind == null) return null;
		ItemStack it = kind.equals("sword")
			? named(Material.DIAMOND_SWORD, "&bSword", "&7คลิกซ้าย: เลือก/สลับที่", "&7คลิกขวา: เอาออก")
			: named(Material.END_CRYSTAL, "&dEnd Crystal", "&7คลิกซ้าย: เลือก/สลับที่", "&7คลิกขวา: เอาออก");
		if (kind.equals("crystal")) it.setAmount(64);
		if (glow) {
			ItemMeta meta = it.getItemMeta();
			meta.setEnchantmentGlintOverride(true);
			it.setItemMeta(meta);
		}
		return it;
	}

	private void openEditor(Player p, String mode, UUID target) {
		EditSession s = new EditSession(layoutOf(p).clone(), mode, target);
		sessions.put(p.getUniqueId(), s);
		openEditorMenu(p, s);
	}

	private void openEditorMenu(Player p, EditSession s) {
		EditorMenu h = new EditorMenu(s);
		Inventory inv = Bukkit.createInventory(h, 54, c("Kit Editor"));
		h.inv = inv;
		renderEditor(h);
		p.openInventory(inv);
	}

	private void renderEditor(EditorMenu h) {
		Inventory inv = h.inv;
		EditSession s = h.s;
		inv.clear();
		for (int i = 0; i < 9; i++) inv.setItem(i, named(Material.GRAY_STAINED_GLASS_PANE, " "));
		for (int i = 36; i < 45; i++) inv.setItem(i, named(Material.GRAY_STAINED_GLASS_PANE, " "));
		inv.setItem(ED_ROOM, named(Material.LIME_BANNER, "&aKit Room", "&7เพิ่มดาบ / คริสตัล"));
		inv.setItem(ED_OK, named(Material.PURPLE_BANNER, "&dตกลง", "&7บันทึก Kit"));
		inv.setItem(ED_CANCEL, named(Material.RED_BANNER, "&cยกเลิก", "&7ไม่บันทึก"));
		inv.setItem(ED_RESET, named(Material.ORANGE_BANNER, "&6รีเซต", "&7กลับเป็นค่าเริ่มต้น"));
		for (int l = 0; l < 36; l++) inv.setItem(layoutToChest(l), layoutItem(s.work[l], l == s.selected));
	}

	private void clickEditor(Player p, EditorMenu em, InventoryClickEvent e) {
		EditSession s = em.s;
		int slot = e.getSlot();
		if (slot == ED_ROOM) { later(1, () -> openRoom(p, s)); return; }
		if (slot == ED_OK) {
			if (count(s.work, "sword") < 1) { p.sendMessage(c("&cต้องมีดาบอย่างน้อย 1 เล่ม")); return; }
			kits.put(p.getUniqueId(), s.work.clone());
			saveKits();
			sessions.remove(p.getUniqueId());
			p.sendMessage(c("&aบันทึก Kit แล้ว"));
			p.closeInventory();
			later(2, () -> { if (isFree(p)) openKitMenu(p, s.mode, s.target); });
			return;
		}
		if (slot == ED_CANCEL) {
			sessions.remove(p.getUniqueId());
			p.closeInventory();
			later(2, () -> { if (isFree(p)) openKitMenu(p, s.mode, s.target); });
			return;
		}
		if (slot == ED_RESET) {
			String[] d = defaultLayout();
			System.arraycopy(d, 0, s.work, 0, 36);
			s.selected = -1;
			renderEditor(em);
			return;
		}
		int l = chestToLayout(slot);
		if (l < 0) return;
		if (e.isRightClick() || e.isShiftClick()) {
			s.work[l] = null;
			s.selected = -1;
		} else if (s.selected == -1) {
			if (s.work[l] != null) s.selected = l;
		} else if (s.selected == l) {
			s.selected = -1;
		} else {
			String tmp = s.work[l];
			s.work[l] = s.work[s.selected];
			s.work[s.selected] = tmp;
			s.selected = -1;
		}
		renderEditor(em);
	}

	private void openRoom(Player p, EditSession s) {
		RoomMenu h = new RoomMenu(s);
		Inventory inv = Bukkit.createInventory(h, 54, c("Kit Room"));
		h.inv = inv;
		renderRoom(h);
		p.openInventory(inv);
	}

	private void renderRoom(RoomMenu h) {
		Inventory inv = h.inv;
		EditSession s = h.s;
		inv.clear();
		inv.setItem(0, named(Material.DIAMOND_SWORD, "&bSword", "&7กดเพื่อเพิ่มดาบ"));
		inv.setItem(2, named(Material.END_CRYSTAL, "&dEnd Crystal", "&7กดเพื่อเพิ่ม 1 สแตก (64)"));
		inv.setItem(8, named(Material.ARROW, "&cกลับ", "&7กลับไป Kit Editor"));
		for (int l = 0; l < 36; l++) inv.setItem(layoutToChest(l), layoutItem(s.work[l], false));
	}

	private void clickRoom(Player p, RoomMenu rm, int slot) {
		EditSession s = rm.s;
		if (slot == 8) { later(1, () -> openEditorMenu(p, s)); return; }
		if (slot != 0 && slot != 2) return;
		String kind = slot == 0 ? "sword" : "crystal";
		if (kind.equals("sword") && count(s.work, "sword") >= 1) { p.sendMessage(c("&eมีดาบอยู่แล้ว")); return; }
		if (kind.equals("crystal") && count(s.work, "crystal") >= MAX_CRYSTAL_STACKS) { p.sendMessage(c("&eคริสตัลเต็มแล้ว")); return; }
		int f = firstFree(s.work);
		if (f < 0) { p.sendMessage(c("&cช่องเต็ม")); return; }
		s.work[f] = kind;
		renderRoom(rm);
	}

	// ---------- queue / invite ----------

	private void joinQueue(Player p, int rounds, boolean crystal) {
		if (!isFree(p)) return;
		rounds = Math.max(1, Math.min(MAX_ROUNDS, rounds));
		Iterator<Map.Entry<UUID, QEntry>> it = queue.entrySet().iterator();
		while (it.hasNext()) {
			QEntry q = it.next().getValue();
			if (!isFree(q.player())) { it.remove(); continue; }
			if (q.player() != p && q.rounds() == rounds && q.crystal() == crystal) {
				it.remove();
				startMatch(q.player(), p, rounds, crystal);
				return;
			}
		}
		queue.put(p.getUniqueId(), new QEntry(p, rounds, crystal));
		p.sendMessage(c("&aเข้าคิวแล้ว &7(" + kitName(crystal) + ", " + rounds + " rounds) &aรอจนกว่าจะมีคนกดเหมือนกัน &7(กดดาบอีกครั้งเพื่อออกจากคิว)"));
	}

	private void sendInvite(Player from, Player to, int rounds, boolean crystal) {
		rounds = Math.max(1, Math.min(MAX_ROUNDS, rounds));
		if (!isFree(from) || !isFree(to) || from == to) {
			from.sendMessage(c("&cผู้เล่นไม่ว่าง"));
			return;
		}
		invites.put(to.getUniqueId(), new Invite(from.getUniqueId(), rounds, crystal, System.currentTimeMillis()));

		to.sendMessage(c("&e" + from.getName() + " &fท้าคุณสู้ &b" + kitName(crystal) + " &7(&f" + rounds + " rounds&7)"));
		Component accept = c("&a[ตกลง]").clickEvent(ClickEvent.runCommand("/accept"));
		Component deny = c("&c[ปฏิเสธ]").clickEvent(ClickEvent.runCommand("/deny"));
		to.sendMessage(accept.append(c(" &7= /accept    ")).append(deny).append(c(" &7= /deny")));
		from.sendMessage(c("&aส่งคำท้าให้ &e" + to.getName() + " &aแล้ว &7(หมดอายุใน " + INVITE_SECONDS + " วิ)"));
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (!(sender instanceof Player p)) return true;
		Invite inv = invites.remove(p.getUniqueId());
		if (inv == null || System.currentTimeMillis() - inv.time() > INVITE_SECONDS * 1000L) {
			p.sendMessage(c("&cไม่มีคำท้าที่รออยู่"));
			return true;
		}
		Player from = Bukkit.getPlayer(inv.from());

		if (cmd.getName().equalsIgnoreCase("deny")) {
			p.sendMessage(c("&cปฏิเสธแล้ว"));
			if (from != null) from.sendMessage(c("&e" + p.getName() + " &cปฏิเสธคำท้า"));
			return true;
		}
		if (!isFree(from) || !isFree(p)) {
			p.sendMessage(c("&cตอนนี้เริ่มดวลไม่ได้ (ผู้เล่นไม่ว่าง)"));
			return true;
		}
		startMatch(from, p, inv.rounds(), inv.crystal());
		return true;
	}

	// ---------- match flow ----------

	private void startMatch(Player a, Player b, int target, boolean crystal) {
		String arenaName = crystal ? CRYSTAL_ARENA : ARENA;
		World arena = arenaWorld(arenaName);
		if (arena == null) {
			a.sendMessage(c("&cหาโลก " + arenaName + " ไม่เจอ"));
			b.sendMessage(c("&cหาโลก " + arenaName + " ไม่เจอ"));
			return;
		}
		for (Player p : List.of(a, b)) {
			queue.remove(p.getUniqueId());
			invites.remove(p.getUniqueId());
		}
		Match m = new Match(a, b, target, crystal);
		matches.put(a.getUniqueId(), m);
		matches.put(b.getUniqueId(), m);

		Bukkit.broadcast(c("&b[Duel] &e" + a.getName() + " &fvs &e" + b.getName()
			+ " &7- " + kitName(crystal) + " (ชนะ " + target + " ตาก่อน)"));
		startRound(m);
		hideOthers(m);
	}

	/** ซ่อนผู้เล่นคู่อื่นในสนาม ให้เห็นแค่คู่ของตัวเอง */
	private void hideOthers(Match m) {
		final String arenaName = m.crystal ? CRYSTAL_ARENA : ARENA;
		later(3, () -> {
			for (Player q : Bukkit.getOnlinePlayers()) {
				if (q == m.a || q == m.b || !q.getWorld().getName().equals(arenaName)) continue;
				for (Player p : List.of(m.a, m.b)) {
					if (p.isOnline()) {
						p.hidePlayer(this, q);
						q.hidePlayer(this, p);
					}
				}
			}
		});
	}

	private void giveKit(Player p, Match m) {
		PlayerInventory inv = p.getInventory();
		inv.clear();
		inv.setHelmet(new ItemStack(Material.DIAMOND_HELMET));
		inv.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
		inv.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
		inv.setBoots(new ItemStack(Material.DIAMOND_BOOTS));

		// ตำแหน่งดาบ/คริสตัลตามที่ผู้เล่นจัดไว้ใน Kit Editor (ใช้ทั้งท้า และจับคู่)
		String[] lay = layoutOf(p);
		int sword = -1, stacks = 0;
		for (int i = 0; i < 36; i++) {
			String k = lay[i];
			if ("sword".equals(k) && sword < 0) {
				inv.setItem(i, new ItemStack(Material.DIAMOND_SWORD));
				sword = i;
			} else if ("crystal".equals(k) && m.crystal && stacks < MAX_CRYSTAL_STACKS) {
				inv.setItem(i, new ItemStack(Material.END_CRYSTAL, 64));
				stacks++;
			}
		}
		if (sword < 0) {
			int f = firstEmpty(inv);
			sword = f < 0 ? 0 : f;
			inv.setItem(sword, new ItemStack(Material.DIAMOND_SWORD));
		}
		if (m.crystal) {
			if (stacks == 0) {
				int f = firstEmpty(inv);
				if (f >= 0) inv.setItem(f, new ItemStack(Material.END_CRYSTAL, 64));
			}
			if (GIVE_OBSIDIAN) {
				int f = firstEmpty(inv);
				if (f >= 0) inv.setItem(f, new ItemStack(Material.OBSIDIAN, 64));
			}
		}
		inv.setHeldItemSlot(sword < 9 ? sword : 0);
		p.updateInventory();
	}

	private int firstEmpty(PlayerInventory inv) {
		for (int i = 0; i < 36; i++) if (inv.getItem(i) == null) return i;
		return -1;
	}

	/** ใส่ชุด + เลือดเต็ม (เรียกซ้ำหลังวาป กันปลั๊กอินแยกอินเวนทอรี่ต่อโลกมาเซ็ตทับ) */
	private void prepare(Match m, Player p) {
		if (!p.isOnline() || m.ended || m.live) return;
		resetPlayer(p);
		if (m.crystal) p.setAllowFlight(true);   // ยืนบนบล็อกปลอมได้ ไม่โดนเตะ (บินจริงถูกยกเลิกไว้)
		giveKit(p, m);
	}

	private void setupPlayer(Player p, Match m, World arena) {
		int idx = m.idx(p);
		double[] s;
		float yaw;
		if (m.crystal) {
			s = idx == 0 ? CRYSTAL_SPAWN_A : CRYSTAL_SPAWN_B;
			yaw = idx == 0 ? CRYSTAL_YAW_A : CRYSTAL_YAW_B;
		} else {
			s = idx == 0 ? SPAWN_A : SPAWN_B;
			yaw = idx == 0 ? 0f : 180f;
		}
		p.closeInventory();
		p.teleport(new Location(arena, s[0], s[1], s[2], yaw, 0f));
		resetPlayer(p);
		if (m.crystal) p.setAllowFlight(true);
		giveKit(p, m);
	}

	private void startRound(Match m) {
		World arena = arenaWorld(m.crystal ? CRYSTAL_ARENA : ARENA);
		if (arena == null) return;
		m.round++;
		m.live = false;
		final int id = ++m.token;

		if (m.crystal) clearArena(m);   // คืนบล็อก/หลุม/คริสตัลทั้งหมดก่อนเริ่มตาใหม่

		for (Player p : List.of(m.a, m.b)) {
			if (!p.isOnline()) continue;
			setupPlayer(p, m, arena);
			for (int t = 5; t <= 95; t += 10) {
				later(t, () -> {
					if (m.token == id) prepare(m, p);
				});
			}
		}

		for (int n = 5; n >= 1; n--) {
			final int num = n;
			later((5 - n) * 20 + 1, () -> {
				if (m.ended || m.token != id) return;
				for (Player p : List.of(m.a, m.b)) {
					if (p.isOnline()) title(p, "&e" + num, "&7Round " + m.round, 1100);
				}
			});
		}
		later(101, () -> {
			if (m.ended || m.token != id) return;
			for (Player p : List.of(m.a, m.b)) {
				if (p.isOnline()) prepare(m, p);
			}
			m.live = true;
			for (Player p : List.of(m.a, m.b)) {
				if (p.isOnline()) title(p, "&aFIGHT!", "", 1000);
			}
		});
	}

	private void winRound(Match m, Player winner) {
		if (!m.live || m.ended) return;
		m.live = false;
		m.token++;
		m.score[m.idx(winner)]++;

		for (Player p : List.of(m.a, m.b)) {
			if (p.isOnline()) {
				p.sendMessage(c("&eตาที่ " + m.round + " &f- &a" + winner.getName() + " &fชนะ &7("
					+ m.score[0] + " - " + m.score[1] + ")"));
			}
		}
		Player loser = m.other(winner);
		if (loser.isOnline()) {
			loser.setGameMode(GameMode.SPECTATOR);
			title(loser, "&cแพ้ตานี้", "", 1500);
		}
		if (winner.isOnline()) title(winner, "&aชนะตานี้", "", 1500);
		if (m.score[m.idx(winner)] >= m.target) {
			endMatch(m, winner);
			return;
		}
		final int id = m.token;
		later(50, () -> {
			if (!m.ended && m.token == id) startRound(m);
		});
	}

	private void endMatch(Match m, Player winner) {
		if (m.ended) return;
		m.ended = true;
		m.live = false;
		m.token++;
		Player loser = m.other(winner);
		matches.remove(m.a.getUniqueId());
		matches.remove(m.b.getUniqueId());
		if (m.crystal) clearArena(m);

		Bukkit.broadcast(c("&b[Duel] &6" + winner.getName() + " &fชนะดวลกับ &6" + loser.getName()
			+ " &7(" + m.score[m.idx(winner)] + " - " + m.score[m.idx(loser)] + ")"));
		if (winner.isOnline()) title(winner, "&6ชนะ!", "", 2000);

		later(60, () -> {
			toLobby(m.a);
			toLobby(m.b);
		});
	}

	// ---------- Crystal PvP: บล็อก/คริสตัล/ระเบิด แยกต่อคู่ ----------
	// หลักการ: ไม่แตะโลกจริงเลย บล็อกที่วาง/พังเก็บใน m.fake แล้วส่งด้วย sendBlockChange ให้ 2 คนในแมตช์เท่านั้น
	// คริสตัลเป็นเอนทิตีที่ซ่อนจากทุกคน ยกเว้น 2 คนนี้ และการระเบิดคำนวณเองทั้งหมด -> คู่อื่นไม่เห็น ไม่โดนดาเมจ

	private static long key(int x, int y, int z) {
		return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (long) (y & 0xFFF);
	}

	private Material typeAt(Match m, World w, int x, int y, int z) {
		Cell cell = m.fake.get(key(x, y, z));
		return cell != null ? cell.data().getMaterial() : w.getType(x, y, z);
	}

	private void setFake(Match m, World w, int x, int y, int z, BlockData data) {
		m.fake.put(key(x, y, z), new Cell(x, y, z, data));
		Location loc = new Location(w, x, y, z);
		for (Player p : List.of(m.a, m.b)) {
			if (p.isOnline() && p.getWorld() == w) p.sendBlockChange(loc, data);
		}
	}

	/** คืนทุกอย่างเป็นเหมือนเดิม: ลบคริสตัล + ส่งบล็อกจริงกลับให้ผู้เล่น */
	private void clearArena(Match m) {
		for (EnderCrystal cr : new ArrayList<>(m.crystals)) {
			crystalOwner.remove(cr.getUniqueId());
			cr.remove();
		}
		m.crystals.clear();
		World w = Bukkit.getWorld(CRYSTAL_ARENA);
		if (w != null) {
			for (Cell cell : m.fake.values()) {
				BlockData real = w.getBlockData(cell.x(), cell.y(), cell.z());
				Location loc = new Location(w, cell.x(), cell.y(), cell.z());
				for (Player p : List.of(m.a, m.b)) {
					if (p.isOnline() && p.getWorld() == w) p.sendBlockChange(loc, real);
				}
			}
		}
		m.fake.clear();
	}

	@EventHandler(priority = EventPriority.HIGH)
	public void onArenaInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		Match m = matches.get(p.getUniqueId());
		if (m == null || !m.crystal) return;
		e.setCancelled(true);
		if (!m.live || m.ended) return;
		if (e.getHand() != EquipmentSlot.HAND || e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
		Block clicked = e.getClickedBlock();
		if (clicked == null) return;
		Material t = p.getInventory().getItemInMainHand().getType();
		World w = p.getWorld();
		if (t == Material.END_CRYSTAL) {
			placeCrystal(m, p, w, clicked.getX(), clicked.getY(), clicked.getZ());
		} else if (t.isBlock() && t.isSolid()) {
			placeBlock(m, p, w, clicked, e.getBlockFace(), t);
		}
	}

	private void consumeOne(Player p) {
		PlayerInventory inv = p.getInventory();
		ItemStack hand = inv.getItemInMainHand();
		if (hand.getAmount() <= 1) {
			inv.setItemInMainHand(null);
		} else {
			hand.setAmount(hand.getAmount() - 1);
			inv.setItemInMainHand(hand);
		}
	}

	private void placeBlock(Match m, Player p, World w, Block clicked, BlockFace face, Material t) {
		int cx = clicked.getX(), cy = clicked.getY(), cz = clicked.getZ();
		if (typeAt(m, w, cx, cy, cz).isAir()) return;
		int x = cx + face.getModX(), y = cy + face.getModY(), z = cz + face.getModZ();
		if (y < w.getMinHeight() || y >= w.getMaxHeight()) return;
		if (!typeAt(m, w, x, y, z).isAir()) return;
		if (m.fake.size() >= MAX_FAKE_BLOCKS) { p.sendMessage(c("&cวางบล็อกเต็มแล้ว")); return; }
		BoundingBox box = new BoundingBox(x, y, z, x + 1, y + 1, z + 1);
		for (Player q : List.of(m.a, m.b)) {
			if (q.isOnline() && q.getGameMode() == GameMode.SURVIVAL && q.getBoundingBox().overlaps(box)) return;
		}
		for (EnderCrystal cr : m.crystals) if (cr.getBoundingBox().overlaps(box)) return;

		BlockData data = t.createBlockData();
		setFake(m, w, x, y, z, data);
		consumeOne(p);
		p.swingMainHand();
		Location loc = new Location(w, x + 0.5, y + 0.5, z + 0.5);
		for (Player q : List.of(m.a, m.b)) {
			if (q.isOnline()) q.playSound(loc, data.getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 1f, 0.8f);
		}
	}

	private void placeCrystal(Match m, Player p, World w, int x, int y, int z) {
		Material base = typeAt(m, w, x, y, z);
		if (base != Material.OBSIDIAN && base != Material.BEDROCK) return;
		if (!typeAt(m, w, x, y + 1, z).isAir()) return;
		BoundingBox box = new BoundingBox(x, y + 1, z, x + 1, y + 3, z + 1);
		for (Player q : List.of(m.a, m.b)) {
			if (q.isOnline() && q.getGameMode() == GameMode.SURVIVAL && q.getBoundingBox().overlaps(box)) return;
		}
		for (EnderCrystal cr : m.crystals) if (cr.getBoundingBox().overlaps(box)) return;

		Location loc = new Location(w, x + 0.5, y + 1, z + 0.5);
		EnderCrystal cr = w.spawn(loc, EnderCrystal.class, ent -> {
			ent.setShowingBottom(false);
			ent.setVisibleByDefault(false);   // ไม่มีใครเห็น จนกว่าจะ showEntity
			ent.setPersistent(false);
		});
		for (Player q : List.of(m.a, m.b)) {
			if (q.isOnline()) q.showEntity(this, cr);
		}
		m.crystals.add(cr);
		crystalOwner.put(cr.getUniqueId(), m);
		consumeOne(p);
		p.swingMainHand();
	}

	/** ตีคริสตัล = ระเบิดแบบที่เราคำนวณเอง (ไม่ให้เกมระเบิดจริง) */
	@EventHandler(priority = EventPriority.HIGH)
	public void onCrystalHit(EntityDamageEvent e) {
		if (!(e.getEntity() instanceof EnderCrystal cr)) return;
		Match m = crystalOwner.get(cr.getUniqueId());
		if (m == null) {
			if (cr.getWorld().getName().equals(CRYSTAL_ARENA)) e.setCancelled(true);
			return;
		}
		e.setCancelled(true);
		if (!m.live || m.ended) return;
		if (e instanceof EntityDamageByEntityEvent be && be.getDamager() instanceof Player d && (d == m.a || d == m.b)) {
			detonate(m, cr, d);
		}
	}

	private void detonate(Match m, EnderCrystal cr, Player cause) {
		if (!m.crystals.remove(cr)) return;
		crystalOwner.remove(cr.getUniqueId());
		Location loc = cr.getLocation();
		cr.remove();
		explode(m, loc.getWorld(), loc.getX(), loc.getY(), loc.getZ(), 6.0f, cause);
	}

	private void explode(Match m, World w, double cx, double cy, double cz, float power, Player cause) {
		Vector center = new Vector(cx, cy, cz);
		Location cLoc = new Location(w, cx, cy, cz);
		Random rnd = new Random();

		// 1) หาบล็อกที่จะพัง (สูตรเดียวกับเกม: ยิงรังสี 16x16x16 หักตามความทนระเบิด)
		Map<Long, int[]> hit = new HashMap<>();
		for (int i = 0; i < 16; i++) {
			for (int j = 0; j < 16; j++) {
				for (int k = 0; k < 16; k++) {
					if (i != 0 && i != 15 && j != 0 && j != 15 && k != 0 && k != 15) continue;
					double dx = i / 15.0 * 2.0 - 1.0, dy = j / 15.0 * 2.0 - 1.0, dz = k / 15.0 * 2.0 - 1.0;
					double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
					dx /= len; dy /= len; dz /= len;
					float intensity = power * (0.7f + rnd.nextFloat() * 0.6f);
					double px = cx, py = cy, pz = cz;
					for (; intensity > 0.0f; intensity -= 0.22500001f) {
						int bx = (int) Math.floor(px), by = (int) Math.floor(py), bz = (int) Math.floor(pz);
						if (by < w.getMinHeight() || by >= w.getMaxHeight()) break;
						Material mt = typeAt(m, w, bx, by, bz);
						if (!mt.isAir()) {
							intensity -= (mt.getBlastResistance() + 0.3f) * 0.3f;
							long kk = key(bx, by, bz);
							if (intensity > 0.0f && mt != Material.WATER && mt != Material.LAVA
								&& mt.getHardness() >= 0f && (CRATERS || m.fake.containsKey(kk))) {
								hit.putIfAbsent(kk, new int[]{bx, by, bz});
							}
						}
						px += dx * 0.3; py += dy * 0.3; pz += dz * 0.3;
					}
				}
			}
		}

		// 2) ดาเมจ + แรงกระเดน เฉพาะ 2 คนในแมตช์ (คนอื่นที่ยืนจุดเดียวกันไม่โดน)
		double q = power * 2.0;
		var bd = DamageSource.builder(DamageType.PLAYER_EXPLOSION);
		if (cause != null) bd.withCausingEntity(cause).withDirectEntity(cause);
		DamageSource src = bd.build();
		Player[] order = cause == null ? new Player[]{m.a, m.b} : new Player[]{m.other(cause), cause};
		for (Player v : order) {
			if (!v.isOnline() || v.getGameMode() != GameMode.SURVIVAL || v.getWorld() != w) continue;
			double d = v.getLocation().toVector().distance(center) / q;
			if (d > 1.0) continue;
			double dx = v.getLocation().getX() - cx;
			double dy = v.getEyeLocation().getY() - cy;
			double dz = v.getLocation().getZ() - cz;
			double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
			if (len == 0) continue;
			double seen = seenPercent(m, w, center, v.getBoundingBox());
			if (seen <= 0) continue;
			double impact = (1.0 - d) * seen;
			double dmg = (int) ((impact * impact + impact) / 2.0 * 7.0 * q + 1.0);
			Vector kb = new Vector(dx / len * impact, dy / len * impact, dz / len * impact);
			internalDamage = true;
			try {
				v.damage(dmg, src);
			} finally {
				internalDamage = false;
			}
			v.setVelocity(v.getVelocity().add(kb));
		}

		// 3) เอฟเฟกต์ ส่งให้ 2 คนนี้เท่านั้น
		for (Player p : List.of(m.a, m.b)) {
			if (!p.isOnline() || p.getWorld() != w) continue;
			p.spawnParticle(Particle.EXPLOSION_EMITTER, cLoc, 1);
			p.playSound(cLoc, Sound.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 4.0f, 0.9f + rnd.nextFloat() * 0.2f);
		}

		// 4) คริสตัลอันอื่นในรัศมี ระเบิดต่อเป็นลูกโซ่
		for (EnderCrystal other : new ArrayList<>(m.crystals)) {
			double d = other.getLocation().toVector().distance(center) / q;
			if (d <= 1.0 && seenPercent(m, w, center, other.getBoundingBox()) > 0) {
				later(1, () -> {
					if (m.live && !m.ended) detonate(m, other, cause);
				});
			}
		}

		// 5) พังบล็อก (เฉพาะภาพของ 2 คนนี้)
		BlockData air = Material.AIR.createBlockData();
		for (int[] b : hit.values()) setFake(m, w, b[0], b[1], b[2], air);
	}

	/** สัดส่วนที่เป้าหมาย "โดนระเบิดโดยตรง" (ไม่มีบล็อกบัง) เหมือนสูตรในเกม */
	private double seenPercent(Match m, World w, Vector c, BoundingBox box) {
		double wx = box.getWidthX(), wy = box.getHeight(), wz = box.getWidthZ();
		double sx = 1.0 / (wx * 2.0 + 1.0), sy = 1.0 / (wy * 2.0 + 1.0), sz = 1.0 / (wz * 2.0 + 1.0);
		double ox = (1.0 - Math.floor(1.0 / sx) * sx) / 2.0;
		double oz = (1.0 - Math.floor(1.0 / sz) * sz) / 2.0;
		int seen = 0, total = 0;
		for (double fx = 0; fx <= 1.0; fx += sx) {
			for (double fy = 0; fy <= 1.0; fy += sy) {
				for (double fz = 0; fz <= 1.0; fz += sz) {
					double px = box.getMinX() + fx * wx + ox;
					double py = box.getMinY() + fy * wy + 0.001;
					double pz = box.getMinZ() + fz * wz + oz;
					if (!blocked(m, w, px, py, pz, c)) seen++;
					total++;
				}
			}
		}
		return total == 0 ? 0 : (double) seen / total;
	}

	private boolean blocked(Match m, World w, double x, double y, double z, Vector c) {
		double dx = c.getX() - x, dy = c.getY() - y, dz = c.getZ() - z;
		double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
		int steps = (int) Math.ceil(len / 0.25);
		for (int i = 1; i < steps; i++) {
			double t = (double) i / steps;
			int bx = (int) Math.floor(x + dx * t), by = (int) Math.floor(y + dy * t), bz = (int) Math.floor(z + dz * t);
			if (by < w.getMinHeight() || by >= w.getMaxHeight()) continue;
			if (typeAt(m, w, bx, by, bz).isSolid()) return true;
		}
		return false;
	}

	// ---------- world / lobby ----------

	@EventHandler
	public void onWorldChange(PlayerChangedWorldEvent e) {
		Player p = e.getPlayer();
		for (int t : new int[]{2, 5, 10, 20, 40, 80}) later(t, () -> refreshWorld(p));
	}

	private void refreshWorld(Player p) {
		if (!p.isOnline()) return;
		Match m = matches.get(p.getUniqueId());
		if (m != null) {
			prepare(m, p);
		} else if (inLobby(p)) {
			resetPlayer(p);
			giveLobbyItems(p);
		}
	}

	private void toLobby(Player p) {
		if (!p.isOnline() || matches.containsKey(p.getUniqueId())) return;
		for (Player q : Bukkit.getOnlinePlayers()) {
			if (q != p) {
				p.showPlayer(this, q);
				q.showPlayer(this, p);
			}
		}
		World lobby = Bukkit.getWorld(LOBBY);
		if (lobby != null) p.teleport(lobby.getSpawnLocation());
		resetPlayer(p);
		giveLobbyItems(p);
	}
}
