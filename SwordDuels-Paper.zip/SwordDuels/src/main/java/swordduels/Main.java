package swordduels;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.RespawnAnchor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

public final class Main extends JavaPlugin implements Listener {

	// ====== ตั้งค่า ======
	static final String LOBBY = "lp";        // โลกล็อบบี้
	static final String ARENA = "sworld1";   // โลกสนามดวล (Sword)
	// ปรับแรงกระเด็นจากระเบิดคริสตัล/แองเคอร์ (ค่ายิ่งน้อยยิ่งกระเด็นน้อย)
	static final double KB_SCALE = 0.55;        // ตัวคูณแรงกระเด็นรวม
	static final double KB_MAX_HORIZONTAL = 0.95; // ความเร็วแนวนอนสูงสุดหลังโดนระเบิด (บล็อก/tick)
	static final double KB_MAX_VERTICAL = 0.80;   // ความเร็วแนวตั้งสูงสุดหลังโดนระเบิด
	static final double[] SPAWN_A = {137.5, 61, 44.5};  // 137 61 44 (หันไป +z)
	static final double[] SPAWN_B = {137.5, 61, 98.5};  // 137 61 98 (หันไป -z)

	// สนาม Crystal PvP: ทุกคู่ใช้พิกัดชุดนี้ร่วมกัน (โลกเดียวกัน) แต่แยกกันเด็ดขาด
	static final String CRYSTAL_ARENA = "cy1";
	static final double[] CRYSTAL_SPAWN_A = {-886.5, 64, -689.5};  // -887 64 -690 (หันไป -x)
	static final double[] CRYSTAL_SPAWN_B = {-920.5, 64, -689.5};  // -921 64 -690 (หันไป +x)
	static final float CRYSTAL_YAW_A = 90f, CRYSTAL_YAW_B = -90f;
	// ระเบิดแล้วพื้น/บล็อกเดิมของสนามเป็นหลุมด้วยไหม (ตอนนี้เป็นบล็อกจริงในสำเนาสนาม จึงไม่บั๊กแล้ว)
	// สนามจริงที่คุณสร้างจะไม่ถูกแตะ: ปลั๊กอินก๊อปสนามไปวางเป็นสำเนา แล้วให้แต่ละคู่เล่นในสำเนาของตัวเอง
	static final boolean CRATERS = true;
	static final boolean GIVE_OBSIDIAN = true;  // แจก obsidian ให้วางฐานคริสตัล
	static final int MAX_FAKE_BLOCKS = 30000;   // จำกัดจำนวนบล็อกที่วาง/พังต่อตา (รวมหลุมระเบิด)
	static final int CRYSTAL_INSTANCES = 8;     // จำนวนสำเนาสนาม = จำนวนคู่ที่เล่น Crystal พร้อมกันได้ (config: crystal.instances)
	static final int MAX_CRYSTAL_INSTANCES = 32; // เพดานจำนวนสำเนา (กันก๊อปสนามหนักเกิน)
	static final int CRYSTAL_STRIDE_Z = 200;    // ระยะห่างแกน Z ระหว่างสำเนา (config: crystal.stride-z)
	static final int REGION_PAD_XZ = 40;        // ขอบเขตสนามเริ่มต้น = รอบจุดเกิดทั้ง 2 ฝั่ง +- ค่านี้ (ตั้งเองได้ด้วย /cyregion)
	static final int REGION_Y_BELOW = 32, REGION_Y_ABOVE = 48;
	static final int COPY_COLUMNS_PER_TICK = 4; // ก๊อปทีละกี่คอลัมน์ชังค์ต่อ tick (กันเซิร์ฟกระตุก)
	static final int MAX_CRYSTAL_STACKS = 8;

	static final int QUEUE_WINS = 3;         // ดาบเพชร: ชนะ 3 ตาก่อน
	static final int IRON_WINS = 2;          // ดาบเหล็ก: 2 ใน 3 ตา (ปรับไม่ได้)
	static final int MAX_ROUNDS = 20;
	static final int INVITE_SECONDS = 60;

	// ช่องในเมนู Select a Kit  (สมุด Kit Editor อยู่ที่ hotbar ช่อง 9 ในล็อบบี้)
	static final int EDITOR_HOTBAR = 8;
	static final int KIT_SLOT = 10;          // ดาบ
	static final int CRYSTAL_SLOT = 11;      // คริสตัล

	// ช่องปุ่มใน Kit Editor
	static final int ED_ROOM = 3;            // ธงเขียว  -> Kit Room
	static final int ED_OK = 4;              // ธงม่วง   -> ตกลง (บันทึก)
	static final int ED_CANCEL = 5;          // ธงแดง    -> ยกเลิก
	static final int ED_RESET = 6;           // ธงส้ม    -> รีเซต
	// ช่องใน Kit Room (หน้าตาตามรูป)
	static final int ROOM_TAB_GEAR = 0;       // ดาบ     -> หน้าอุปกรณ์ (เกราะ/ดาบ/อาวุธ/ลูกธนู)
	static final int ROOM_TAB_CRYSTAL = 2;    // คริสตัล -> หน้าของ Crystal PvP
	static final int ROOM_EQUIP_FIRST = 45;   // 45-48 = หมวก/เสื้อ/กางเกง/รองเท้าที่ใส่อยู่
	static final int ROOM_OFFHAND = 49;       // มือรอง
	static final int ROOM_RESET = 51;         // สีย้อมม่วง = รีเซต Kit กลับเป็นค่าเริ่มต้น
	static final int ROOM_SAVE = 52;          // สีย้อมเขียว = บันทึก Kit
	static final int ROOM_CANCEL = 53;        // สีย้อมแดง = ยกเลิก
	static final int KIT_SIZE = 41;           // 0-35 ช่องเก็บของ, 36-39 รองเท้า/กางเกง/เสื้อ/หมวก, 40 มือรอง
	// =====================

	public interface DuelCallback { void accept(Player p, String opponentName, int rounds); }

	record Invite(UUID from, int rounds, boolean crystal, long time) {}
	record QEntry(Player player, int rounds, boolean crystal) {}
	record Cell(int x, int y, int z, BlockData data, BlockData orig) {}

	static final class Match {
		final Player a, b;
		final int target;
		final boolean crystal;
		final int[] score = new int[2];
		/** บันทึกบล็อกที่ถูกวาง/พังในสำเนาสนามของคู่นี้ (เก็บค่าเดิมไว้คืนตอนจบตา) */
		final Map<Long, Cell> fake = new HashMap<>();
		final Set<EnderCrystal> crystals = new HashSet<>();
		/** ของที่ผู้เล่นทิ้งในสำเนาสนาม (ไว้เคลียร์ตอนจบตา แม้ตกออกนอกขอบเขต) */
		final Set<org.bukkit.entity.Item> drops = new HashSet<>();
		int round, token;
		int slot = -1, dz;   // สำเนาสนามที่ใช้ (Crystal) และระยะเลื่อนแกน Z ของสำเนานั้น
		boolean live, ended;
		Match(Player a, Player b, int target, boolean crystal) { this.a = a; this.b = b; this.target = target; this.crystal = crystal; }
		Player other(Player p) { return p == a ? b : a; }
		int idx(Player p) { return p == a ? 0 : 1; }
	}

	static final class KitMenu implements InventoryHolder {
		final String mode; final UUID target; Inventory inv;
		KitMenu(String mode, UUID target) { this.mode = mode; this.target = target; }
		@Override public Inventory getInventory() { return inv; }
	}

	static final class RoundsMenu implements InventoryHolder {
		final UUID target; final boolean crystal; Inventory inv;
		RoundsMenu(UUID target, boolean crystal) { this.target = target; this.crystal = crystal; }
		@Override public Inventory getInventory() { return inv; }
	}

	static final class PickMenu implements InventoryHolder {
		final Map<Integer, UUID> slots = new HashMap<>(); Inventory inv;
		@Override public Inventory getInventory() { return inv; }
	}

	static final class EditorMenu implements InventoryHolder {
		Inventory inv;
		@Override public Inventory getInventory() { return inv; }
	}

	static final class RoomMenu implements InventoryHolder {
		Inventory inv;
		int page;                                                   // 0 = อุปกรณ์, 1 = Crystal
		final Map<Integer, ItemStack> catalog = new HashMap<>();    // ช่อง -> ของต้นแบบในหน้านี้
		@Override public Inventory getInventory() { return inv; }
	}

	private NamespacedKey itemKey;
	private boolean floodgate;
	private boolean internalDamage;   // true ตอนเราสั่งดาเมจระเบิดเอง
	private File kitFile;
	private final Map<UUID, QEntry> queue = new LinkedHashMap<>();
	private final Map<UUID, Invite> invites = new HashMap<>();
	private final Map<UUID, Match> matches = new HashMap<>();
	private final Map<UUID, Long> lastUse = new HashMap<>();
	private final Map<UUID, String[]> kits = new HashMap<>();          // layout 36 ช่อง: null / "sword" / "crystal"
	private final Set<UUID> editing = new HashSet<>();
	private final Set<UUID> swordEditing = new HashSet<>();                // คนที่กำลังจัด Kit ดาบแบบง่าย (ไม่ใช่ Kit Crystal)
	private final Map<UUID, ItemStack[]> crystalKits = new HashMap<>();   // Kit คริสตัลที่จัดเอง (41 ช่อง: ของ+เกราะ+มือรอง)
	private File crystalKitFile;
	private final Map<UUID, Match> crystalOwner = new HashMap<>();     // คริสตัลแต่ละอัน เป็นของแมตช์ไหน
	private int instances = CRYSTAL_INSTANCES, strideZ = CRYSTAL_STRIDE_Z;
	// สำเนาสนามสร้างเมื่อมีคู่ ลบเมื่อไม่มีคู่: สถานะของแต่ละช่อง
	private static final int SL_EMPTY = 0, SL_BUILDING = 1, SL_READY = 2, SL_CLEARING = 3;
	private boolean[] slotBusy = new boolean[0], slotPendingClear = new boolean[0];
	private int[] slotState = new int[0], slotRemaining = new int[0];
	private Runnable[] slotDone = new Runnable[0];
	private final Deque<int[]> slotJobs = new ArrayDeque<>();   // {slot, cx, cz, 1=ก๊อป / 0=ลบ}
	private org.bukkit.scheduler.BukkitTask slotTask;

	@Override
	public void onEnable() {
		itemKey = new NamespacedKey(this, "duel_item");
		floodgate = Bukkit.getPluginManager().getPlugin("floodgate") != null;
		saveDefaultConfig();   // สร้าง config.yml (crystal.instances = จำนวนคู่ Crystal พร้อมกัน) ถ้ายังไม่มี
		loadKits();
		loadCrystalKits();
		instances = Math.max(1, Math.min(MAX_CRYSTAL_INSTANCES, getConfig().getInt("crystal.instances", CRYSTAL_INSTANCES)));
		strideZ = getConfig().getInt("crystal.stride-z", CRYSTAL_STRIDE_Z);
		if (strideZ == 0) strideZ = CRYSTAL_STRIDE_Z;
		slotBusy = new boolean[instances];
		slotPendingClear = new boolean[instances];
		slotState = new int[instances];
		slotRemaining = new int[instances];
		slotDone = new Runnable[instances];
		Bukkit.getPluginManager().registerEvents(this, this);
		later(40, this::clearIdleCopies);   // ล้างสำเนาที่ค้างจากรอบก่อน (สำเนาจะถูกสร้างตอนมีคู่เท่านั้น)
		// สนามคริสตัล: ล็อกเป็นเวลาเช้า ฟ้าโปร่ง และเก็บมอนที่ค้างอยู่ออก
		Bukkit.getScheduler().runTaskTimer(this, () -> {
			World cw = Bukkit.getWorld(CRYSTAL_ARENA);
			if (cw == null) return;
			if (cw.getTime() != 1000L) cw.setTime(1000L);
			if (cw.hasStorm()) cw.setStorm(false);
			if (cw.isThundering()) cw.setThundering(false);
			for (org.bukkit.entity.Entity en : cw.getEntities()) {
				if (en instanceof org.bukkit.entity.Mob) en.remove();
			}
		}, 40L, 100L);
		Bukkit.getScheduler().runTaskTimer(this, () -> {
			tryPairCrystal();
			for (QEntry q : queue.values()) {
				if (q.player().isOnline()) {
					q.player().sendActionBar(c("&eกำลังหาคู่... &7(" + kitName(q.crystal()) + ", " + q.rounds() + " rounds) กดดาบอีกครั้งเพื่อยกเลิก"));
				}
			}
		}, 20L, 40L);
		getLogger().info("Floodgate: " + (floodgate ? "พบ (ผู้เล่น Bedrock ใช้ฟอร์ม)" : "ไม่พบ"));
	}

	@Override
	public void onDisable() {
		for (Match m : new HashSet<>(matches.values())) {
			if (m.crystal) clearArena(m);
		}
	}

	// ---------- helpers ----------

	private Component c(String s) {
		return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
	}

	private Component itemName(String s) {
		return c(s).decoration(TextDecoration.ITALIC, false);
	}

	private String kitName(boolean crystal) { return crystal ? "Crystal PVP" : "Sword PVP"; }

	private void later(int ticks, Runnable r) {
		Bukkit.getScheduler().runTaskLater(this, r, Math.max(1, ticks));
	}

	private boolean throttle(Player p, long ms) {
		long now = System.currentTimeMillis();
		Long last = lastUse.get(p.getUniqueId());
		if (last != null && now - last < ms) return true;
		lastUse.put(p.getUniqueId(), now);
		return false;
	}

	private boolean inLobby(Player p) { return p.getWorld().getName().equals(LOBBY); }

	private boolean protectedWorld(Player p) {
		String w = p.getWorld().getName();
		return w.equals(LOBBY) || w.equals(ARENA) || w.equals(CRYSTAL_ARENA);
	}

	private boolean isFree(Player p) {
		return p != null && p.isOnline() && inLobby(p) && !matches.containsKey(p.getUniqueId());
	}

	private World arenaWorld(String name) {
		World w = Bukkit.getWorld(name);
		if (w == null) w = Bukkit.createWorld(new WorldCreator(name)); // โหลดโลกที่มีอยู่แล้ว
		return w;
	}

	private void title(Player p, String t, String sub, int stayMs) {
		p.showTitle(Title.title(c(t), c(sub),
			Title.Times.times(Duration.ZERO, Duration.ofMillis(stayMs), Duration.ZERO)));
	}

	private ItemStack tagged(Material m, String name, String tag) {
		ItemStack it = new ItemStack(m);
		ItemMeta meta = it.getItemMeta();
		meta.displayName(itemName(name));
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, tag);
		it.setItemMeta(meta);
		return it;
	}

	private ItemStack named(Material m, String name, String... lore) {
		ItemStack it = new ItemStack(m);
		ItemMeta meta = it.getItemMeta();
		meta.displayName(itemName(name));
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		if (lore.length > 0) {
			List<Component> l = new ArrayList<>();
			for (String s : lore) l.add(itemName(s));
			meta.lore(l);
		}
		it.setItemMeta(meta);
		return it;
	}

	private void giveLobbyItems(Player p) {
		p.getInventory().clear();
		p.getInventory().setArmorContents(new ItemStack[4]);
		p.getInventory().setItem(0, tagged(Material.DIAMOND_SWORD, "&bหาคู่สู้ &7(Queue)", "queue"));
		p.getInventory().setItem(1, tagged(Material.IRON_SWORD, "&7สุ่มหาคู่ &7(2 ใน 3 ตา)", "duel"));
		p.getInventory().setItem(EDITOR_HOTBAR, tagged(Material.BOOK, "&eKit Editor &7(จัด Kit ดาบ/คริสตัล)", "editor"));
		p.getInventory().setHeldItemSlot(0);
		p.updateInventory();
	}

	private void resetPlayer(Player p) {
		p.setGameMode(GameMode.SURVIVAL);
		p.setFlying(false);
		p.setAllowFlight(false);
		for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
		AttributeInstance maxHp = p.getAttribute(Attribute.MAX_HEALTH);
		p.setHealth(maxHp != null ? maxHp.getValue() : 20.0);
		p.addPotionEffect(new PotionEffect(PotionEffectType.INSTANT_HEALTH, 1, 5));
		p.setFoodLevel(20);
		p.setSaturation(20f);
		p.setFireTicks(0);
		p.setFallDistance(0f);
		p.setVelocity(new Vector(0, 0, 0));
	}

	// ---------- kit layout (บันทึกลงไฟล์ kits.yml) ----------

	private static String[] defaultLayout() {
		String[] d = new String[36];
		d[0] = "sword";
		d[1] = "crystal";
		return d;
	}

	private String[] layoutOf(Player p) {
		return kits.getOrDefault(p.getUniqueId(), defaultLayout());
	}

	private void loadKits() {
		kitFile = new File(getDataFolder(), "kits.yml");
		if (!kitFile.exists()) return;
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(kitFile);
		for (String k : cfg.getKeys(false)) {
			try {
				UUID id = UUID.fromString(k);
				List<String> l = cfg.getStringList(k);
				String[] a = new String[36];
				for (int i = 0; i < 36 && i < l.size(); i++) {
					String v = l.get(i);
					a[i] = ("sword".equals(v) || "crystal".equals(v)) ? v : null;
				}
				kits.put(id, a);
			} catch (IllegalArgumentException ignored) {}
		}
	}

	private void saveKits() {
		YamlConfiguration cfg = new YamlConfiguration();
		for (Map.Entry<UUID, String[]> en : kits.entrySet()) {
			List<String> l = new ArrayList<>();
			for (String v : en.getValue()) l.add(v == null ? "-" : v);
			cfg.set(en.getKey().toString(), l);
		}
		try {
			getDataFolder().mkdirs();
			cfg.save(kitFile != null ? kitFile : new File(getDataFolder(), "kits.yml"));
		} catch (IOException ex) {
			getLogger().warning("เซฟ kits.yml ไม่ได้: " + ex.getMessage());
		}
	}

	private void loadCrystalKits() {
		crystalKitFile = new File(getDataFolder(), "crystal-kits.yml");
		if (!crystalKitFile.exists()) return;
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(crystalKitFile);
		for (String k : cfg.getKeys(false)) {
			try {
				UUID id = UUID.fromString(k);
				List<?> l = cfg.getList(k);
				if (l == null) continue;
				ItemStack[] a = new ItemStack[KIT_SIZE];
				for (int i = 0; i < KIT_SIZE && i < l.size(); i++) {
					if (l.get(i) instanceof ItemStack it && !it.getType().isAir()) a[i] = it;
				}
				crystalKits.put(id, a);
			} catch (IllegalArgumentException ignored) {}
		}
	}

	private void saveCrystalKits() {
		YamlConfiguration cfg = new YamlConfiguration();
		for (Map.Entry<UUID, ItemStack[]> en : crystalKits.entrySet()) {
			cfg.set(en.getKey().toString(), Arrays.asList(en.getValue()));
		}
		try {
			getDataFolder().mkdirs();
			cfg.save(crystalKitFile);
		} catch (IOException ex) {
			getLogger().warning("เซฟ crystal-kits.yml ไม่ได้: " + ex.getMessage());
		}
	}

	// ---------- Kit Crystal: ของ + เกราะ + มือรอง (41 ช่อง) ----------
	// 0-35 = ช่องเก็บของ (0-8 hotbar), 36 รองเท้า, 37 กางเกง, 38 เสื้อ, 39 หมวก, 40 มือรอง

	private ItemStack[] kitOf(Player p) {
		ItemStack[] k = crystalKits.get(p.getUniqueId());
		return k != null ? k : defaultCrystalKit();
	}

	private static ItemStack cloneOrNull(ItemStack it) {
		return it == null || it.getType().isAir() ? null : it.clone();
	}

	private static ItemStack[] copyKit(ItemStack[] src) {
		ItemStack[] c = new ItemStack[KIT_SIZE];
		for (int i = 0; i < KIT_SIZE && i < src.length; i++) c[i] = cloneOrNull(src[i]);
		return c;
	}

	private static boolean isSword(ItemStack it) {
		return it != null && it.getType().name().endsWith("_SWORD");
	}

	private static boolean hasSword(ItemStack[] kit) {
		for (int i = 0; i < 36; i++) if (isSword(kit[i])) return true;
		return false;
	}

	private static int crystalStacks(ItemStack[] items) {
		int n = 0;
		for (int i = 0; i < 36 && i < items.length; i++) {
			if (items[i] != null && items[i].getType() == Material.END_CRYSTAL) n++;
		}
		return n;
	}

	/** กันโกง: จำกัดจำนวนสแตกคริสตัล และไม่ให้สแตกเกินขนาด */
	private void sanitizeKit(ItemStack[] kit) {
		int stacks = 0;
		for (int i = 0; i < KIT_SIZE; i++) {
			ItemStack it = kit[i];
			if (it == null) continue;
			if (it.getAmount() > it.getMaxStackSize()) it.setAmount(it.getMaxStackSize());
			if (it.getType() == Material.END_CRYSTAL && ++stacks > MAX_CRYSTAL_STACKS) kit[i] = null;
			else if (it.getType() == Material.OBSIDIAN && !GIVE_OBSIDIAN) kit[i] = null;
		}
	}

	/** อ่าน Kit จากอินเวนทอรี่จริงของผู้เล่น (ของที่ถืออยู่บนเมาส์ไม่นับ) */
	private ItemStack[] captureKit(Player p) {
		PlayerInventory inv = p.getInventory();
		ItemStack[] k = new ItemStack[KIT_SIZE];
		ItemStack[] st = inv.getStorageContents();
		for (int i = 0; i < 36 && i < st.length; i++) k[i] = cloneOrNull(st[i]);
		ItemStack[] ar = inv.getArmorContents();   // [รองเท้า, กางเกง, เสื้อ, หมวก]
		for (int i = 0; i < 4 && i < ar.length; i++) k[36 + i] = cloneOrNull(ar[i]);
		k[40] = cloneOrNull(inv.getItemInOffHand());
		return k;
	}

	/** ใส่ Kit ลงอินเวนทอรี่จริง (ล้างของเดิมทั้งหมด) */
	private void applyKit(Player p, ItemStack[] kit) {
		PlayerInventory inv = p.getInventory();
		inv.clear();
		ItemStack[] st = new ItemStack[36];
		for (int i = 0; i < 36; i++) st[i] = cloneOrNull(kit[i]);
		inv.setStorageContents(st);
		inv.setArmorContents(new ItemStack[]{
			cloneOrNull(kit[36]), cloneOrNull(kit[37]), cloneOrNull(kit[38]), cloneOrNull(kit[39])});
		inv.setItemInOffHand(cloneOrNull(kit[40]));
		p.updateInventory();
	}

	/** ช่องที่ดาบอยู่ (ใช้ตอนดวล Sword) — อิงจาก Kit ที่จัดไว้ ถ้าไม่มีใช้ layout เก่า */
	private int swordSlot(Player p) {
		UUID id = p.getUniqueId();
		String[] lay = kits.get(id);   // Kit ดาบที่จัดแบบง่าย (ปุ่มดาบใน Select a Kit)
		if (lay != null) {
			for (int i = 0; i < 36; i++) if ("sword".equals(lay[i])) return i;
		}
		ItemStack[] k = crystalKits.get(id);   // ไม่เคยจัด -> ใช้ตำแหน่งดาบจาก Kit Crystal
		if (k != null) {
			for (int i = 0; i < 36; i++) if (isSword(k[i])) return i;
		}
		return 0;
	}

	/** Kit เริ่มต้นของ Crystal PvP (ตอนยังไม่ได้จัด / กดรีเซต) */
	private ItemStack[] defaultCrystalKit() {
		ItemStack[] k = new ItemStack[KIT_SIZE];
		// hotbar
		k[0] = sword(Material.NETHERITE_SWORD);
		k[1] = full(Material.ENDER_PEARL);
		k[2] = full(Material.GOLDEN_APPLE);
		k[3] = full(Material.OBSIDIAN);
		k[4] = full(Material.END_CRYSTAL);
		k[5] = full(anchor());
		k[6] = full(Material.GLOWSTONE);
		k[7] = crossbowItem();
		k[8] = new ItemStack(Material.TOTEM_OF_UNDYING);
		// แถวบน
		k[9] = full(Material.ENDER_PEARL);
		k[10] = full(Material.ENDER_PEARL);
		for (int i = 11; i <= 16; i++) k[i] = new ItemStack(Material.TOTEM_OF_UNDYING);
		k[17] = axe(Material.NETHERITE_AXE);
		// แถวกลาง
		k[18] = full(Material.ENDER_PEARL);
		k[19] = full(Material.ENDER_PEARL);
		for (int i = 20; i <= 25; i++) k[i] = new ItemStack(Material.TOTEM_OF_UNDYING);
		k[26] = tool(Material.NETHERITE_PICKAXE);
		// แถวล่าง
		k[27] = full(Material.ENDER_PEARL);
		k[28] = full(Material.ENDER_PEARL);
		k[29] = full(Material.GOLDEN_APPLE);
		k[30] = full(Material.OBSIDIAN);
		k[31] = full(Material.END_CRYSTAL);
		k[32] = full(Material.EXPERIENCE_BOTTLE);
		k[33] = full(Material.EXPERIENCE_BOTTLE);
		k[34] = full(tippedArrow(PotionType.SLOW_FALLING));
		k[35] = unbreakingOnly(Material.SHIELD);
		// เกราะเนเธอไรต์ครบเซต + โทเท็มมือรอง
		k[36] = armorPiece(Material.NETHERITE_BOOTS);
		k[37] = armorPiece(Material.NETHERITE_LEGGINGS);
		k[38] = armorPiece(Material.NETHERITE_CHESTPLATE);
		k[39] = armorPiece(Material.NETHERITE_HELMET);
		k[40] = new ItemStack(Material.TOTEM_OF_UNDYING);
		return k;
	}

	// ---------- events: lobby ----------

	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		Player p = e.getPlayer();
		String w = p.getWorld().getName();
		if (w.equals(ARENA) || w.equals(CRYSTAL_ARENA)) {
			later(2, () -> toLobby(p));
		} else if (w.equals(LOBBY)) {
			giveLobbyItems(p);
		}
	}

	@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		Player p = e.getPlayer();
		UUID id = p.getUniqueId();
		queue.remove(id);
		invites.remove(id);
		lastUse.remove(id);
		editing.remove(id);
		swordEditing.remove(id);
		Match m = matches.get(id);
		if (m != null && !m.ended) endMatch(m, m.other(p));
	}

	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		if (!inLobby(p)) return;
		e.setCancelled(true);
		if (e.getHand() != EquipmentSlot.HAND) return;
		if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
		ItemStack it = e.getItem();
		if (it == null || !it.hasItemMeta()) return;
		String tag = it.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
		if (tag == null || throttle(p, 600)) return;

		if (tag.equals("editor")) {
			if (queue.containsKey(p.getUniqueId())) { p.sendMessage(c("&cออกจากคิวก่อนถึงจะจัด Kit ได้")); return; }
			openKitMenu(p, "edit", null);   // เลือก Sword / Crystal ก่อน
			return;
		}
		if (queue.remove(p.getUniqueId()) != null) {
			p.sendMessage(c("&cออกจากคิวแล้ว"));
			return;
		}
		if (tag.equals("queue")) {
			openKitMenu(p, "queue", null);
		} else if (tag.equals("duel")) {
			openKitMenu(p, "random", null);
		}
	}

	@EventHandler(priority = EventPriority.HIGH)
	public void onDamage(EntityDamageEvent e) {
		if (!(e.getEntity() instanceof Player v)) return;
		Match m = matches.get(v.getUniqueId());

		if (m != null) {
			if (!m.live) { e.setCancelled(true); return; }
			if (m.crystal && e.getCause() == EntityDamageEvent.DamageCause.FALL) { e.setCancelled(true); return; }
			// ดาเมจที่ไม่ได้มาจากคู่ต่อสู้ (รวมถึงระเบิดจริงจากที่อื่น) ไม่นับ — ยกเว้นระเบิดที่เราคำนวณเอง
			if (!internalDamage) {
				if (e instanceof EntityDamageByEntityEvent be && be.getDamager() != m.other(v)) {
					e.setCancelled(true);
					return;
				}
				if (e.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION
					|| e.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) {
					e.setCancelled(true);
					return;
				}
			}
			boolean fatal = e.getCause() == EntityDamageEvent.DamageCause.VOID || v.getHealth() - e.getFinalDamage() <= 0;
			if (fatal) {
				e.setCancelled(true);
				if (m.crystal && e.getCause() != EntityDamageEvent.DamageCause.VOID && popTotem(m, v)) return;
				winRound(m, m.other(v));
			}
			return;
		}

		if (protectedWorld(v)) {
			e.setCancelled(true);
			// ตีตัวคนในล็อบบี้ = ท้าดวล
			if (e instanceof EntityDamageByEntityEvent be
				&& be.getDamager() instanceof Player d
				&& d != v && inLobby(v) && inLobby(d) && !throttle(d, 1000)) {
				openKitMenu(d, "duel", v.getUniqueId());
			}
		}
	}

	/** โทเท็มในมือหลัก/มือรอง: กันตายหนึ่งครั้ง เหมือนในเกม (จำลองเอง เพราะเรายกเลิกความตายจริงไว้) */
	private boolean popTotem(Match m, Player v) {
		PlayerInventory inv = v.getInventory();
		if (inv.getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING) {
			inv.setItemInOffHand(null);
		} else if (inv.getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING) {
			inv.setItemInMainHand(null);
		} else {
			return false;
		}
		v.setHealth(1.0);
		v.clearActivePotionEffects();
		v.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 900, 1));
		v.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1));
		v.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 800, 0));
		Location l = v.getLocation().add(0, 1, 0);
		for (Player q : List.of(m.a, m.b)) {
			if (!q.isOnline() || q.getWorld() != v.getWorld()) continue;
			q.spawnParticle(Particle.TOTEM_OF_UNDYING, l, 40, 0.4, 0.6, 0.4, 0.3);
			q.playSound(l, Sound.ITEM_TOTEM_USE, SoundCategory.PLAYERS, 1f, 1f);
		}
		return true;
	}

	@EventHandler
	public void onMove(PlayerMoveEvent e) {
		Match m = matches.get(e.getPlayer().getUniqueId());
		if (m == null || m.live || m.ended) return;
		if (e.getPlayer().getGameMode() == GameMode.SPECTATOR) return;
		Location f = e.getFrom(), t = e.getTo();
		if (t == null) return;
		if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
			Location n = f.clone();
			n.setYaw(t.getYaw());
			n.setPitch(t.getPitch());
			e.setTo(n);
		}
	}

	@EventHandler
	public void onBreak(BlockBreakEvent e) {
		Player p = e.getPlayer();
		if (!protectedWorld(p)) return;
		e.setCancelled(true);   // ไม่ให้เกมทำลายจริง (กันของดรอป) -- Crystal ขุดได้ผ่านระบบของเราด้านล่าง
		Match m = matches.get(p.getUniqueId());
		if (m == null || !m.crystal || !m.live || m.ended) return;
		Block b = e.getBlock();
		World w = b.getWorld();
		if (!w.getName().equals(CRYSTAL_ARENA)) return;
		Material t = b.getType();
		if (t.isAir() || t.getHardness() < 0f || t == Material.BARRIER) return;   // เบดร็อก/บล็อกที่ทำลายไม่ได้
		int x = b.getX(), y = b.getY(), z = b.getZ();
		if (m.fake.size() >= MAX_FAKE_BLOCKS && !m.fake.containsKey(key(x, y, z))) {
			p.sendMessage(c("&cพังบล็อกเต็มแล้ว"));
			return;
		}
		BlockData old = b.getBlockData();
		setFake(m, w, x, y, z, Material.AIR.createBlockData());   // จำค่าเดิมไว้คืนตอนจบตา
		Location loc = new Location(w, x + 0.5, y + 0.5, z + 0.5);
		for (Player q : List.of(m.a, m.b)) {
			if (q.isOnline() && q.getWorld() == w) {
				q.playSound(loc, old.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1f, 0.8f);
			}
		}
	}
	@EventHandler public void onPlace(BlockPlaceEvent e) { if (protectedWorld(e.getPlayer())) e.setCancelled(true); }
	@EventHandler(ignoreCancelled = true)
	public void onDrop(PlayerDropItemEvent e) {
		Player p = e.getPlayer();
		if (!protectedWorld(p)) return;
		Match m = matches.get(p.getUniqueId());
		if (m != null && m.crystal && !m.ended && p.getWorld().getName().equals(CRYSTAL_ARENA)) {
			m.drops.add(e.getItemDrop());   // Crystal: ทิ้ง/โยนของได้ แล้วเคลียร์ตอนจบตา
			return;
		}
		e.setCancelled(true);
	}
	@EventHandler
	public void onSwap(PlayerSwapHandItemsEvent e) {
		Match m = matches.get(e.getPlayer().getUniqueId());
		if (m != null && m.crystal) return;   // Crystal: สลับโทเท็มเข้ามือรองได้
		if (protectedWorld(e.getPlayer())) e.setCancelled(true);
	}

	@EventHandler
	public void onFood(FoodLevelChangeEvent e) {
		if (e.getEntity() instanceof Player p && protectedWorld(p)) e.setCancelled(true);
	}

	/** บล็อกปลอมที่ผู้เล่นยืนอยู่ เซิร์ฟมองเป็นอากาศ -> เปิด allowFlight กันโดนเตะ แต่ห้ามบินจริง */
	@EventHandler
	public void onToggleFlight(PlayerToggleFlightEvent e) {
		Player p = e.getPlayer();
		Match m = matches.get(p.getUniqueId());
		if (m != null && m.crystal && p.getGameMode() == GameMode.SURVIVAL && e.isFlying()) e.setCancelled(true);
	}

	// ระเบิดจริงในสนามคริสตัลไม่ต้องมี (เราคำนวณเอง) กันไว้เผื่อมีอะไรหลุดมา
	/** ล็อบบี้ + สนามคริสตัล (และสำเนา): ไม่ให้มอนเกิด */
	@EventHandler
	public void onMobSpawn(org.bukkit.event.entity.CreatureSpawnEvent e) {
		String wn = e.getLocation().getWorld().getName();
		if (wn.equals(CRYSTAL_ARENA) || wn.equals(LOBBY)) e.setCancelled(true);   // ล็อบบี้ (lp) + สนามคริสตัล: ไม่ให้มอนเกิด
	}

	@EventHandler public void onEntityExplode(EntityExplodeEvent e) { if (e.getEntity().getWorld().getName().equals(CRYSTAL_ARENA)) e.setCancelled(true); }
	@EventHandler public void onBlockExplode(BlockExplodeEvent e) { if (e.getBlock().getWorld().getName().equals(CRYSTAL_ARENA)) e.setCancelled(true); }

	@EventHandler
	public void onDrag(InventoryDragEvent e) {
		if (!(e.getWhoClicked() instanceof Player p)) return;
		InventoryHolder h = e.getView().getTopInventory().getHolder();
		if (h instanceof EditorMenu || h instanceof RoomMenu) {
			int size = e.getView().getTopInventory().getSize();
			for (int raw : e.getRawSlots()) if (raw < size) { e.setCancelled(true); break; }
			return;
		}
		Match inMatch = matches.get(p.getUniqueId());
		if (!(h instanceof KitMenu) && !(h instanceof RoundsMenu) && !(h instanceof PickMenu)
			&& inMatch != null && inMatch.crystal && !inMatch.ended) {
			int size = e.getView().getTopInventory().getSize();   // ลากในอินเวนทอรี่ตัวเองได้ แต่ห้ามลงช่องคราฟต์
			for (int raw : e.getRawSlots()) if (raw < size) { e.setCancelled(true); break; }
			return;
		}
		if (h instanceof KitMenu || h instanceof RoundsMenu || h instanceof PickMenu
			|| (protectedWorld(p) && p.getGameMode() != GameMode.CREATIVE)) {
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void onClick(InventoryClickEvent e) {
		if (!(e.getWhoClicked() instanceof Player p)) return;
		Inventory top = e.getView().getTopInventory();
		InventoryHolder h = top.getHolder();
		boolean inTop = e.getClickedInventory() == top;

		if (h instanceof KitMenu km) {
			e.setCancelled(true);
			if (!inTop) return;
			int s = e.getSlot();
			if (s == KIT_SLOT || s == CRYSTAL_SLOT) {
				final boolean crystal = s == CRYSTAL_SLOT;
				p.closeInventory();
				later(5, () -> {
					if (!isFree(p)) return;
					if (km.mode.equals("edit")) {
						if (queue.containsKey(p.getUniqueId())) { p.sendMessage(c("&cออกจากคิวก่อนถึงจะจัด Kit ได้")); return; }
						if (crystal) openEditor(p); else openSwordEditor(p);
					} else if (km.mode.equals("queue")) {
						openQueueUi(p, crystal);
					} else if (km.mode.equals("random")) {
						joinQueue(p, IRON_WINS, crystal);
					} else {
						Player t = km.target == null ? null : Bukkit.getPlayer(km.target);
						if (t != null) openDuelUi(p, t, crystal);
					}
				});
			}
			return;
		}
		if (h instanceof EditorMenu || h instanceof RoomMenu) {
			handleKitClick(e, p, h, inTop);
			return;
		}
		if (h instanceof PickMenu pm) {
			e.setCancelled(true);
			UUID tid = inTop ? pm.slots.get(e.getSlot()) : null;
			if (tid != null) {
				p.closeInventory();
				later(5, () -> {
					Player t = Bukkit.getPlayer(tid);
					if (!isFree(p)) return;
					if (!isFree(t)) { p.sendMessage(c("&cผู้เล่นไม่ว่าง")); return; }
					openDuelUi(p, t, false);
				});
			}
			return;
		}
		if (h instanceof RoundsMenu rm) {
			e.setCancelled(true);
			if (inTop && e.getSlot() >= 0 && e.getSlot() < MAX_ROUNDS) {
				int rounds = e.getSlot() + 1;
				p.closeInventory();
				Player t = rm.target == null ? null : Bukkit.getPlayer(rm.target);
				later(2, () -> {
					if (rm.target == null) { joinQueue(p, rounds, rm.crystal); return; }
					if (t == null) { p.sendMessage(c("&cหาผู้เล่นไม่เจอ")); return; }
					sendInvite(p, t, rounds, rm.crystal);
				});
			}
			return;
		}
		Match inMatch = matches.get(p.getUniqueId());
		if (inMatch != null && inMatch.crystal && !inMatch.ended) {
			// Crystal: สลับของในช่องเก็บของ/แถบด่วน/เกราะ/มือรองได้ตามปกติ (ช่องคราฟต์ยังห้าม)
			if (!(e.getClickedInventory() instanceof PlayerInventory)) e.setCancelled(true);
			return;
		}
		if (protectedWorld(p) && p.getGameMode() != GameMode.CREATIVE) e.setCancelled(true);
	}

	// ---------- menu + form ----------

	private void openKitMenu(Player p, String mode, UUID target) {
		KitMenu h = new KitMenu(mode, target);
		Inventory inv = Bukkit.createInventory(h, 54, c("Select a Kit"));
		h.inv = inv;
		inv.setItem(KIT_SLOT, named(Material.DIAMOND_SWORD, "&bSword"));
		inv.setItem(CRYSTAL_SLOT, named(Material.END_CRYSTAL, "&dCrystal PvP", "&7ระเบิดคริสตัล + วางบล็อก"));
		p.openInventory(inv);
	}

	private void openPlayerPicker(Player p) {
		PickMenu h = new PickMenu();
		Inventory inv = Bukkit.createInventory(h, 54, c("Select a Player"));
		h.inv = inv;
		int slot = 0;
		for (Player q : Bukkit.getOnlinePlayers()) {
			if (q == p || !isFree(q) || slot >= 54) continue;
			ItemStack head = new ItemStack(Material.PLAYER_HEAD);
			SkullMeta sm = (SkullMeta) head.getItemMeta();
			sm.setOwningPlayer(q);
			sm.displayName(itemName("&e" + q.getName()));
			sm.lore(List.of(itemName("&7กดเพื่อท้าดวล")));
			head.setItemMeta(sm);
			inv.setItem(slot, head);
			h.slots.put(slot, q.getUniqueId());
			slot++;
		}
		if (h.slots.isEmpty()) {
			p.sendMessage(c("&cไม่มีผู้เล่นให้ท้าตอนนี้"));
			return;
		}
		p.openInventory(inv);
	}

	/** เลือกจำนวน Rounds ก่อนเข้าคิว: Bedrock = ฟอร์มสไลเดอร์, Java = เมนูกล่อง */
	private void openQueueUi(Player p, boolean crystal) {
		if (floodgate && FloodForms.isBedrock(p)) {
			FloodForms.sendQueue(this, p, crystal ? "Crystal" : "Sword", QUEUE_WINS, (pl, o, rounds) -> {
				if (isFree(pl)) joinQueue(pl, rounds, crystal);
			});
			return;
		}
		RoundsMenu h = new RoundsMenu(null, crystal);
		Inventory inv = Bukkit.createInventory(h, 27, c("Rounds (Queue)"));
		h.inv = inv;
		for (int i = 1; i <= MAX_ROUNDS; i++) {
			ItemStack it = new ItemStack(Material.PAPER, i);
			ItemMeta meta = it.getItemMeta();
			meta.displayName(itemName("&e" + i + " rounds"));
			it.setItemMeta(meta);
			inv.setItem(i - 1, it);
		}
		p.openInventory(inv);
	}

	private void openDuelUi(Player p, Player target, boolean crystal) {
		boolean bedrock = floodgate && FloodForms.isBedrock(p);

		if (bedrock) {
			List<String> names = new ArrayList<>();
			if (target == null) {
				for (Player q : Bukkit.getOnlinePlayers()) {
					if (q != p && isFree(q)) names.add(q.getName());
				}
				if (names.isEmpty()) {
					p.sendMessage(c("&cไม่มีผู้เล่นให้ท้าตอนนี้"));
					return;
				}
			}
			FloodForms.sendDuel(this, p, target, names, crystal ? "Crystal" : "Sword", (pl, opp, rounds) -> {
				Player t = target != null ? target : (opp == null ? null : Bukkit.getPlayerExact(opp));
				if (t == null) { pl.sendMessage(c("&cหาผู้เล่นไม่เจอ")); return; }
				sendInvite(pl, t, rounds, crystal);
			});
			return;
		}

		// ผู้เล่น Java: เลือก rounds ผ่านเมนูกล่อง (ต้องตีตัวผู้เล่นเพื่อท้า)
		if (target == null) {
			p.sendMessage(c("&eใช้ดาบตีตัวผู้เล่นที่ต้องการท้าได้เลย"));
			return;
		}
		RoundsMenu h = new RoundsMenu(target.getUniqueId(), crystal);
		Inventory inv = Bukkit.createInventory(h, 27, c("Rounds vs " + target.getName()));
		h.inv = inv;
		for (int i = 1; i <= MAX_ROUNDS; i++) {
			ItemStack it = new ItemStack(Material.PAPER, i);
			ItemMeta meta = it.getItemMeta();
			meta.displayName(itemName("&e" + i + " rounds"));
			it.setItemMeta(meta);
			inv.setItem(i - 1, it);
		}
		p.openInventory(inv);
	}

	// ---------- Kit Editor / Kit Room ----------
	// อินเวนทอรี่จริงของผู้เล่น (ด้านล่าง) คือ Kit ที่จัด ลาก/สลับได้เอง ส่วนกล่องด้านบนคือปุ่มกับของให้กดเพิ่ม

	private static final Set<InventoryAction> EDIT_OK = EnumSet.of(
		InventoryAction.PICKUP_ALL, InventoryAction.PICKUP_HALF, InventoryAction.PICKUP_ONE, InventoryAction.PICKUP_SOME,
		InventoryAction.PLACE_ALL, InventoryAction.PLACE_ONE, InventoryAction.PLACE_SOME,
		InventoryAction.SWAP_WITH_CURSOR, InventoryAction.HOTBAR_SWAP, InventoryAction.HOTBAR_MOVE_AND_READD,
		InventoryAction.NOTHING);

	// ----- ไอเทมต้นแบบ (ใช้ทั้งใน Kit Room และ Kit เริ่มต้น) -----

	private static ItemStack withEnchants(Material m, Object... pairs) {
		ItemStack it = new ItemStack(m);
		ItemMeta meta = it.getItemMeta();
		for (int i = 0; i + 1 < pairs.length; i += 2) {
			meta.addEnchant((Enchantment) pairs[i], (Integer) pairs[i + 1], true);
		}
		it.setItemMeta(meta);
		return it;
	}

	/** เกราะครบเซตสำหรับ Crystal PvP: กางเกง-รองเท้า Blast Protection IV / หมวก-เกราะอก Protection IV + Unbreaking III + Mending (+ ของเฉพาะชิ้น) */
	private static ItemStack armorPiece(Material m) {
		String n = m.name();
		Enchantment prot = (n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS")) ? Enchantment.BLAST_PROTECTION : Enchantment.PROTECTION;   // กางเกง+รองเท้า = Blast IV, หมวก+เกราะอก = Protection IV
		ItemStack it = withEnchants(m, prot, 4, Enchantment.UNBREAKING, 3, Enchantment.MENDING, 1);
		ItemMeta meta = it.getItemMeta();
		if (n.endsWith("_HELMET")) {
			meta.addEnchant(Enchantment.RESPIRATION, 3, true);
			meta.addEnchant(Enchantment.AQUA_AFFINITY, 1, true);
		} else if (n.endsWith("_LEGGINGS")) {
			meta.addEnchant(Enchantment.SWIFT_SNEAK, 3, true);
		} else if (n.endsWith("_BOOTS")) {
			meta.addEnchant(Enchantment.FEATHER_FALLING, 4, true);
			meta.addEnchant(Enchantment.DEPTH_STRIDER, 3, true);
			meta.addEnchant(Enchantment.SOUL_SPEED, 3, true);
		}
		it.setItemMeta(meta);
		return it;
	}

	private static ItemStack sword(Material m) {
		return withEnchants(m, Enchantment.SHARPNESS, 5, Enchantment.FIRE_ASPECT, 2, Enchantment.LOOTING, 3,
			Enchantment.SWEEPING_EDGE, 3, Enchantment.UNBREAKING, 3, Enchantment.MENDING, 1);
	}

	private static ItemStack axe(Material m) {
		return withEnchants(m, Enchantment.SHARPNESS, 5, Enchantment.EFFICIENCY, 5,
			Enchantment.UNBREAKING, 3, Enchantment.MENDING, 1);
	}

	private static ItemStack tool(Material m) {
		return withEnchants(m, Enchantment.EFFICIENCY, 5, Enchantment.UNBREAKING, 3, Enchantment.MENDING, 1);
	}

	private static ItemStack unbreakingOnly(Material m) {
		return withEnchants(m, Enchantment.UNBREAKING, 3, Enchantment.MENDING, 1);
	}

	private static ItemStack crossbowItem() {
		return withEnchants(Material.CROSSBOW, Enchantment.QUICK_CHARGE, 3, Enchantment.PIERCING, 4,
			Enchantment.UNBREAKING, 3, Enchantment.MENDING, 1);
	}

	private static ItemStack bowItem() {
		return withEnchants(Material.BOW, Enchantment.POWER, 5, Enchantment.PUNCH, 2, Enchantment.FLAME, 1,
			Enchantment.UNBREAKING, 3, Enchantment.MENDING, 1);
	}

	private static ItemStack maceItem(boolean enchanted) {
		if (!enchanted) return new ItemStack(Material.MACE);
		return withEnchants(Material.MACE, Enchantment.WIND_BURST, 3, Enchantment.FIRE_ASPECT, 2,
			Enchantment.UNBREAKING, 3, Enchantment.MENDING, 1);
	}

	private static ItemStack tippedArrow(PotionType type) {
		ItemStack it = new ItemStack(Material.TIPPED_ARROW);
		PotionMeta pm = (PotionMeta) it.getItemMeta();
		pm.setBasePotionType(type);
		it.setItemMeta(pm);
		return it;
	}

	/** Respawn Anchor ที่สแตกได้ 64 (ในเกมปกติสแตกไม่ได้) */
	private static ItemStack anchor() {
		ItemStack it = new ItemStack(Material.RESPAWN_ANCHOR);
		ItemMeta meta = it.getItemMeta();
		meta.setMaxStackSize(64);
		it.setItemMeta(meta);
		return it;
	}

	/** ของที่หยิบจาก Kit Room มาเป็นสแตกเต็ม (เพิร์ล 16, ที่เหลือ 64, ของที่สแตกไม่ได้ = 1) */
	private static ItemStack full(ItemStack proto) {
		ItemStack it = proto.clone();
		it.setAmount(Math.max(1, it.getMaxStackSize()));
		return it;
	}

	private static ItemStack full(Material m) {
		return full(new ItemStack(m));
	}

	private static int armorIndex(Material m) {   // 0 หมวก, 1 เสื้อ, 2 กางเกง, 3 รองเท้า, -1 ไม่ใช่เกราะ
		String n = m.name();
		if (n.endsWith("_HELMET")) return 0;
		if (n.endsWith("_CHESTPLATE") || m == Material.ELYTRA) return 1;
		if (n.endsWith("_LEGGINGS")) return 2;
		if (n.endsWith("_BOOTS")) return 3;
		return -1;
	}

	private void equip(Player p, int idx, ItemStack it) {
		PlayerInventory inv = p.getInventory();
		switch (idx) {
			case 0 -> inv.setHelmet(it);
			case 1 -> inv.setChestplate(it);
			case 2 -> inv.setLeggings(it);
			case 3 -> inv.setBoots(it);
			default -> inv.setItemInOffHand(it);
		}
	}

	/** รายการของในแต่ละหน้าของ Kit Room: ช่อง -> ของต้นแบบ (จัดวางตามรูป) */
	private Map<Integer, ItemStack> roomCatalog(int page) {
		Map<Integer, ItemStack> m = new LinkedHashMap<>();
		if (page == 0) {   // หน้าอุปกรณ์ (กดดาบ)
			m.put(10, armorPiece(Material.NETHERITE_HELMET));
			m.put(11, armorPiece(Material.DIAMOND_HELMET));
			m.put(12, sword(Material.NETHERITE_SWORD));
			m.put(14, axe(Material.NETHERITE_AXE));
			m.put(15, tool(Material.NETHERITE_SHOVEL));
			m.put(16, tool(Material.NETHERITE_PICKAXE));
			m.put(19, armorPiece(Material.NETHERITE_CHESTPLATE));
			m.put(20, armorPiece(Material.DIAMOND_CHESTPLATE));
			m.put(21, unbreakingOnly(Material.ELYTRA));
			m.put(23, crossbowItem());
			m.put(24, bowItem());
			m.put(25, unbreakingOnly(Material.SHIELD));
			m.put(28, armorPiece(Material.NETHERITE_LEGGINGS));
			m.put(29, armorPiece(Material.DIAMOND_LEGGINGS));
			m.put(30, maceItem(false));
			m.put(32, new ItemStack(Material.SPECTRAL_ARROW));
			m.put(33, new ItemStack(Material.ARROW));
			m.put(34, tippedArrow(PotionType.SLOW_FALLING));
			m.put(37, armorPiece(Material.NETHERITE_BOOTS));
			m.put(38, armorPiece(Material.DIAMOND_BOOTS));
			m.put(39, maceItem(true));
			m.put(41, tippedArrow(PotionType.SLOWNESS));
			m.put(42, tippedArrow(PotionType.HARMING));
			m.put(43, tippedArrow(PotionType.POISON));
		} else {           // หน้า Crystal (กดคริสตัล)
			m.put(10, anchor());
			m.put(11, new ItemStack(Material.END_CRYSTAL));
			m.put(12, new ItemStack(Material.FIREWORK_ROCKET));
			m.put(14, new ItemStack(Material.TNT));
			m.put(15, new ItemStack(Material.COBWEB));
			m.put(16, new ItemStack(Material.TNT_MINECART));
			m.put(19, new ItemStack(Material.GLOWSTONE));
			m.put(20, new ItemStack(Material.OBSIDIAN));
			m.put(21, new ItemStack(Material.WIND_CHARGE));
			m.put(23, new ItemStack(Material.FLINT_AND_STEEL));
			m.put(24, new ItemStack(Material.FISHING_ROD));
			m.put(25, new ItemStack(Material.SLIME_BLOCK));
			m.put(28, new ItemStack(Material.TOTEM_OF_UNDYING));
			m.put(29, new ItemStack(Material.EXPERIENCE_BOTTLE));
			m.put(30, new ItemStack(Material.ENDER_PEARL));
			m.put(32, new ItemStack(Material.ANVIL));
			m.put(33, new ItemStack(Material.LADDER));
			m.put(34, new ItemStack(Material.OAK_BOAT));
			m.put(38, new ItemStack(Material.WATER_BUCKET));
			m.put(42, new ItemStack(Material.LAVA_BUCKET));
			m.put(43, new ItemStack(Material.GOLDEN_APPLE));
		}
		return m;
	}

	private static final String[] EQUIP_EMPTY = {
		"หมวก (ว่าง)", "เสื้อเกราะ (ว่าง)", "กางเกง (ว่าง)", "รองเท้า (ว่าง)", "มือรอง (ว่าง)"};

	private void fillRoom(RoomMenu rm, Player p) {
		Inventory inv = rm.inv;
		ItemStack pane = named(Material.GRAY_STAINED_GLASS_PANE, " ");
		for (int i = 0; i < 54; i++) inv.setItem(i, pane);

		if (rm.page == 2) {   // จัด Kit ดาบแบบง่าย: ไม่มีแท็บ/ของ/เกราะ มีแค่ปุ่มบันทึกกับยกเลิก
			rm.catalog.clear();
			inv.setItem(4, named(Material.DIAMOND_SWORD, "&bจัดตำแหน่งดาบ",
				"&7ลากดาบในช่องด้านล่างไปวางช่องที่ต้องการ", "&7แล้วกดสีเขียวเพื่อบันทึก"));
			inv.setItem(ROOM_SAVE, named(Material.LIME_DYE, "&aบันทึก Kit", "&7กดเพื่อบันทึก"));
			inv.setItem(ROOM_CANCEL, named(Material.RED_DYE, "&cยกเลิก", "&7ไม่บันทึก"));
			return;
		}

		// แท็บ: ดาบ = หน้าเกราะ/อาวุธ, คริสตัล = หน้าของ Crystal PvP (แท็บที่เปิดอยู่จะเรืองแสง)
		ItemStack sw = named(Material.NETHERITE_SWORD, "&bSword",
			rm.page == 0 ? "&aกำลังดูหน้านี้" : "&7กดเพื่อไปหน้าเกราะ/อาวุธ");
		ItemMeta sm = sw.getItemMeta();
		sm.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		sm.setEnchantmentGlintOverride(rm.page == 0);
		sw.setItemMeta(sm);
		inv.setItem(ROOM_TAB_GEAR, sw);

		ItemStack cr = named(Material.END_CRYSTAL, "&dCrystal PvP",
			rm.page == 1 ? "&aกำลังดูหน้านี้" : "&7กดเพื่อไปหน้าของคริสตัล");
		ItemMeta cm = cr.getItemMeta();
		cm.setEnchantmentGlintOverride(rm.page == 1);
		cr.setItemMeta(cm);
		inv.setItem(ROOM_TAB_CRYSTAL, cr);

		rm.catalog.clear();
		rm.catalog.putAll(roomCatalog(rm.page));
		for (Map.Entry<Integer, ItemStack> en : rm.catalog.entrySet()) {
			inv.setItem(en.getKey(), en.getValue().clone());
		}

		inv.setItem(ROOM_RESET, named(Material.PURPLE_DYE, "&dรีเซต Kit", "&7กลับเป็น Kit เริ่มต้น"));
		inv.setItem(ROOM_SAVE, named(Material.LIME_DYE, "&aบันทึก Kit", "&7กดเพื่อบันทึก"));
		inv.setItem(ROOM_CANCEL, named(Material.RED_DYE, "&cยกเลิก", "&7ไม่บันทึก"));
		refreshEquip(rm, p);
	}

	/** แถวล่างของ Kit Room แสดงเกราะ 4 ชิ้น + มือรอง ที่ผู้เล่นใส่อยู่ (หน้าต่างแบบนี้มองไม่เห็นช่องเกราะ) */
	private void refreshEquip(RoomMenu rm, Player p) {
		if (rm.page == 2) return;
		PlayerInventory pi = p.getInventory();
		ItemStack[] eq = {pi.getHelmet(), pi.getChestplate(), pi.getLeggings(), pi.getBoots(), pi.getItemInOffHand()};
		for (int i = 0; i < 5; i++) {
			ItemStack it = cloneOrNull(eq[i]);
			rm.inv.setItem(ROOM_EQUIP_FIRST + i,
				it != null ? it : named(Material.GRAY_STAINED_GLASS_PANE, "&7" + EQUIP_EMPTY[i]));
		}
	}

	/** กดคริสตัลใน Select a Kit = เข้า Kit Room (หน้าของคริสตัล) */
	private void openEditor(Player p) {
		editing.add(p.getUniqueId());
		swordEditing.remove(p.getUniqueId());
		applyKit(p, kitOf(p));
		openRoom(p, 1);
	}

	/** กดดาบใน Select a Kit = จัดตำแหน่งดาบแบบง่ายๆ: มีแต่ดาบ 1 เล่ม ลากไปวางช่องที่ต้องการ แล้วกดเขียว */
	private void openSwordEditor(Player p) {
		editing.add(p.getUniqueId());
		swordEditing.add(p.getUniqueId());
		PlayerInventory pi = p.getInventory();
		pi.clear();
		pi.setArmorContents(new ItemStack[4]);
		pi.setItemInOffHand(null);
		pi.setItem(swordSlot(p), new ItemStack(Material.DIAMOND_SWORD));
		p.updateInventory();
		openRoom(p, 2);
	}

	/** หน้าตาเหมือนรูป: ธงเขียว/ม่วง/แดง/ส้มแถวบน ของอยู่กลางกล่อง */
	private void openEditorMenu(Player p) {
		EditorMenu h = new EditorMenu();
		Inventory inv = Bukkit.createInventory(h, 54, c("Kit Editor"));
		h.inv = inv;
		inv.setItem(ED_ROOM, named(Material.LIME_BANNER, "&aKit Room", "&7เปิดห้องเพิ่มของ"));
		inv.setItem(ED_OK, named(Material.PURPLE_BANNER, "&dตกลง", "&7บันทึก Kit"));
		inv.setItem(ED_CANCEL, named(Material.RED_BANNER, "&cยกเลิก", "&7ไม่บันทึก"));
		inv.setItem(ED_RESET, named(Material.ORANGE_BANNER, "&6รีเซต", "&7กลับเป็น Kit เริ่มต้น"));
		inv.setItem(10, named(Material.NETHERITE_SWORD, "&bSword", "&7กดเพื่อเพิ่มดาบ"));
		ItemStack cr = named(Material.END_CRYSTAL, "&dEnd Crystal", "&7กดเพื่อเพิ่มคริสตัล 1 สแตก");
		ItemMeta m = cr.getItemMeta();
		m.setEnchantmentGlintOverride(true);
		cr.setItemMeta(m);
		inv.setItem(12, cr);
		p.openInventory(inv);
	}

	private void openRoom(Player p) { openRoom(p, 1); }

	private void openRoom(Player p, int page) {
		RoomMenu h = new RoomMenu();
		h.page = page;
		Inventory inv = Bukkit.createInventory(h, 54, c("Kit Room"));
		h.inv = inv;
		fillRoom(h, p);
		p.openInventory(inv);
	}

	/** ใส่ของลงช่องว่างช่องแรก (hotbar ก่อน); เกราะ -> ใส่ช่องเกราะเลย */
	private boolean addKitItem(Player p, ItemStack item) {
		int ai = armorIndex(item.getType());
		if (ai >= 0) { equip(p, ai, item); return true; }
		PlayerInventory inv = p.getInventory();
		if (item.getType() == Material.END_CRYSTAL && crystalStacks(inv.getStorageContents()) >= MAX_CRYSTAL_STACKS) {
			p.sendMessage(c("&eคริสตัลเต็มแล้ว (สูงสุด " + MAX_CRYSTAL_STACKS + " สแตก)"));
			return false;
		}
		int f = inv.firstEmpty();
		if (f < 0 || f > 35) { p.sendMessage(c("&cช่องเต็ม")); return false; }
		inv.setItem(f, item);
		p.updateInventory();
		return true;
	}

	private void saveEditor(Player p) {
		if (swordEditing.contains(p.getUniqueId())) {
			int slot = -1;
			ItemStack[] st = p.getInventory().getStorageContents();
			for (int i = 0; i < 36 && i < st.length; i++) {
				if (isSword(st[i])) { slot = i; break; }
			}
			if (slot < 0) { p.sendMessage(c("&cต้องมีดาบ (วางดาบลงในช่องก่อนบันทึก)")); return; }
			String[] lay = new String[36];
			lay[slot] = "sword";
			kits.put(p.getUniqueId(), lay);
			saveKits();
			editing.remove(p.getUniqueId());
			swordEditing.remove(p.getUniqueId());
			p.setItemOnCursor(null);
			p.closeInventory();
			giveLobbyItems(p);
			p.sendMessage(c("&aบันทึกตำแหน่งดาบแล้ว"));
			return;
		}
		ItemStack[] kit = captureKit(p);
		if (!hasSword(kit)) { p.sendMessage(c("&cต้องมีดาบอย่างน้อย 1 เล่ม")); return; }
		sanitizeKit(kit);
		crystalKits.put(p.getUniqueId(), kit);
		saveCrystalKits();
		editing.remove(p.getUniqueId());
		p.setItemOnCursor(null);
		p.closeInventory();
		giveLobbyItems(p);
		p.sendMessage(c("&aบันทึก Kit แล้ว"));
	}

	private void cancelEditor(Player p) {
		editing.remove(p.getUniqueId());
		swordEditing.remove(p.getUniqueId());
		p.setItemOnCursor(null);
		p.closeInventory();
		giveLobbyItems(p);
		p.sendMessage(c("&7ยกเลิกแล้ว"));
	}

	private void shrinkCursor(Player p) {
		ItemStack cur = p.getItemOnCursor();
		if (cur.getAmount() <= 1) {
			p.setItemOnCursor(null);
		} else {
			cur.setAmount(cur.getAmount() - 1);
			p.setItemOnCursor(cur);
		}
	}

	private void clickEditor(Player p, int slot) {
		if (slot == ED_ROOM) { later(1, () -> openRoom(p)); return; }
		if (slot == 10) { addKitItem(p, sword(Material.NETHERITE_SWORD)); return; }
		if (slot == 12) { addKitItem(p, full(Material.END_CRYSTAL)); return; }
		if (slot == ED_RESET) { applyKit(p, defaultCrystalKit()); return; }
		if (slot == ED_OK) { saveEditor(p); return; }
		if (slot == ED_CANCEL) cancelEditor(p);
	}

	/**
	 * Kit Room: คลิกของในกล่องบน = หยิบมาติดเมาส์ (ของในกล่องไม่หมด) แล้ววางลงอินเวนทอรี่ด้านล่าง
	 * วางของที่ถืออยู่กลับในกล่องบน = เอาออก; shift-click = ใส่ช่องว่าง/ใส่เกราะให้เลย
	 */
	private void clickRoom(Player p, RoomMenu rm, InventoryClickEvent e) {
		int slot = e.getSlot();
		ItemStack cursor = p.getItemOnCursor();
		boolean holding = !cursor.getType().isAir();

		if (rm.page == 2) {   // จัด Kit ดาบแบบง่าย
			if (slot == ROOM_SAVE) saveEditor(p);
			else if (slot == ROOM_CANCEL) cancelEditor(p);
			return;
		}
		if (slot == ROOM_SAVE) { saveEditor(p); return; }
		if (slot == ROOM_CANCEL) { cancelEditor(p); return; }
		if (slot == ROOM_RESET) {   // รีเซต: ล้างแล้วใส่ Kit เริ่มต้น (ยังไม่บันทึกจนกว่าจะกดเขียว)
			p.setItemOnCursor(null);
			applyKit(p, defaultCrystalKit());
			refreshEquip(rm, p);
			p.sendMessage(c("&eรีเซต Kit แล้ว &7(กดสีเขียวเพื่อบันทึก)"));
			return;
		}
		if (slot == ROOM_TAB_GEAR || slot == ROOM_TAB_CRYSTAL) {   // ดาบ = หน้าเกราะ/อาวุธ, คริสตัล = หน้าของคริสตัล
			int target = slot == ROOM_TAB_CRYSTAL ? 1 : 0;
			if (rm.page != target) {
				rm.page = target;
				fillRoom(rm, p);
			}
			return;
		}

		// แถวล่าง: เกราะที่ใส่อยู่ + มือรอง
		if (slot >= ROOM_EQUIP_FIRST && slot <= ROOM_OFFHAND) {
			int eq = slot - ROOM_EQUIP_FIRST;
			if (holding) {
				if (eq == 4) {
					p.getInventory().setItemInOffHand(cursor.clone());
					p.setItemOnCursor(null);
				} else if (armorIndex(cursor.getType()) == eq) {
					equip(p, eq, cursor.clone());
					p.setItemOnCursor(null);
				} else {
					p.sendMessage(c("&cใส่ในช่องนี้ไม่ได้"));
				}
			} else {
				equip(p, eq, null);   // คลิกเกราะที่ใส่อยู่ = ถอดทิ้ง
			}
			refreshEquip(rm, p);
			return;
		}

		if (holding) { p.setItemOnCursor(null); return; }   // วางกลับในห้อง = เอาออก
		ItemStack proto = rm.catalog.get(slot);
		if (proto == null) return;
		if (proto.getType() == Material.END_CRYSTAL
			&& crystalStacks(p.getInventory().getStorageContents()) >= MAX_CRYSTAL_STACKS) {
			p.sendMessage(c("&eคริสตัลเต็มแล้ว (สูงสุด " + MAX_CRYSTAL_STACKS + " สแตก)"));
			return;
		}
		ItemStack give = full(proto);
		if (e.getClick() == ClickType.NUMBER_KEY) {
			p.getInventory().setItem(e.getHotbarButton(), give);
			p.updateInventory();
		} else if (e.isShiftClick()) {
			addKitItem(p, give);
		} else {
			p.setItemOnCursor(give);
		}
		refreshEquip(rm, p);
	}

	/** คลิกในหน้าต่าง Kit Editor / Kit Room ทั้งหมด */
	private void handleKitClick(InventoryClickEvent e, Player p, InventoryHolder h, boolean inTop) {
		InventoryAction a = e.getAction();

		// คลิกนอกหน้าต่างพร้อมของบนเมาส์ = โยนทิ้ง -> ลบ ไม่ดรอปลงพื้น
		if (e.getClickedInventory() == null) {
			e.setCancelled(true);
			if (a == InventoryAction.DROP_ALL_CURSOR) p.setItemOnCursor(null);
			else if (a == InventoryAction.DROP_ONE_CURSOR) shrinkCursor(p);
			return;
		}
		if (inTop) {
			e.setCancelled(true);
			if (h instanceof EditorMenu) clickEditor(p, e.getSlot());
			else if (h instanceof RoomMenu rm) clickRoom(p, rm, e);
			return;
		}

		if (a == InventoryAction.DROP_ALL_SLOT || a == InventoryAction.DROP_ONE_SLOT) {
			// กด Q (หรือ Ctrl+Q) บนของในช่อง = เอาออก ไม่ดรอปลงพื้น
			e.setCancelled(true);
			ItemStack it = e.getCurrentItem();
			if (it != null && !it.getType().isAir()) {
				if (a == InventoryAction.DROP_ONE_SLOT && it.getAmount() > 1) {
					ItemStack rest = it.clone();
					rest.setAmount(it.getAmount() - 1);
					e.getClickedInventory().setItem(e.getSlot(), rest);
				} else {
					e.getClickedInventory().setItem(e.getSlot(), null);
				}
			}
		} else if (!EDIT_OK.contains(a)) {
			e.setCancelled(true);   // กัน shift-click / ดับเบิลคลิก ที่จะดึงของข้ามช่อง
		}
		if (h instanceof RoomMenu rm) {
			later(1, () -> { if (editing.contains(p.getUniqueId())) refreshEquip(rm, p); });
		}
	}

	/** ปิดหน้าต่างด้วย ESC = ยกเลิก (สลับ Editor<->Room ไม่นับ) */
	@EventHandler
	public void onEditorClose(InventoryCloseEvent e) {
		if (!(e.getPlayer() instanceof Player p)) return;
		InventoryHolder h = e.getInventory().getHolder();
		if (!(h instanceof EditorMenu) && !(h instanceof RoomMenu)) return;
		if (!editing.contains(p.getUniqueId())) return;
		p.setItemOnCursor(null);   // ของที่ถืออยู่ = เอาออก ไม่ให้เด้งกลับเข้าช่องหรือหล่นพื้น
		later(2, () -> {
			if (!p.isOnline() || !editing.contains(p.getUniqueId())) return;
			InventoryHolder now = p.getOpenInventory().getTopInventory().getHolder();
			if (now instanceof EditorMenu || now instanceof RoomMenu) return;
			editing.remove(p.getUniqueId());
			swordEditing.remove(p.getUniqueId());
			giveLobbyItems(p);
			p.sendMessage(c("&7ยกเลิกการจัด Kit (กดสีเขียวเพื่อบันทึก)"));
		});
	}

	// ---------- queue / invite ----------

	private void joinQueue(Player p, int rounds, boolean crystal) {
		if (!isFree(p)) return;
		rounds = Math.max(1, Math.min(MAX_ROUNDS, rounds));
		Iterator<Map.Entry<UUID, QEntry>> it = queue.entrySet().iterator();
		while (it.hasNext()) {
			QEntry q = it.next().getValue();
			if (!isFree(q.player())) { it.remove(); continue; }
			if (q.player() != p && q.rounds() == rounds && q.crystal() == crystal) {
				if (crystal && !crystalSlotFree()) {
					p.sendMessage(c("&eสนาม Crystal เต็มชั่วคราว รอสักครู่ ระบบจะเริ่มให้อัตโนมัติ"));
					break;   // เข้าคิวรอ แล้ว tryPairCrystal() จะจับคู่ให้ตอนมีสนามว่าง
				}
				it.remove();
				startMatch(q.player(), p, rounds, crystal);
				return;
			}
		}
		queue.put(p.getUniqueId(), new QEntry(p, rounds, crystal));
		p.sendMessage(c("&aเข้าคิวแล้ว &7(" + kitName(crystal) + ", " + rounds + " rounds) &aรอจนกว่าจะมีคนกดเหมือนกัน &7(กดดาบอีกครั้งเพื่อออกจากคิว)"));
	}

	private void sendInvite(Player from, Player to, int rounds, boolean crystal) {
		rounds = Math.max(1, Math.min(MAX_ROUNDS, rounds));
		if (!isFree(from) || !isFree(to) || from == to) {
			from.sendMessage(c("&cผู้เล่นไม่ว่าง"));
			return;
		}
		invites.put(to.getUniqueId(), new Invite(from.getUniqueId(), rounds, crystal, System.currentTimeMillis()));

		to.sendMessage(c("&e" + from.getName() + " &fท้าคุณสู้ &b" + kitName(crystal) + " &7(&f" + rounds + " rounds&7)"));
		Component accept = c("&a[ตกลง]").clickEvent(ClickEvent.runCommand("/accept"));
		Component deny = c("&c[ปฏิเสธ]").clickEvent(ClickEvent.runCommand("/deny"));
		to.sendMessage(accept.append(c(" &7= /accept    ")).append(deny).append(c(" &7= /deny")));
		from.sendMessage(c("&aส่งคำท้าให้ &e" + to.getName() + " &aแล้ว &7(หมดอายุใน " + INVITE_SECONDS + " วิ)"));
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (cmd.getName().equalsIgnoreCase("cyregion")) { regionCommand(sender, args); return true; }
		if (!(sender instanceof Player p)) return true;
		Invite inv = invites.remove(p.getUniqueId());
		if (inv == null || System.currentTimeMillis() - inv.time() > INVITE_SECONDS * 1000L) {
			p.sendMessage(c("&cไม่มีคำท้าที่รออยู่"));
			return true;
		}
		Player from = Bukkit.getPlayer(inv.from());

		if (cmd.getName().equalsIgnoreCase("deny")) {
			p.sendMessage(c("&cปฏิเสธแล้ว"));
			if (from != null) from.sendMessage(c("&e" + p.getName() + " &cปฏิเสธคำท้า"));
			return true;
		}
		if (!isFree(from) || !isFree(p)) {
			p.sendMessage(c("&cตอนนี้เริ่มดวลไม่ได้ (ผู้เล่นไม่ว่าง)"));
			return true;
		}
		if (inv.crystal() && !crystalSlotFree()) {
			p.sendMessage(c("&cสนาม Crystal เต็ม/ยังเตรียมไม่เสร็จ ลอง /accept ใหม่ไม่ได้ ให้อีกฝ่ายท้าใหม่อีกครั้ง"));
			from.sendMessage(c("&cสนาม Crystal เต็ม ลองท้าใหม่อีกสักครู่"));
			return true;
		}
		startMatch(from, p, inv.rounds(), inv.crystal());
		return true;
	}

	// ---------- match flow ----------

	private void startMatch(Player a, Player b, int target, boolean crystal) {
		String arenaName = crystal ? CRYSTAL_ARENA : ARENA;
		World arena = arenaWorld(arenaName);
		if (arena == null) {
			a.sendMessage(c("&cหาโลก " + arenaName + " ไม่เจอ"));
			b.sendMessage(c("&cหาโลก " + arenaName + " ไม่เจอ"));
			return;
		}
		int slot = -1;
		if (crystal) {
			if (!strideOk()) {
				a.sendMessage(c("&cตั้งค่าสนาม Crystal ไม่ถูกต้อง (stride-z) แจ้งแอดมิน"));
				b.sendMessage(c("&cตั้งค่าสนาม Crystal ไม่ถูกต้อง (stride-z) แจ้งแอดมิน"));
				return;
			}
			slot = allocSlot();
			if (slot < 0) {
				a.sendMessage(c("&cสนาม Crystal เต็ม/ยังเตรียมไม่เสร็จ ลองใหม่อีกสักครู่"));
				b.sendMessage(c("&cสนาม Crystal เต็ม/ยังเตรียมไม่เสร็จ ลองใหม่อีกสักครู่"));
				return;
			}
		}
		for (Player p : List.of(a, b)) {
			queue.remove(p.getUniqueId());
			invites.remove(p.getUniqueId());
		}
		Match m = new Match(a, b, target, crystal);
		m.slot = slot;
		m.dz = slot < 0 ? 0 : (slot + 1) * strideZ;
		matches.put(a.getUniqueId(), m);
		matches.put(b.getUniqueId(), m);

		Bukkit.broadcast(c("&b[Duel] &e" + a.getName() + " &fvs &e" + b.getName()
			+ " &7- " + kitName(crystal) + " (ชนะ " + target + " ตาก่อน)"));
		if (crystal && slotState[slot] != SL_READY) {   // สร้างสำเนาเมื่อมีคู่
			for (Player p : List.of(a, b)) p.sendMessage(c("&eกำลังเตรียมสนาม Crystal..."));
			requestBuild(slot, () -> {
				if (m.ended || !a.isOnline() || !b.isOnline()) return;
				startRound(m);
				hideOthers(m);
			});
			return;
		}
		startRound(m);
		hideOthers(m);
	}

	/** ซ่อนผู้เล่นคู่อื่นในสนาม ให้เห็นแค่คู่ของตัวเอง */
	private void hideOthers(Match m) {
		final String arenaName = m.crystal ? CRYSTAL_ARENA : ARENA;
		later(3, () -> {
			for (Player q : Bukkit.getOnlinePlayers()) {
				if (q == m.a || q == m.b || !q.getWorld().getName().equals(arenaName)) continue;
				for (Player p : List.of(m.a, m.b)) {
					if (p.isOnline()) {
						p.hidePlayer(this, q);
						q.hidePlayer(this, p);
					}
				}
			}
		});
	}

	private void giveKit(Player p, Match m) {
		PlayerInventory inv = p.getInventory();
		if (m.crystal) {
			// Crystal: ใช้ Kit ที่ผู้เล่นจัดไว้ใน Kit Editor (ยังไม่ได้จัด = Kit เริ่มต้น)
			ItemStack[] kit = copyKit(kitOf(p));
			sanitizeKit(kit);
			applyKit(p, kit);
			int held = 0;
			for (int i = 0; i < 9; i++) {
				if (isSword(kit[i])) { held = i; break; }
			}
			inv.setHeldItemSlot(held);
			p.updateInventory();
			return;
		}
		inv.clear();
		inv.setHelmet(new ItemStack(Material.DIAMOND_HELMET));
		inv.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
		inv.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
		inv.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
		// ตำแหน่งดาบตามที่ผู้เล่นจัดไว้ใน Kit Editor (ใช้ทั้งท้า และจับคู่)
		int sword = swordSlot(p);
		inv.setItem(sword, new ItemStack(Material.DIAMOND_SWORD));
		inv.setHeldItemSlot(sword < 9 ? sword : 0);
		p.updateInventory();
	}

	/** ใส่ชุด + เลือดเต็ม (เรียกซ้ำหลังวาป กันปลั๊กอินแยกอินเวนทอรี่ต่อโลกมาเซ็ตทับ) */
	private void prepare(Match m, Player p) {
		if (!p.isOnline() || m.ended || m.live) return;
		resetPlayer(p);
		giveKit(p, m);
	}

	private void setupPlayer(Player p, Match m, World arena) {
		int idx = m.idx(p);
		double[] s;
		float yaw;
		if (m.crystal) {
			s = idx == 0 ? CRYSTAL_SPAWN_A : CRYSTAL_SPAWN_B;
			yaw = idx == 0 ? CRYSTAL_YAW_A : CRYSTAL_YAW_B;
		} else {
			s = idx == 0 ? SPAWN_A : SPAWN_B;
			yaw = idx == 0 ? 0f : 180f;
		}
		p.closeInventory();
		p.teleport(new Location(arena, s[0], s[1], s[2] + m.dz, yaw, 0f));
		resetPlayer(p);
		giveKit(p, m);
	}

	private void startRound(Match m) {
		World arena = arenaWorld(m.crystal ? CRYSTAL_ARENA : ARENA);
		if (arena == null) return;
		m.round++;
		m.live = false;
		final int id = ++m.token;

		if (m.crystal) clearArena(m);   // คืนบล็อก/หลุม/คริสตัลทั้งหมดก่อนเริ่มตาใหม่

		for (Player p : List.of(m.a, m.b)) {
			if (!p.isOnline()) continue;
			setupPlayer(p, m, arena);
			for (int t = 5; t <= 95; t += 10) {
				later(t, () -> {
					if (m.token == id) prepare(m, p);
				});
			}
		}

		for (int n = 5; n >= 1; n--) {
			final int num = n;
			later((5 - n) * 20 + 1, () -> {
				if (m.ended || m.token != id) return;
				for (Player p : List.of(m.a, m.b)) {
					if (p.isOnline()) {
						title(p, "&e" + num, "&7Round " + m.round, 1100);
						p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, SoundCategory.MASTER, 1f, num <= 3 ? 1.2f : 0.9f);   // ติ๊ง
					}
				}
			});
		}
		later(101, () -> {
			if (m.ended || m.token != id) return;
			for (Player p : List.of(m.a, m.b)) {
				if (p.isOnline()) prepare(m, p);
			}
			m.live = true;
			for (Player p : List.of(m.a, m.b)) {
				if (p.isOnline()) {
					title(p, "&aFIGHT!", "", 1000);
					p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, SoundCategory.MASTER, 1f, 2f);   // ติ๊งสูง = เริ่ม
				}
			}
		});
	}

	private void winRound(Match m, Player winner) {
		if (!m.live || m.ended) return;
		m.live = false;
		m.token++;
		m.score[m.idx(winner)]++;
		if (m.crystal) clearDrops(m);   // จบตา: เคลียร์ของดรอปทันที

		for (Player p : List.of(m.a, m.b)) {
			if (p.isOnline()) {
				p.sendMessage(c("&eตาที่ " + m.round + " &f- &a" + winner.getName() + " &fชนะ &7("
					+ m.score[0] + " - " + m.score[1] + ")"));
			}
		}
		Player loser = m.other(winner);
		if (loser.isOnline()) {
			loser.setGameMode(GameMode.SPECTATOR);
			title(loser, "&cแพ้ตานี้", "", 1500);
		}
		if (winner.isOnline()) title(winner, "&aชนะตานี้", "", 1500);
		if (m.score[m.idx(winner)] >= m.target) {
			endMatch(m, winner);
			return;
		}
		final int id = m.token;
		later(50, () -> {
			if (!m.ended && m.token == id) startRound(m);
		});
	}

	private void endMatch(Match m, Player winner) {
		if (m.ended) return;
		m.ended = true;
		m.live = false;
		m.token++;
		Player loser = m.other(winner);
		matches.remove(m.a.getUniqueId());
		matches.remove(m.b.getUniqueId());
		if (m.crystal) clearArena(m);

		Bukkit.broadcast(c("&b[Duel] &6" + winner.getName() + " &fชนะดวลกับ &6" + loser.getName()
			+ " &7(" + m.score[m.idx(winner)] + " - " + m.score[m.idx(loser)] + ")"));
		if (winner.isOnline()) title(winner, "&6ชนะ!", "", 2000);

		later(60, () -> {
			toLobby(m.a);
			toLobby(m.b);
			if (m.crystal && m.slot >= 0) {   // ปล่อยสำเนาสนามหลังผู้เล่นออกไปแล้ว
				slotBusy[m.slot] = false;
				tryPairCrystal();   // ถ้ามีคู่รออยู่ ใช้สำเนานี้ต่อได้เลย
				if (!slotBusy[m.slot]) releaseCopy(m.slot);   // ไม่มีคู่ = ลบสำเนา
			}
		});
	}

	// ---------- Crystal PvP: บล็อก/คริสตัล/ระเบิด ในสำเนาสนามของแต่ละคู่ ----------
	// หลักการ: ปลั๊กอินก๊อปสนาม cy1 ไปวางเป็นสำเนาหลายช่อง (เลื่อนแกน Z ทีละ strideZ) แต่ละคู่ใช้สำเนาของตัวเอง
	// บล็อกที่วาง/พัง/หลุมระเบิด เป็นบล็อกจริงในสำเนา (เซิร์ฟกับไคลเอนต์เห็นตรงกัน ไม่ติดบั๊กลอย)
	// จบตา/จบแมตช์ ย้อนบล็อกที่เปลี่ยนกลับเป็นค่าเดิมจาก m.fake (สนามต้นฉบับไม่ถูกแตะเลย)

	private static long key(int x, int y, int z) {
		return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (long) (y & 0xFFF);
	}

	private Material typeAt(Match m, World w, int x, int y, int z) {
		return w.getType(x, y, z);
	}

	/** ช่องที่วางทับได้: อากาศ หรือบล็อกที่แทนที่ได้ (น้ำ หญ้า หิมะบางๆ ฯลฯ) */
	private boolean replaceableAt(Match m, World w, int x, int y, int z) {
		BlockData d = w.getBlockData(x, y, z);
		return d.getMaterial().isAir() || d.isReplaceable();
	}

	/** เปลี่ยนบล็อกจริงในสำเนาสนาม + จำค่าเดิมไว้คืนทีหลัง */
	private void setFake(Match m, World w, int x, int y, int z, BlockData data) {
		long k = key(x, y, z);
		Cell prev = m.fake.get(k);
		BlockData orig = prev != null ? prev.orig() : w.getBlockData(x, y, z);
		m.fake.put(k, new Cell(x, y, z, data, orig));
		w.getBlockAt(x, y, z).setBlockData(data, false);
	}

	/** คืนทุกอย่างเป็นเหมือนเดิม: ลบคริสตัล + ย้อนบล็อกในสำเนากลับ + ลบของที่ตกค้าง (ลูกธนู ฯลฯ) */
	private void clearArena(Match m) {
		for (EnderCrystal cr : new ArrayList<>(m.crystals)) {
			crystalOwner.remove(cr.getUniqueId());
			cr.remove();
		}
		m.crystals.clear();
		clearDrops(m);
		World w = Bukkit.getWorld(CRYSTAL_ARENA);
		if (w != null) {
			for (Cell cell : m.fake.values()) {
				w.getBlockAt(cell.x(), cell.y(), cell.z()).setBlockData(cell.orig(), false);
			}
			if (m.slot >= 0) {
				int[] r = region();
				BoundingBox box = new BoundingBox(r[0], r[1], r[2] + m.dz, r[3] + 1, r[4] + 1, r[5] + 1 + m.dz);
				for (org.bukkit.entity.Entity en : w.getNearbyEntities(box)) {
					if (!(en instanceof Player)) en.remove();
				}
			}
		}
		m.fake.clear();
	}

	// ---------- สำเนาสนาม ----------

	/** ขอบเขตสนามที่จะก๊อป {x1,y1,z1,x2,y2,z2}: ตั้งด้วย /cyregion pos1/pos2 ไม่ตั้ง = รอบจุดเกิด */
	private int[] region() {
		World w = Bukkit.getWorld(CRYSTAL_ARENA);
		int minY = w != null ? w.getMinHeight() : -64, maxY = w != null ? w.getMaxHeight() - 1 : 319;
		List<Integer> a = getConfig().getIntegerList("crystal.pos1");
		List<Integer> b = getConfig().getIntegerList("crystal.pos2");
		int x1, y1, z1, x2, y2, z2;
		if (a.size() == 3 && b.size() == 3) {
			x1 = Math.min(a.get(0), b.get(0)); x2 = Math.max(a.get(0), b.get(0));
			y1 = Math.min(a.get(1), b.get(1)); y2 = Math.max(a.get(1), b.get(1));
			z1 = Math.min(a.get(2), b.get(2)); z2 = Math.max(a.get(2), b.get(2));
		} else {
			x1 = (int) Math.floor(Math.min(CRYSTAL_SPAWN_A[0], CRYSTAL_SPAWN_B[0])) - REGION_PAD_XZ;
			x2 = (int) Math.floor(Math.max(CRYSTAL_SPAWN_A[0], CRYSTAL_SPAWN_B[0])) + REGION_PAD_XZ;
			z1 = (int) Math.floor(Math.min(CRYSTAL_SPAWN_A[2], CRYSTAL_SPAWN_B[2])) - REGION_PAD_XZ;
			z2 = (int) Math.floor(Math.max(CRYSTAL_SPAWN_A[2], CRYSTAL_SPAWN_B[2])) + REGION_PAD_XZ;
			y1 = (int) CRYSTAL_SPAWN_A[1] - REGION_Y_BELOW;
			y2 = (int) CRYSTAL_SPAWN_A[1] + REGION_Y_ABOVE;
		}
		return new int[]{x1, Math.max(minY, y1), z1, x2, Math.min(maxY, y2), z2};
	}

	private boolean slotUsable(int i) {
		return !slotBusy[i] && (slotState[i] == SL_READY || slotState[i] == SL_EMPTY);
	}

	private int allocSlot() {
		for (int i = 0; i < instances; i++) {   // ใช้สำเนาที่พร้อมอยู่แล้วก่อน
			if (!slotBusy[i] && slotState[i] == SL_READY) { slotBusy[i] = true; return i; }
		}
		for (int i = 0; i < instances; i++) {   // ไม่มี = เอาช่องว่างไปสร้างใหม่
			if (slotUsable(i)) { slotBusy[i] = true; return i; }
		}
		return -1;
	}

	private boolean crystalSlotFree() {
		for (int i = 0; i < instances; i++) if (slotUsable(i)) return true;
		return false;
	}

	/** จับคู่คนที่รอคิว Crystal อยู่ เมื่อมีสนามว่าง */
	private void tryPairCrystal() {
		if (!crystalSlotFree()) return;
		List<QEntry> list = new ArrayList<>(queue.values());
		for (int i = 0; i < list.size(); i++) {
			QEntry x = list.get(i);
			if (!x.crystal() || !isFree(x.player())) continue;
			for (int j = i + 1; j < list.size(); j++) {
				QEntry y = list.get(j);
				if (!y.crystal() || y.rounds() != x.rounds() || !isFree(y.player())) continue;
				queue.remove(x.player().getUniqueId());
				queue.remove(y.player().getUniqueId());
				startMatch(x.player(), y.player(), x.rounds(), true);
				tryPairCrystal();
				return;
			}
		}
	}

	/** สำเนาซ้อนทับสนามต้นฉบับไหม (stride-z น้อยเกินไป) */
	private boolean strideOk() {
		final int[] r = region();
		if (Math.abs(strideZ) < (r[5] - r[2] + 1) + 16) {
			getLogger().warning("crystal.stride-z (" + strideZ + ") น้อยเกินไปสำหรับสนามที่ลึก " + (r[5] - r[2] + 1)
				+ " บล็อก -- เพิ่มค่านี้ใน config.yml หรือลดขอบเขตด้วย /cyregion (ไม่สร้างสำเนา เพื่อไม่ให้ทับสนามต้นฉบับ)");
			return false;
		}
		return true;
	}

	/** สร้างสำเนาของช่องนี้ (ทีละนิดต่อ tick) แล้วเรียก done */
	private void requestBuild(int slot, Runnable done) {
		final int[] r = region();
		slotState[slot] = SL_BUILDING;
		slotDone[slot] = done;
		slotRemaining[slot] = 0;
		for (int cx = r[0] >> 4; cx <= r[3] >> 4; cx++) {
			for (int cz = r[2] >> 4; cz <= r[5] >> 4; cz++) {
				slotJobs.add(new int[]{slot, cx, cz, 1});
				slotRemaining[slot]++;
			}
		}
		startSlotWorker();
	}

	/** ลบสำเนาของช่องนี้ (ตั้งเป็นอากาศ) */
	private void requestClear(int slot) {
		final int[] r = region();
		slotState[slot] = SL_CLEARING;
		slotDone[slot] = null;
		slotRemaining[slot] = 0;
		for (int cx = r[0] >> 4; cx <= r[3] >> 4; cx++) {
			for (int cz = r[2] >> 4; cz <= r[5] >> 4; cz++) {
				slotJobs.add(new int[]{slot, cx, cz, 0});
				slotRemaining[slot]++;
			}
		}
		startSlotWorker();
	}

	/** ปล่อยช่องหลังแมตช์จบ: ลบสำเนา (ถ้ายังสร้างไม่เสร็จ รอให้เสร็จก่อนแล้วค่อยลบ) */
	private void releaseCopy(int slot) {
		if (slotState[slot] == SL_BUILDING) slotPendingClear[slot] = true;
		else if (slotState[slot] == SL_READY) requestClear(slot);
	}

	/** ล้างสำเนาทุกช่องที่ไม่มีคนใช้ (ตอนเปิดเซิร์ฟ / /cyregion rebuild) */
	private void clearIdleCopies() {
		if (arenaWorld(CRYSTAL_ARENA) == null) return;
		for (int i = 0; i < instances; i++) {
			if (!slotBusy[i] && (slotState[i] == SL_READY || slotState[i] == SL_EMPTY)) requestClear(i);
		}
	}

	private void startSlotWorker() {
		if (slotTask != null) return;
		final World w = Bukkit.getWorld(CRYSTAL_ARENA);
		slotTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
			final int[] r = region();
			for (int n = 0; n < COPY_COLUMNS_PER_TICK && !slotJobs.isEmpty(); n++) {
				int[] j = slotJobs.poll();
				if (w != null) {
					if (j[3] == 1) copyColumn(w, r, j[0], j[1], j[2]);
					else clearColumn(w, r, j[0], j[1], j[2]);
				}
				if (--slotRemaining[j[0]] == 0) finishSlot(j[0], j[3] == 1);
			}
			if (slotJobs.isEmpty()) {
				slotTask.cancel();
				slotTask = null;
			}
		}, 1L, 1L);
	}

	private void finishSlot(int slot, boolean built) {
		if (built) {
			slotState[slot] = SL_READY;
			Runnable done = slotDone[slot];
			slotDone[slot] = null;
			if (slotPendingClear[slot]) {   // แมตช์จบไปก่อนสร้างเสร็จ
				slotPendingClear[slot] = false;
				requestClear(slot);
			} else if (done != null) {
				done.run();
			}
		} else {
			slotState[slot] = SL_EMPTY;
			tryPairCrystal();
		}
	}

	private void clearColumn(World w, int[] r, int slot, int cx, int cz) {
		int dz = (slot + 1) * strideZ;
		int x0 = Math.max(r[0], cx << 4), x1 = Math.min(r[3], (cx << 4) + 15);
		int z0 = Math.max(r[2], cz << 4), z1 = Math.min(r[5], (cz << 4) + 15);
		for (int x = x0; x <= x1; x++) {
			for (int z = z0; z <= z1; z++) {
				if (!w.isChunkGenerated(x >> 4, (z + dz) >> 4)) continue;   // ชังค์ที่ไม่เคยสร้าง = ไม่มีอะไรให้ลบ (กันเจนโลกเปล่าๆ)
				for (int y = r[1]; y <= r[4]; y++) {
					Block dst = w.getBlockAt(x, y, z + dz);
					if (!dst.getType().isAir()) dst.setType(Material.AIR, false);
				}
			}
		}
	}

	private void copyColumn(World w, int[] r, int slot, int cx, int cz) {
		int dz = (slot + 1) * strideZ;
		int x0 = Math.max(r[0], cx << 4), x1 = Math.min(r[3], (cx << 4) + 15);
		int z0 = Math.max(r[2], cz << 4), z1 = Math.min(r[5], (cz << 4) + 15);
		for (int x = x0; x <= x1; x++) {
			for (int z = z0; z <= z1; z++) {
				for (int y = r[1]; y <= r[4]; y++) {
					BlockData src = w.getBlockData(x, y, z);
					Block dst = w.getBlockAt(x, y, z + dz);
					if (!dst.getBlockData().equals(src)) dst.setBlockData(src, false);
				}
			}
		}
	}

	/** /cyregion pos1|pos2|show|rebuild */
	private void regionCommand(CommandSender s, String[] args) {
		String sub = args.length > 0 ? args[0].toLowerCase() : "show";
		switch (sub) {
			case "pos1", "pos2" -> {
				if (!(s instanceof Player p)) { s.sendMessage("ใช้ในเกมเท่านั้น"); return; }
				if (!p.getWorld().getName().equals(CRYSTAL_ARENA)) { p.sendMessage(c("&cต้องยืนในโลก " + CRYSTAL_ARENA)); return; }
				Location l = p.getLocation();
				getConfig().set("crystal." + sub, List.of(l.getBlockX(), l.getBlockY(), l.getBlockZ()));
				saveConfig();
				p.sendMessage(c("&aตั้ง " + sub + " = " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ()
					+ " &7(ตั้งครบ 2 จุดแล้วพิมพ์ /cyregion rebuild)"));
			}
			case "rebuild" -> {
				clearIdleCopies();
				s.sendMessage(c("&aล้างสำเนาที่ไม่มีคนใช้แล้ว (สำเนาจะถูกสร้างใหม่เองตอนมีคู่)"));
			}
			default -> {
				int[] r = region();
				s.sendMessage(c("&eขอบเขต: &f" + r[0] + "," + r[1] + "," + r[2] + " &7ถึง &f" + r[3] + "," + r[4] + "," + r[5]));
				s.sendMessage(c("&eสำเนา: &f" + instances + " ชุด &7เลื่อนแกน Z ทีละ &f" + strideZ));
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < instances; i++) sb.append(slotState[i] == SL_READY ? (slotBusy[i] ? "&c●" : "&a●") : (slotState[i] == SL_EMPTY ? "&7○" : "&e◐"));
				s.sendMessage(c("&eสถานะ: " + sb + " &7(เขียว=ว่าง แดง=กำลังเล่น เทา=ยังไม่พร้อม)"));
			}
		}
	}

	/** ของที่ใช้ได้แบบเกมปกติตอนสู้ในสนามคริสตัล (ไม่ผ่านระบบวางบล็อก/คริสตัลของเรา) */
	private static final Set<Material> USABLE_IN_CRYSTAL = EnumSet.of(
		Material.ENDER_PEARL, Material.WIND_CHARGE, Material.FISHING_ROD, Material.BOW, Material.CROSSBOW,
		Material.TRIDENT, Material.SNOWBALL, Material.EGG, Material.SPLASH_POTION, Material.LINGERING_POTION,
		Material.EXPERIENCE_BOTTLE, Material.FIREWORK_ROCKET, Material.SHIELD, Material.TOTEM_OF_UNDYING);

	private static boolean isArmorItem(Material t) {
		String n = t.name();
		return n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE") || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS");
	}

	/** เคลียร์ของที่ผู้เล่นทิ้งไว้ในสำเนาสนาม */
	private void clearDrops(Match m) {
		for (org.bukkit.entity.Item it : new ArrayList<>(m.drops)) it.remove();
		m.drops.clear();
		World w = Bukkit.getWorld(CRYSTAL_ARENA);
		if (w != null && m.slot >= 0) {
			int[] r = region();
			BoundingBox box = new BoundingBox(r[0], r[1], r[2] + m.dz, r[3] + 1, r[4] + 1, r[5] + 1 + m.dz);
			for (org.bukkit.entity.Entity en : w.getNearbyEntities(box)) {
				if (en instanceof org.bukkit.entity.Item) en.remove();
			}
		}
	}

	@EventHandler(priority = EventPriority.HIGH)
	public void onArenaInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		Match m = matches.get(p.getUniqueId());
		if (m == null || !m.crystal) return;
		Material t = p.getInventory().getItemInMainHand().getType();
		if (e.getAction() == Action.LEFT_CLICK_BLOCK || e.getAction() == Action.LEFT_CLICK_AIR) return;   // ขุด/ตี ผ่านไปที่ onBreak
		// Respawn Anchor ต้องทำก่อน: ถืออะไรอยู่ก็ชาร์จ/ระเบิดได้ (บล็อกนี้เป็นของปลอม เซิร์ฟมองเป็นอากาศ เลยไม่ปล่อยให้ไปเป็นกินของ/ใช้ของ)
		if (e.getAction() == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null && m.live && !m.ended) {
			Block ab = e.getClickedBlock();
			if (typeAt(m, p.getWorld(), ab.getX(), ab.getY(), ab.getZ()) == Material.RESPAWN_ANCHOR) {
				e.setCancelled(true);
				if (e.getHand() == EquipmentSlot.HAND) {
					Material held = p.getInventory().getItemInMainHand().getType();
					useAnchor(m, p, p.getWorld(), ab.getX(), ab.getY(), ab.getZ(), held);
				}
				return;
			}
		}
		if (!m.ended && (t == Material.ELYTRA || isArmorItem(t))) return;   // คลิกขวาสลับเกราะ/ปีกได้ตามปกติ
		if (t.isEdible()) return;   // กินแอปเปิลทองได้ตามปกติ
		if (m.live && !m.ended && USABLE_IN_CRYSTAL.contains(t)) return;   // ปาเพิร์ล/วินด์ชาร์จ/ธนู ฯลฯ ตามปกติ
		e.setCancelled(true);
		if (!m.live || m.ended) return;
		if (e.getHand() != EquipmentSlot.HAND || e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
		Block clicked = e.getClickedBlock();
		if (clicked == null) return;
		World w = p.getWorld();
		final int cx = clicked.getX(), cy = clicked.getY(), cz = clicked.getZ();
		final BlockFace face = e.getBlockFace();
		if (typeAt(m, w, cx, cy, cz) == Material.RESPAWN_ANCHOR
			&& useAnchor(m, p, w, cx, cy, cz, t)) return;
		if (t == Material.END_CRYSTAL) {
			placeCrystal(m, p, w, cx, cy, cz);
		} else if (isPlaceable(t)) {
			placeBlock(m, p, w, clicked, face, t);
		}
	}

	/** บล็อกที่วางได้ในสนามคริสตัล (รวมใยแมงมุม/บันได ที่ isSolid() เป็น false) */
	private static boolean isPlaceable(Material t) {
		if (!t.isBlock() || !t.isItem() || t.isAir()) return false;
		return switch (t) {
			case WATER, LAVA, FIRE, SOUL_FIRE, LIGHT, STRUCTURE_VOID, BARRIER -> false;
			default -> true;
		};
	}

	/** Respawn Anchor: ใส่ glowstone ชาร์จ / คลิกตอนมีชาร์จ = ระเบิด (เหมือนในโอเวอร์เวิลด์) */
	private boolean useAnchor(Match m, Player p, World w, int x, int y, int z, Material held) {
		BlockData data = w.getBlockData(x, y, z);
		if (!(data instanceof RespawnAnchor ra)) return false;
		int ch = ra.getCharges();
		Location loc = new Location(w, x + 0.5, y + 0.5, z + 0.5);
		if (held == Material.GLOWSTONE && ch < ra.getMaximumCharges()) {
			ra.setCharges(ch + 1);
			setFake(m, w, x, y, z, ra);
			consumeOne(p);
			p.swingMainHand();
			for (Player q : List.of(m.a, m.b)) {
				if (q.isOnline()) q.playSound(loc, Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, SoundCategory.BLOCKS, 1f, 1f);
			}
			return true;
		}
		if (ch > 0) {
			setFake(m, w, x, y, z, Material.AIR.createBlockData());
			explode(m, w, loc.getX(), loc.getY(), loc.getZ(), 5.0f, p);
			return true;
		}
		return false;
	}

	private void consumeOne(Player p) {
		PlayerInventory inv = p.getInventory();
		ItemStack hand = inv.getItemInMainHand();
		if (hand.getAmount() <= 1) {
			inv.setItemInMainHand(null);
		} else {
			hand.setAmount(hand.getAmount() - 1);
			inv.setItemInMainHand(hand);
		}
	}

	private void placeBlock(Match m, Player p, World w, Block clicked, BlockFace face, Material t) {
		int cx = clicked.getX(), cy = clicked.getY(), cz = clicked.getZ();
		if (typeAt(m, w, cx, cy, cz).isAir()) return;
		int x = cx + face.getModX(), y = cy + face.getModY(), z = cz + face.getModZ();
		if (y < w.getMinHeight() || y >= w.getMaxHeight()) return;
		if (!replaceableAt(m, w, x, y, z)) return;
		if (m.fake.size() >= MAX_FAKE_BLOCKS) { p.sendMessage(c("&cวางบล็อกเต็มแล้ว")); return; }
		BoundingBox box = new BoundingBox(x, y, z, x + 1, y + 1, z + 1);
		for (Player q : List.of(m.a, m.b)) {
			if (q.isOnline() && q.getGameMode() == GameMode.SURVIVAL && q.getBoundingBox().overlaps(box)) return;
		}
		for (EnderCrystal cr : m.crystals) if (cr.getBoundingBox().overlaps(box)) return;

		BlockData data = t.createBlockData();
		if (data instanceof org.bukkit.block.data.Directional dir && t == Material.LADDER) {
			if (face == BlockFace.UP || face == BlockFace.DOWN) return;   // บันไดต้องติดข้างบล็อก
			dir.setFacing(face);
		}
		setFake(m, w, x, y, z, data);
		consumeOne(p);
		p.swingMainHand();
		Location loc = new Location(w, x + 0.5, y + 0.5, z + 0.5);
		for (Player q : List.of(m.a, m.b)) {
			if (q.isOnline()) q.playSound(loc, data.getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 1f, 0.8f);
		}
	}

	private void placeCrystal(Match m, Player p, World w, int x, int y, int z) {
		Material base = typeAt(m, w, x, y, z);
		if (base != Material.OBSIDIAN && base != Material.BEDROCK) return;
		if (!typeAt(m, w, x, y + 1, z).isAir()) return;
		BoundingBox box = new BoundingBox(x, y + 1, z, x + 1, y + 3, z + 1);
		for (Player q : List.of(m.a, m.b)) {
			if (q.isOnline() && q.getGameMode() == GameMode.SURVIVAL && q.getBoundingBox().overlaps(box)) return;
		}
		for (EnderCrystal cr : m.crystals) if (cr.getBoundingBox().overlaps(box)) return;

		Location loc = new Location(w, x + 0.5, y + 1, z + 0.5);
		EnderCrystal cr = w.spawn(loc, EnderCrystal.class, ent -> {
			ent.setShowingBottom(false);
			ent.setVisibleByDefault(false);   // ไม่มีใครเห็น จนกว่าจะ showEntity
			ent.setPersistent(false);
		});
		for (Player q : List.of(m.a, m.b)) {
			if (q.isOnline()) q.showEntity(this, cr);
		}
		m.crystals.add(cr);
		crystalOwner.put(cr.getUniqueId(), m);
		consumeOne(p);
		p.swingMainHand();
	}

	/** ตีคริสตัล = ระเบิดแบบที่เราคำนวณเอง (ไม่ให้เกมระเบิดจริง) */
	@EventHandler(priority = EventPriority.HIGH)
	public void onCrystalHit(EntityDamageEvent e) {
		if (!(e.getEntity() instanceof EnderCrystal cr)) return;
		Match m = crystalOwner.get(cr.getUniqueId());
		if (m == null) {
			if (cr.getWorld().getName().equals(CRYSTAL_ARENA)) e.setCancelled(true);
			return;
		}
		e.setCancelled(true);
		if (!m.live || m.ended) return;
		if (e instanceof EntityDamageByEntityEvent be && be.getDamager() instanceof Player d && (d == m.a || d == m.b)) {
			detonate(m, cr, d);
		}
	}

	private void detonate(Match m, EnderCrystal cr, Player cause) {
		if (!m.crystals.remove(cr)) return;
		crystalOwner.remove(cr.getUniqueId());
		Location loc = cr.getLocation();
		cr.remove();
		explode(m, loc.getWorld(), loc.getX(), loc.getY(), loc.getZ(), 6.0f, cause);
	}

	/** Blast Protection ลดแรงกระเด็นเหมือนในเกม: ตัวคูณ = 1 - 0.15 x เลเวลสูงสุดบนเกราะ */
	private static double blastKbFactor(Player v) {
		int lvl = 0;
		for (ItemStack a : v.getInventory().getArmorContents()) {
			if (a != null && !a.getType().isAir()) lvl = Math.max(lvl, a.getEnchantmentLevel(Enchantment.BLAST_PROTECTION));
		}
		return Math.max(0.0, 1.0 - 0.15 * lvl);
	}

	private void explode(Match m, World w, double cx, double cy, double cz, float power, Player cause) {
		Vector center = new Vector(cx, cy, cz);
		Location cLoc = new Location(w, cx, cy, cz);
		Random rnd = new Random();

		// 1) หาบล็อกที่จะพัง (สูตรเดียวกับเกม: ยิงรังสี 16x16x16 หักตามความทนระเบิด)
		Map<Long, int[]> hit = new HashMap<>();
		for (int i = 0; i < 16; i++) {
			for (int j = 0; j < 16; j++) {
				for (int k = 0; k < 16; k++) {
					if (i != 0 && i != 15 && j != 0 && j != 15 && k != 0 && k != 15) continue;
					double dx = i / 15.0 * 2.0 - 1.0, dy = j / 15.0 * 2.0 - 1.0, dz = k / 15.0 * 2.0 - 1.0;
					double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
					dx /= len; dy /= len; dz /= len;
					float intensity = power * (0.7f + rnd.nextFloat() * 0.6f);
					double px = cx, py = cy, pz = cz;
					for (; intensity > 0.0f; intensity -= 0.22500001f) {
						int bx = (int) Math.floor(px), by = (int) Math.floor(py), bz = (int) Math.floor(pz);
						if (by < w.getMinHeight() || by >= w.getMaxHeight()) break;
						Material mt = typeAt(m, w, bx, by, bz);
						if (!mt.isAir()) {
							intensity -= (mt.getBlastResistance() + 0.3f) * 0.3f;
							long kk = key(bx, by, bz);
							if (intensity > 0.0f && mt != Material.WATER && mt != Material.LAVA
								&& mt.getHardness() >= 0f && (CRATERS || m.fake.containsKey(kk))) {
								hit.putIfAbsent(kk, new int[]{bx, by, bz});
							}
						}
						px += dx * 0.3; py += dy * 0.3; pz += dz * 0.3;
					}
				}
			}
		}

		// 2) ดาเมจ + แรงกระเดน เฉพาะ 2 คนในแมตช์ (คนอื่นที่ยืนจุดเดียวกันไม่โดน)
		double q = power * 2.0;
		var bd = DamageSource.builder(DamageType.PLAYER_EXPLOSION);
		if (cause != null) bd.withCausingEntity(cause).withDirectEntity(cause);
		DamageSource src = bd.build();
		Player[] order = cause == null ? new Player[]{m.a, m.b} : new Player[]{m.other(cause), cause};
		for (Player v : order) {
			if (!v.isOnline() || v.getGameMode() != GameMode.SURVIVAL || v.getWorld() != w) continue;
			double d = v.getLocation().toVector().distance(center) / q;
			if (d > 1.0) continue;
			double dx = v.getLocation().getX() - cx;
			double dy = v.getEyeLocation().getY() - cy;
			double dz = v.getLocation().getZ() - cz;
			double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
			if (len == 0) continue;
			double seen = seenPercent(m, w, center, v.getBoundingBox());
			if (seen <= 0) continue;
			double impact = (1.0 - d) * seen;
			double dmg = (int) ((impact * impact + impact) / 2.0 * 7.0 * q + 1.0);
			double kbMul = impact * KB_SCALE * blastKbFactor(v);
			Vector kb = new Vector(dx / len * kbMul, dy / len * kbMul, dz / len * kbMul);
			internalDamage = true;
			try {
				v.damage(dmg, src);
			} finally {
				internalDamage = false;
			}
			Vector nv = v.getVelocity().add(kb);
			double hx = nv.getX(), hz = nv.getZ(), hl = Math.sqrt(hx * hx + hz * hz);
			if (hl > KB_MAX_HORIZONTAL) { nv.setX(hx / hl * KB_MAX_HORIZONTAL); nv.setZ(hz / hl * KB_MAX_HORIZONTAL); }
			if (nv.getY() > KB_MAX_VERTICAL) nv.setY(KB_MAX_VERTICAL);
			v.setVelocity(nv);
		}

		// 3) เอฟเฟกต์ ส่งให้ 2 คนนี้เท่านั้น
		for (Player p : List.of(m.a, m.b)) {
			if (!p.isOnline() || p.getWorld() != w) continue;
			p.spawnParticle(Particle.EXPLOSION_EMITTER, cLoc, 1);
			p.playSound(cLoc, Sound.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 4.0f, 0.9f + rnd.nextFloat() * 0.2f);
		}

		// 4) คริสตัลอันอื่นในรัศมี ระเบิดต่อเป็นลูกโซ่
		for (EnderCrystal other : new ArrayList<>(m.crystals)) {
			double d = other.getLocation().toVector().distance(center) / q;
			if (d <= 1.0 && seenPercent(m, w, center, other.getBoundingBox()) > 0) {
				later(1, () -> {
					if (m.live && !m.ended) detonate(m, other, cause);
				});
			}
		}

		// 5) พังบล็อกจริงในสำเนาสนาม (จบตาแล้วย้อนกลับให้)
		BlockData air = Material.AIR.createBlockData();
		for (int[] b : hit.values()) {
			setFake(m, w, b[0], b[1], b[2], air);
		}
	}

	/** สัดส่วนที่เป้าหมาย "โดนระเบิดโดยตรง" (ไม่มีบล็อกบัง) เหมือนสูตรในเกม */
	private double seenPercent(Match m, World w, Vector c, BoundingBox box) {
		double wx = box.getWidthX(), wy = box.getHeight(), wz = box.getWidthZ();
		double sx = 1.0 / (wx * 2.0 + 1.0), sy = 1.0 / (wy * 2.0 + 1.0), sz = 1.0 / (wz * 2.0 + 1.0);
		double ox = (1.0 - Math.floor(1.0 / sx) * sx) / 2.0;
		double oz = (1.0 - Math.floor(1.0 / sz) * sz) / 2.0;
		int seen = 0, total = 0;
		for (double fx = 0; fx <= 1.0; fx += sx) {
			for (double fy = 0; fy <= 1.0; fy += sy) {
				for (double fz = 0; fz <= 1.0; fz += sz) {
					double px = box.getMinX() + fx * wx + ox;
					double py = box.getMinY() + fy * wy + 0.001;
					double pz = box.getMinZ() + fz * wz + oz;
					if (!blocked(m, w, px, py, pz, c)) seen++;
					total++;
				}
			}
		}
		return total == 0 ? 0 : (double) seen / total;
	}

	private boolean blocked(Match m, World w, double x, double y, double z, Vector c) {
		double dx = c.getX() - x, dy = c.getY() - y, dz = c.getZ() - z;
		double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
		int steps = (int) Math.ceil(len / 0.25);
		for (int i = 1; i < steps; i++) {
			double t = (double) i / steps;
			int bx = (int) Math.floor(x + dx * t), by = (int) Math.floor(y + dy * t), bz = (int) Math.floor(z + dz * t);
			if (by < w.getMinHeight() || by >= w.getMaxHeight()) continue;
			if (typeAt(m, w, bx, by, bz).isSolid()) return true;
		}
		return false;
	}

	// ---------- world / lobby ----------

	@EventHandler
	public void onWorldChange(PlayerChangedWorldEvent e) {
		Player p = e.getPlayer();
		for (int t : new int[]{2, 5, 10, 20, 40, 80}) later(t, () -> refreshWorld(p));
	}

	private void refreshWorld(Player p) {
		if (!p.isOnline()) return;
		Match m = matches.get(p.getUniqueId());
		if (m != null) {
			prepare(m, p);
		} else if (inLobby(p)) {
			resetPlayer(p);
			giveLobbyItems(p);
		}
	}

	private void toLobby(Player p) {
		if (!p.isOnline() || matches.containsKey(p.getUniqueId())) return;
		for (Player q : Bukkit.getOnlinePlayers()) {
			if (q != p) {
				p.showPlayer(this, q);
				q.showPlayer(this, p);
			}
		}
		World lobby = Bukkit.getWorld(LOBBY);
		if (lobby != null) p.teleport(lobby.getSpawnLocation());
		resetPlayer(p);
		giveLobbyItems(p);
	}
}
