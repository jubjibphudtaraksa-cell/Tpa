package swordduels;

import java.time.Duration;
import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.util.Vector;

public final class Main extends JavaPlugin implements Listener {

	// ====== ตั้งค่า ======
	static final String LOBBY = "lp";        // โลกล็อบบี้
	static final String ARENA = "sworld1";   // โลกสนามดวล
	static final double[] SPAWN_A = {137.5, 61, 44.5};  // 137 61 44 (หันไป +z)
	static final double[] SPAWN_B = {137.5, 61, 98.5};  // 137 61 98 (หันไป -z)
	static final int QUEUE_WINS = 3;         // จับคู่สุ่ม: ชนะ 3 ตาก่อน
	static final int MAX_ROUNDS = 20;
	static final int INVITE_SECONDS = 60;
	static final int KIT_SLOT = 10;          // ช่องของดาบในเมนูกล่อง
	// =====================

	public interface DuelCallback { void accept(Player p, String opponentName, int rounds); }

	record Invite(UUID from, int rounds, long time) {}

	static final class Match {
		final Player a, b;
		final int target;
		final int[] score = new int[2];
		int round, token;
		boolean live, ended;
		Match(Player a, Player b, int target) { this.a = a; this.b = b; this.target = target; }
		Player other(Player p) { return p == a ? b : a; }
		int idx(Player p) { return p == a ? 0 : 1; }
	}

	static final class KitMenu implements InventoryHolder {
		final String mode; final UUID target; Inventory inv;
		KitMenu(String mode, UUID target) { this.mode = mode; this.target = target; }
		@Override public Inventory getInventory() { return inv; }
	}

	static final class RoundsMenu implements InventoryHolder {
		final UUID target; Inventory inv;
		RoundsMenu(UUID target) { this.target = target; }
		@Override public Inventory getInventory() { return inv; }
	}

	private NamespacedKey itemKey;
	private boolean floodgate;
	private final Map<UUID, Player> queue = new LinkedHashMap<>();
	private final Map<UUID, Invite> invites = new HashMap<>();
	private final Map<UUID, Match> matches = new HashMap<>();
	private final Map<UUID, Long> lastUse = new HashMap<>();

	@Override
	public void onEnable() {
		itemKey = new NamespacedKey(this, "duel_item");
		floodgate = Bukkit.getPluginManager().getPlugin("floodgate") != null;
		Bukkit.getPluginManager().registerEvents(this, this);
		getLogger().info("Floodgate: " + (floodgate ? "พบ (ผู้เล่น Bedrock ใช้ฟอร์ม)" : "ไม่พบ"));
	}

	// ---------- helpers ----------

	private Component c(String s) {
		return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
	}

	private Component itemName(String s) {
		return c(s).decoration(TextDecoration.ITALIC, false);
	}

	private void later(int ticks, Runnable r) {
		Bukkit.getScheduler().runTaskLater(this, r, Math.max(1, ticks));
	}

	private boolean throttle(Player p, long ms) {
		long now = System.currentTimeMillis();
		Long last = lastUse.get(p.getUniqueId());
		if (last != null && now - last < ms) return true;
		lastUse.put(p.getUniqueId(), now);
		return false;
	}

	private boolean inLobby(Player p) { return p.getWorld().getName().equals(LOBBY); }

	private boolean protectedWorld(Player p) {
		String w = p.getWorld().getName();
		return w.equals(LOBBY) || w.equals(ARENA);
	}

	private boolean isFree(Player p) {
		return p != null && p.isOnline() && inLobby(p) && !matches.containsKey(p.getUniqueId());
	}

	private World arenaWorld() {
		World w = Bukkit.getWorld(ARENA);
		if (w == null) w = Bukkit.createWorld(new WorldCreator(ARENA)); // โหลดโลกที่มีอยู่แล้ว
		return w;
	}

	private void title(Player p, String t, String sub, int stayMs) {
		p.showTitle(Title.title(c(t), c(sub),
			Title.Times.times(Duration.ZERO, Duration.ofMillis(stayMs), Duration.ZERO)));
	}

	private ItemStack tagged(Material m, String name, String tag) {
		ItemStack it = new ItemStack(m);
		ItemMeta meta = it.getItemMeta();
		meta.displayName(itemName(name));
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, tag);
		it.setItemMeta(meta);
		return it;
	}

	private void giveLobbyItems(Player p) {
		p.getInventory().clear();
		p.getInventory().setArmorContents(new ItemStack[4]);
		p.getInventory().setItem(0, tagged(Material.DIAMOND_SWORD, "&bหาคู่สู้ &7(Queue)", "queue"));
		p.getInventory().setItem(1, tagged(Material.IRON_SWORD, "&7ท้าดวล &7(Duel)", "duel"));
		p.getInventory().setHeldItemSlot(0);
	}

	private void resetPlayer(Player p) {
		p.setGameMode(GameMode.SURVIVAL);
		for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
		p.setHealth(20.0);
		p.setFoodLevel(20);
		p.setSaturation(20f);
		p.setFireTicks(0);
		p.setFallDistance(0f);
		p.setVelocity(new Vector(0, 0, 0));
	}

	// ---------- events: lobby ----------

	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		Player p = e.getPlayer();
		String w = p.getWorld().getName();
		if (w.equals(ARENA)) {
			later(2, () -> toLobby(p));
		} else if (w.equals(LOBBY)) {
			giveLobbyItems(p);
		}
	}

	@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		Player p = e.getPlayer();
		UUID id = p.getUniqueId();
		queue.remove(id);
		invites.remove(id);
		lastUse.remove(id);
		Match m = matches.get(id);
		if (m != null && !m.ended) endMatch(m, m.other(p));
	}

	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		if (!inLobby(p)) return;
		e.setCancelled(true);
		if (e.getHand() != EquipmentSlot.HAND) return;
		if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
		ItemStack it = e.getItem();
		if (it == null || !it.hasItemMeta()) return;
		String tag = it.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
		if (tag == null || throttle(p, 600)) return;

		if (tag.equals("queue")) {
			if (queue.remove(p.getUniqueId()) != null) {
				p.sendMessage(c("&cออกจากคิวแล้ว"));
				return;
			}
			openKitMenu(p, "queue", null);
		} else if (tag.equals("duel")) {
			openKitMenu(p, "duel", null);
		}
	}

	@EventHandler(priority = EventPriority.HIGH)
	public void onDamage(EntityDamageEvent e) {
		if (!(e.getEntity() instanceof Player v)) return;
		Match m = matches.get(v.getUniqueId());

		if (m != null) {
			if (!m.live) { e.setCancelled(true); return; }
			if (e instanceof EntityDamageByEntityEvent be && be.getDamager() != m.other(v)) {
				e.setCancelled(true);
				return;
			}
			if (e.getCause() == EntityDamageEvent.DamageCause.VOID || v.getHealth() - e.getFinalDamage() <= 0) {
				e.setCancelled(true);
				winRound(m, m.other(v));
			}
			return;
		}

		if (protectedWorld(v)) {
			e.setCancelled(true);
			// ตีตัวคนในล็อบบี้ = ท้าดวล
			if (e instanceof EntityDamageByEntityEvent be
				&& be.getDamager() instanceof Player d
				&& d != v && inLobby(v) && inLobby(d) && !throttle(d, 1000)) {
				openKitMenu(d, "duel", v.getUniqueId());
			}
		}
	}

	@EventHandler
	public void onMove(PlayerMoveEvent e) {
		Match m = matches.get(e.getPlayer().getUniqueId());
		if (m == null || m.live || m.ended) return;
		Location f = e.getFrom(), t = e.getTo();
		if (t == null) return;
		if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
			Location n = f.clone();
			n.setYaw(t.getYaw());
			n.setPitch(t.getPitch());
			e.setTo(n);
		}
	}

	@EventHandler public void onBreak(BlockBreakEvent e) { if (protectedWorld(e.getPlayer())) e.setCancelled(true); }
	@EventHandler public void onPlace(BlockPlaceEvent e) { if (protectedWorld(e.getPlayer())) e.setCancelled(true); }
	@EventHandler public void onDrop(PlayerDropItemEvent e) { if (protectedWorld(e.getPlayer())) e.setCancelled(true); }
	@EventHandler public void onSwap(PlayerSwapHandItemsEvent e) { if (protectedWorld(e.getPlayer())) e.setCancelled(true); }

	@EventHandler
	public void onFood(FoodLevelChangeEvent e) {
		if (e.getEntity() instanceof Player p && protectedWorld(p)) e.setCancelled(true);
	}

	@EventHandler
	public void onDrag(InventoryDragEvent e) {
		if (!(e.getWhoClicked() instanceof Player p)) return;
		InventoryHolder h = e.getView().getTopInventory().getHolder();
		if (h instanceof KitMenu || h instanceof RoundsMenu || (protectedWorld(p) && p.getGameMode() != GameMode.CREATIVE)) {
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void onClick(InventoryClickEvent e) {
		if (!(e.getWhoClicked() instanceof Player p)) return;
		Inventory top = e.getView().getTopInventory();
		InventoryHolder h = top.getHolder();
		boolean inTop = e.getClickedInventory() == top;

		if (h instanceof KitMenu km) {
			e.setCancelled(true);
			if (inTop && e.getSlot() == KIT_SLOT) {
				p.closeInventory();
				later(5, () -> {
					if (!isFree(p)) return;
					if (km.mode.equals("queue")) {
						joinQueue(p);
					} else {
						openDuelUi(p, km.target == null ? null : Bukkit.getPlayer(km.target));
					}
				});
			}
			return;
		}
		if (h instanceof RoundsMenu rm) {
			e.setCancelled(true);
			if (inTop && e.getSlot() >= 0 && e.getSlot() < MAX_ROUNDS) {
				int rounds = e.getSlot() + 1;
				p.closeInventory();
				Player t = Bukkit.getPlayer(rm.target);
				later(2, () -> {
					if (t == null) { p.sendMessage(c("&cหาผู้เล่นไม่เจอ")); return; }
					sendInvite(p, t, rounds);
				});
			}
			return;
		}
		if (protectedWorld(p) && p.getGameMode() != GameMode.CREATIVE) e.setCancelled(true);
	}

	// ---------- menu + form ----------

	private void openKitMenu(Player p, String mode, UUID target) {
		KitMenu h = new KitMenu(mode, target);
		Inventory inv = Bukkit.createInventory(h, 54, c("Select a Kit"));
		h.inv = inv;
		ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
		ItemMeta meta = sword.getItemMeta();
		meta.displayName(itemName("&bSword"));
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		sword.setItemMeta(meta);
		inv.setItem(KIT_SLOT, sword);
		p.openInventory(inv);
	}

	private void openDuelUi(Player p, Player target) {
		boolean bedrock = floodgate && FloodForms.isBedrock(p);

		if (bedrock) {
			List<String> names = new ArrayList<>();
			if (target == null) {
				for (Player q : Bukkit.getOnlinePlayers()) {
					if (q != p && isFree(q)) names.add(q.getName());
				}
				if (names.isEmpty()) {
					p.sendMessage(c("&cไม่มีผู้เล่นให้ท้าตอนนี้"));
					return;
				}
			}
			FloodForms.sendDuel(this, p, target, names, (pl, opp, rounds) -> {
				Player t = target != null ? target : (opp == null ? null : Bukkit.getPlayerExact(opp));
				if (t == null) { pl.sendMessage(c("&cหาผู้เล่นไม่เจอ")); return; }
				sendInvite(pl, t, rounds);
			});
			return;
		}

		// ผู้เล่น Java: เลือก rounds ผ่านเมนูกล่อง (ต้องตีตัวผู้เล่นเพื่อท้า)
		if (target == null) {
			p.sendMessage(c("&eใช้ดาบตีตัวผู้เล่นที่ต้องการท้าได้เลย"));
			return;
		}
		RoundsMenu h = new RoundsMenu(target.getUniqueId());
		Inventory inv = Bukkit.createInventory(h, 27, c("Rounds vs " + target.getName()));
		h.inv = inv;
		for (int i = 1; i <= MAX_ROUNDS; i++) {
			ItemStack it = new ItemStack(Material.PAPER, i);
			ItemMeta meta = it.getItemMeta();
			meta.displayName(itemName("&e" + i + " rounds"));
			it.setItemMeta(meta);
			inv.setItem(i - 1, it);
		}
		p.openInventory(inv);
	}

	// ---------- queue / invite ----------

	private void joinQueue(Player p) {
		Iterator<Map.Entry<UUID, Player>> it = queue.entrySet().iterator();
		while (it.hasNext()) {
			Player q = it.next().getValue();
			it.remove();
			if (q != p && isFree(q)) {
				startMatch(q, p, QUEUE_WINS);
				return;
			}
		}
		queue.put(p.getUniqueId(), p);
		p.sendMessage(c("&aเข้าคิวแล้ว กำลังหาคู่... &7(กดดาบอีกครั้งเพื่อออกจากคิว)"));
	}

	private void sendInvite(Player from, Player to, int rounds) {
		rounds = Math.max(1, Math.min(MAX_ROUNDS, rounds));
		if (!isFree(from) || !isFree(to) || from == to) {
			from.sendMessage(c("&cผู้เล่นไม่ว่าง"));
			return;
		}
		invites.put(to.getUniqueId(), new Invite(from.getUniqueId(), rounds, System.currentTimeMillis()));

		to.sendMessage(c("&e" + from.getName() + " &fท้าคุณสู้ &bSword PVP &7(&f" + rounds + " rounds&7)"));
		Component accept = c("&a[ตกลง]").clickEvent(ClickEvent.runCommand("/accept"));
		Component deny = c("&c[ปฏิเสธ]").clickEvent(ClickEvent.runCommand("/deny"));
		to.sendMessage(accept.append(c(" &7= /accept    ")).append(deny).append(c(" &7= /deny")));
		from.sendMessage(c("&aส่งคำท้าให้ &e" + to.getName() + " &aแล้ว &7(หมดอายุใน " + INVITE_SECONDS + " วิ)"));
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (!(sender instanceof Player p)) return true;
		Invite inv = invites.remove(p.getUniqueId());
		if (inv == null || System.currentTimeMillis() - inv.time() > INVITE_SECONDS * 1000L) {
			p.sendMessage(c("&cไม่มีคำท้าที่รออยู่"));
			return true;
		}
		Player from = Bukkit.getPlayer(inv.from());

		if (cmd.getName().equalsIgnoreCase("deny")) {
			p.sendMessage(c("&cปฏิเสธแล้ว"));
			if (from != null) from.sendMessage(c("&e" + p.getName() + " &cปฏิเสธคำท้า"));
			return true;
		}
		if (!isFree(from) || !isFree(p)) {
			p.sendMessage(c("&cตอนนี้เริ่มดวลไม่ได้ (ผู้เล่นไม่ว่าง)"));
			return true;
		}
		startMatch(from, p, inv.rounds());
		return true;
	}

	// ---------- match flow ----------

	private void startMatch(Player a, Player b, int target) {
		World arena = arenaWorld();
		if (arena == null) {
			a.sendMessage(c("&cหาโลก " + ARENA + " ไม่เจอ"));
			b.sendMessage(c("&cหาโลก " + ARENA + " ไม่เจอ"));
			return;
		}
		for (Player p : List.of(a, b)) {
			queue.remove(p.getUniqueId());
			invites.remove(p.getUniqueId());
		}
		Match m = new Match(a, b, target);
		matches.put(a.getUniqueId(), m);
		matches.put(b.getUniqueId(), m);

		Bukkit.broadcast(c("&b[Duel] &e" + a.getName() + " &fvs &e" + b.getName()
			+ " &7- Sword PVP (ชนะ " + target + " ตาก่อน)"));
		startRound(m);
		hideOthers(m);
	}

	/** ซ่อนผู้เล่นคู่อื่นในสนาม ให้เห็นแค่คู่ของตัวเอง */
	private void hideOthers(Match m) {
		later(3, () -> {
			for (Player q : Bukkit.getOnlinePlayers()) {
				if (q == m.a || q == m.b || !q.getWorld().getName().equals(ARENA)) continue;
				for (Player p : List.of(m.a, m.b)) {
					if (p.isOnline()) {
						p.hidePlayer(this, q);
						q.hidePlayer(this, p);
					}
				}
			}
		});
	}

	private void setupPlayer(Player p, int idx, World arena) {
		resetPlayer(p);
		p.getInventory().clear();
		p.getInventory().setHelmet(new ItemStack(Material.DIAMOND_HELMET));
		p.getInventory().setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
		p.getInventory().setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
		p.getInventory().setBoots(new ItemStack(Material.DIAMOND_BOOTS));
		p.getInventory().setItem(0, new ItemStack(Material.DIAMOND_SWORD));
		p.getInventory().setHeldItemSlot(0);

		double[] s = idx == 0 ? SPAWN_A : SPAWN_B;
		p.teleport(new Location(arena, s[0], s[1], s[2], idx == 0 ? 0f : 180f, 0f));
	}

	private void startRound(Match m) {
		World arena = arenaWorld();
		if (arena == null) return;
		m.round++;
		m.live = false;
		final int id = ++m.token;

		for (Player p : List.of(m.a, m.b)) {
			if (p.isOnline()) setupPlayer(p, m.idx(p), arena);
		}

		for (int n = 5; n >= 1; n--) {
			final int num = n;
			later((5 - n) * 20 + 1, () -> {
				if (m.ended || m.token != id) return;
				for (Player p : List.of(m.a, m.b)) {
					if (p.isOnline()) title(p, "&e" + num, "&7Round " + m.round, 1100);
				}
			});
		}
		later(101, () -> {
			if (m.ended || m.token != id) return;
			m.live = true;
			for (Player p : List.of(m.a, m.b)) {
				if (p.isOnline()) title(p, "&aFIGHT!", "", 1000);
			}
		});
	}

	private void winRound(Match m, Player winner) {
		if (!m.live || m.ended) return;
		m.live = false;
		m.token++;
		m.score[m.idx(winner)]++;

		for (Player p : List.of(m.a, m.b)) {
			if (p.isOnline()) {
				p.sendMessage(c("&eตาที่ " + m.round + " &f- &a" + winner.getName() + " &fชนะ &7("
					+ m.score[0] + " - " + m.score[1] + ")"));
			}
		}
		if (m.score[m.idx(winner)] >= m.target) {
			endMatch(m, winner);
			return;
		}
		final int id = m.token;
		later(40, () -> {
			if (!m.ended && m.token == id) startRound(m);
		});
	}

	private void endMatch(Match m, Player winner) {
		if (m.ended) return;
		m.ended = true;
		m.live = false;
		m.token++;
		Player loser = m.other(winner);
		matches.remove(m.a.getUniqueId());
		matches.remove(m.b.getUniqueId());

		Bukkit.broadcast(c("&b[Duel] &6" + winner.getName() + " &fชนะดวลกับ &6" + loser.getName()
			+ " &7(" + m.score[m.idx(winner)] + " - " + m.score[m.idx(loser)] + ")"));
		if (winner.isOnline()) title(winner, "&6ชนะ!", "", 2000);

		later(60, () -> {
			toLobby(m.a);
			toLobby(m.b);
		});
	}

	private void toLobby(Player p) {
		if (!p.isOnline() || matches.containsKey(p.getUniqueId())) return;
		for (Player q : Bukkit.getOnlinePlayers()) {
			if (q != p) {
				p.showPlayer(this, q);
				q.showPlayer(this, p);
			}
		}
		World lobby = Bukkit.getWorld(LOBBY);
		if (lobby != null) p.teleport(lobby.getSpawnLocation());
		resetPlayer(p);
		giveLobbyItems(p);
	}
}
