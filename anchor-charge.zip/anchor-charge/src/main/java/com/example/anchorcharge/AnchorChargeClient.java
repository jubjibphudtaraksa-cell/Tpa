package com.example.anchorcharge;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AnchorChargeClient implements ClientModInitializer {
    private static final int MAX_WAIT_TICKS = 10;

    private static boolean enabled = true;
    private static BlockPos pending = null;
    private static int waited = 0;

    @Override
    public void onInitializeClient() {
        // วาง Respawn Anchor -> จำตำแหน่งไว้
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (enabled && world.isClient()) {
                ItemStack stack = player.getStackInHand(hand);
                if (stack.isOf(Items.RESPAWN_ANCHOR)) {
                    pending = new ItemPlacementContext(player, hand, stack, hit).getBlockPos();
                    waited = 0;
                }
            }
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(AnchorChargeClient::tick);

        // /fastanchor-charge on | off
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("fastanchor-charge")
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(Text.literal("FastAnchor-Charge: " + (enabled ? "ON" : "OFF")));
                    return 1;
                })
                .then(ClientCommandManager.literal("on").executes(ctx -> {
                    enabled = true;
                    ctx.getSource().sendFeedback(Text.literal("FastAnchor-Charge: ON"));
                    return 1;
                }))
                .then(ClientCommandManager.literal("off").executes(ctx -> {
                    enabled = false;
                    pending = null;
                    ctx.getSource().sendFeedback(Text.literal("FastAnchor-Charge: OFF"));
                    return 1;
                }))));
    }

    private static void tick(MinecraftClient mc) {
        if (pending == null) return;

        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (!enabled || player == null || world == null || mc.interactionManager == null) {
            pending = null;
            return;
        }

        // รอให้ anchor ถูกวางจริงก่อน
        if (!world.getBlockState(pending).isOf(Blocks.RESPAWN_ANCHOR)) {
            if (++waited > MAX_WAIT_TICKS) pending = null;
            return;
        }

        // ชาร์จแล้วไม่ต้องใส่ซ้ำ
        if (world.getBlockState(pending).get(RespawnAnchorBlock.CHARGES) > 0) {
            pending = null;
            return;
        }

        int prevSlot = player.getInventory().getSelectedSlot();
        Hand hand = null;

        if (player.getOffHandStack().isOf(Items.GLOWSTONE)) {
            hand = Hand.OFF_HAND;
        } else {
            for (int i = 0; i < 9; i++) {
                if (player.getInventory().getStack(i).isOf(Items.GLOWSTONE)) {
                    player.getInventory().setSelectedSlot(i); // สลับเป็นโกลสโตน
                    hand = Hand.MAIN_HAND;
                    break;
                }
            }
        }

        // ไม่มีโกลสโตน = ไม่ทำอะไร (ไม่คลิกมือเปล่า เพราะอาจระเบิด)
        if (hand == null) {
            pending = null;
            return;
        }

        BlockHitResult hit = faceHit(pending, player.getEyePos());
        mc.interactionManager.interactBlock(player, hand, hit);
        player.swingHand(hand);

        player.getInventory().setSelectedSlot(prevSlot); // สลับกลับช่องเดิม
        pending = null;
    }

    // คลิกที่หน้าของบล็อกที่ "หันเข้าหาตา" จริงๆ (ไม่ใช่ด้านบนเสมอ)
    // ถ้า anchor อยู่ระดับหัวหรือสูงกว่า ด้านบนมองไม่เห็น เซิร์ฟเวอร์จะปฏิเสธคลิก
    private static BlockHitResult faceHit(BlockPos pos, Vec3d eye) {
        Vec3d c = Vec3d.ofCenter(pos);
        Direction dir = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);

        double x = MathHelper.clamp(eye.x, pos.getX() + 0.05, pos.getX() + 0.95);
        double y = MathHelper.clamp(eye.y, pos.getY() + 0.05, pos.getY() + 0.95);
        double z = MathHelper.clamp(eye.z, pos.getZ() + 0.05, pos.getZ() + 0.95);

        if (dir.getAxis() == Direction.Axis.X) x = pos.getX() + (dir.getOffsetX() > 0 ? 1.0 : 0.0);
        if (dir.getAxis() == Direction.Axis.Y) y = pos.getY() + (dir.getOffsetY() > 0 ? 1.0 : 0.0);
        if (dir.getAxis() == Direction.Axis.Z) z = pos.getZ() + (dir.getOffsetZ() > 0 ? 1.0 : 0.0);

        return new BlockHitResult(new Vec3d(x, y, z), dir, pos, false);
    }
}
