package com.example.anchorcharge;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class AnchorChargeClient implements ClientModInitializer {
    private static final int MAX_WAIT_TICKS = 10;

    private static BlockPos pending = null;
    private static int waited = 0;

    @Override
    public void onInitializeClient() {
        // จำตำแหน่งที่กำลังวาง Respawn Anchor
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient()) {
                ItemStack stack = player.getStackInHand(hand);
                if (stack.isOf(Items.RESPAWN_ANCHOR)) {
                    pending = new ItemPlacementContext(player, hand, stack, hit).getBlockPos();
                    waited = 0;
                }
            }
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(AnchorChargeClient::tick);
    }

    private static void tick(MinecraftClient mc) {
        if (pending == null) return;

        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (player == null || world == null || mc.interactionManager == null) {
            pending = null;
            return;
        }

        // รอจนกว่า anchor จะถูกวางจริง
        if (!world.getBlockState(pending).isOf(Blocks.RESPAWN_ANCHOR)) {
            if (++waited > MAX_WAIT_TICKS) pending = null;
            return;
        }

        // ชาร์จแล้ว ไม่ต้องทำซ้ำ (กันระเบิด)
        if (world.getBlockState(pending).get(RespawnAnchorBlock.CHARGES) > 0) {
            pending = null;
            return;
        }

        int prevSlot = player.getInventory().getSelectedSlot();
        Hand hand = null;

        if (player.getOffHandStack().isOf(Items.GLOWSTONE)) {
            hand = Hand.OFF_HAND;
        } else {
            for (int i = 0; i < 9; i++) {
                if (player.getInventory().getStack(i).isOf(Items.GLOWSTONE)) {
                    player.getInventory().setSelectedSlot(i);
                    hand = Hand.MAIN_HAND;
                    break;
                }
            }
        }

        // ไม่มี glowstone = ไม่ทำอะไรเลย (ไม่คลิกมือเปล่าเพราะจะระเบิด)
        if (hand == null) {
            pending = null;
            return;
        }

        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(pending), Direction.UP, pending, false);
        mc.interactionManager.interactBlock(player, hand, hit);
        player.swingHand(hand);

        player.getInventory().setSelectedSlot(prevSlot);
        pending = null;
    }
}
