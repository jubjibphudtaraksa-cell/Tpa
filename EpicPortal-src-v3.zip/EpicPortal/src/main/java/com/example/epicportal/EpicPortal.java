package com.example.epicportal;

import com.example.epicportal.listeners.CompassListener;
import com.example.epicportal.listeners.GUIListener;
import com.example.epicportal.listeners.NpcListener;
import com.example.epicportal.listeners.ProtectionListener;
import com.example.epicportal.listeners.SwordListener;
import com.example.epicportal.managers.QueueManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public final class EpicPortal extends JavaPlugin {

    private static EpicPortal instance;
    private QueueManager queueManager;
    private CompassListener compassListener;
    private SwordListener swordListener;
    private ProtectionListener protectionListener;
    private NpcListener npcListener;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        queueManager = new QueueManager(this);
        compassListener = new CompassListener(this);

        swordListener = new SwordListener(this);

        protectionListener = new ProtectionListener(this);
        getServer().getPluginManager().registerEvents(compassListener, this);
        getServer().getPluginManager().registerEvents(protectionListener, this);
        getServer().getPluginManager().registerEvents(swordListener, this);
        npcListener = new NpcListener(this);
        getServer().getPluginManager().registerEvents(npcListener, this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);

        // /queueleave command
        Objects.requireNonNull(getCommand("queueleave")).setExecutor(this::cmdQueueLeave);
        // /epicnpc command
        Objects.requireNonNull(getCommand("epicnpc")).setExecutor(this::cmdNpc);
        Objects.requireNonNull(getCommand("epicqueue")).setExecutor(this::cmdEpicQueue);
        // /queuepos command
        Objects.requireNonNull(getCommand("queuepos")).setExecutor(this::cmdQueuePos);

        queueManager.startTask();
        protectionListener.start();

        getLogger().info("EpicPortal enabled! EPIC=" + getConfig().getString("worlds.epic", "EPIC")
                + " -> SMP=" + getConfig().getString("worlds.smp", "world"));
    }

    @Override
    public void onDisable() {
        if (queueManager != null) queueManager.stopTask();
        getLogger().info("EpicPortal disabled.");
    }

    // ── Commands ────────────────────────────────────────────────────────────

    private boolean cmdQueueLeave(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command."));
            return true;
        }
        if (queueManager.removeFromQueue(player.getUniqueId())) {
            player.sendMessage(Component.text("✘ คุณออกจากคิวแล้ว").color(NamedTextColor.RED));
        } else {
            player.sendMessage(Component.text("คุณไม่ได้อยู่ในคิว").color(NamedTextColor.GRAY));
        }
        return true;
    }

    private boolean cmdQueuePos(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command."));
            return true;
        }
        int pos = queueManager.getPosition(player.getUniqueId());
        if (pos == -1) {
            player.sendMessage(Component.text("คุณไม่ได้อยู่ในคิว").color(NamedTextColor.GRAY));
        } else {
            player.sendMessage(Component.text("ตำแหน่งคิวของคุณ: ").color(NamedTextColor.GRAY)
                    .append(Component.text("#" + pos + " / " + queueManager.getQueueSize(player.getUniqueId()))
                            .color(NamedTextColor.YELLOW)));
        }
        return true;
    }

    /** /epicnpc <smp|pvp|remove> — สร้าง/ลบบอท (Mannequin ของ Minecraft ไม่ต้องใช้ Citizens) */
    private boolean cmdNpc(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command."));
            return true;
        }
        if (!player.hasPermission("epicportal.admin")) {
            player.sendMessage(Component.text("✘ คุณไม่มีสิทธิ์").color(NamedTextColor.RED));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(Component.text("ใช้: /epicnpc <smp|pvp|remove>").color(NamedTextColor.YELLOW));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "smp" -> createBot(player, QueueManager.TARGET_SMP);
            case "pvp", "lp" -> createBot(player, QueueManager.TARGET_LP);
            case "remove" -> {
                int n = npcListener.removeNearby(player, 5.0);
                player.sendMessage(n > 0
                        ? Component.text("✔ ลบบอท " + n + " ตัวแล้ว").color(NamedTextColor.GREEN)
                        : Component.text("ไม่พบบอทในระยะ 5 บล็อก").color(NamedTextColor.GRAY));
            }
            default -> player.sendMessage(Component.text("ใช้: /epicnpc <smp|pvp|remove>").color(NamedTextColor.YELLOW));
        }
        return true;
    }

    private void createBot(Player player, String target) {
        String skin = getConfig().getString("npc.skins." + target,
                QueueManager.TARGET_LP.equals(target) ? "jeb_" : "Notch");
        npcListener.spawnBot(player, target, skin, ok -> player.sendMessage(ok
                ? Component.text("✔ สร้างบอท " + target.toUpperCase() + " แล้ว (สกิน " + skin + ")")
                        .color(NamedTextColor.GREEN)
                : Component.text("✘ สร้างบอทไม่สำเร็จ — ดูข้อความ error ในคอนโซลเซิร์ฟเวอร์")
                        .color(NamedTextColor.RED)));
    }

    /** /epicqueue <player> <smp|lp> — คำสั่งเดิม (ยังใช้ได้) */
    private boolean cmdEpicQueue(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length < 2) return true;
        Player player = getServer().getPlayerExact(args[0]);
        if (player != null) queueFor(player, args[1].toLowerCase());
        return true;
    }

    /** เข้าคิวปลายทาง — เรียกจากการกดบอท */
    public void queueFor(Player player, String target) {
        if (!(target.equals(QueueManager.TARGET_SMP) || target.equals(QueueManager.TARGET_LP))) return;

        QueueManager qm = getQueueManager();
        String name = qm.getDisplayName(target);

        if (player.getWorld().getName().equalsIgnoreCase(qm.getWorldName(target))) {
            player.sendMessage(Component.text("✔ คุณอยู่ในโลก " + name + " แล้ว!").color(NamedTextColor.GREEN));
            return;
        }
        if (qm.isInQueue(player.getUniqueId())) {
            player.sendMessage(Component.text("! คุณอยู่ในคิวแล้ว ตำแหน่ง: ").color(NamedTextColor.YELLOW)
                    .append(Component.text("#" + qm.getPosition(player.getUniqueId()) + " / "
                            + qm.getQueueSize(player.getUniqueId())).color(NamedTextColor.WHITE)));
            player.sendMessage(Component.text("พิมพ์ /queueleave เพื่อออกจากคิว").color(NamedTextColor.GRAY));
            return;
        }
        if (qm.addToQueue(player, target)) {
            player.sendMessage(Component.text("✔ เข้าคิว " + name + " สำเร็จ! ตำแหน่ง: ").color(NamedTextColor.GREEN)
                    .append(Component.text("#" + qm.getPosition(player.getUniqueId()) + " / "
                            + qm.getQueueSize(target)).color(NamedTextColor.YELLOW)));
            player.sendMessage(Component.text("พิมพ์ /queueleave เพื่อออกจากคิว").color(NamedTextColor.GRAY));
        }
    }

    // ── Getters ─────────────────────────────────────────────────────────────

    public static EpicPortal getInstance() { return instance; }
    public QueueManager getQueueManager() { return queueManager; }
    public SwordListener getSwordListener() { return swordListener; }
    public ProtectionListener getProtectionListener() { return protectionListener; }
    public CompassListener getCompassListener() { return compassListener; }
}
