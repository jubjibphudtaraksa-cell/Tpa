package com.example.epicportal.listeners;

import com.example.epicportal.EpicPortal;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;

import java.util.Locale;

/**
 * บอท SMP/PVP แบบตัวผู้เล่นจริง (Minecraft Mannequin, 1.21.9+) — ไม่ต้องใช้ Citizens
 * ตัวบอทมี scoreboard tag "epicportal_npc" และ "epicportal_npc_<target>"
 */
public class NpcListener implements Listener {

    private static final String TAG = "epicportal_npc";
    private static final String TAG_PREFIX = "epicportal_npc_";

    private final EpicPortal plugin;

    public NpcListener(EpicPortal plugin) {
        this.plugin = plugin;
    }

    /** สร้างบอทตรงตำแหน่งผู้เล่น หันหน้าเข้าหาผู้เล่น */
    public void spawnBot(Player admin, String target, String skin, java.util.function.Consumer<Boolean> done) {
        if (!skin.matches("[A-Za-z0-9_]{1,16}")) { done.accept(false); return; }

        Location loc = admin.getLocation();
        float yaw = loc.getYaw() + 180f;
        String title = target.equals("lp")
                ? "{text:\"PVP\",color:\"red\",bold:true}"
                : "{text:\"SMP\",color:\"green\",bold:true}";

        String nbt = "{profile:{name:\"" + skin + "\"},"
                + "immovable:1b,hide_description:1b,"
                + "CustomName:" + title + ",CustomNameVisible:1b,"
                + "Invulnerable:1b,PersistenceRequired:1b,Silent:1b,"
                + "Rotation:[" + yaw + "f,0f],"
                + "Tags:[\"" + TAG + "\",\"" + TAG_PREFIX + target + "\"]}";

        String cmd = "execute as " + admin.getName() + " at @s run summon minecraft:mannequin ~ ~ ~ " + nbt;
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        // เช็กหลังผ่านไป 2 tick ว่ามีบอทเกิดจริง (ไม่พึ่งค่าที่คำสั่งคืนมา)
        Bukkit.getScheduler().runTaskLater(plugin, () ->
                done.accept(admin.isOnline() && findNearby(admin, 4.0, target) != null), 2L);
    }

    /** ลบบอทที่อยู่ใกล้ผู้เล่น — คืนจำนวนที่ลบ */
    public int removeNearby(Player player, double radius) {
        int n = 0;
        for (Entity e : player.getNearbyEntities(radius, radius, radius)) {
            if (e.getScoreboardTags().contains(TAG)) {
                e.remove();
                n++;
            }
        }
        return n;
    }

    private Entity findNearby(Player player, double radius, String target) {
        for (Entity e : player.getNearbyEntities(radius, radius, radius)) {
            if (!e.getScoreboardTags().contains(TAG)) continue;
            if (target == null || e.getScoreboardTags().contains(TAG_PREFIX + target)) return e;
        }
        return null;
    }

    // ── Click handling ────────────────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEntityEvent event) {
        String target = targetOf(event.getRightClicked());
        if (target == null) return;
        event.setCancelled(true);
        if (event.getHand() != EquipmentSlot.HAND) return;
        plugin.queueFor(event.getPlayer(), target);
    }

    /** คลิกซ้ายที่บอทก็เข้าคิวได้ และบอทไม่รับความเสียหาย */
    @EventHandler(priority = EventPriority.HIGH)
    public void onHit(EntityDamageByEntityEvent event) {
        String target = targetOf(event.getEntity());
        if (target == null) return;
        event.setCancelled(true);
        if (event.getDamager() instanceof Player p) plugin.queueFor(p, target);
    }

    private String targetOf(Entity entity) {
        if (!entity.getScoreboardTags().contains(TAG)) return null;
        for (String t : entity.getScoreboardTags()) {
            if (t.startsWith(TAG_PREFIX)) return t.substring(TAG_PREFIX.length()).toLowerCase(Locale.ROOT);
        }
        return null;
    }
}
