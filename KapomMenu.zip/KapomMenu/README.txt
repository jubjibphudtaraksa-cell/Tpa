KapomMenu - Dialog menus (Paper 1.21.7+ Dialog API)

Build:  mvn package   ->  target/KapomMenu-1.0.0.jar  (JDK 21)
Use:    /menu.  Put jar in plugins/, edit config.yml to map buttons to your commands.

Page flow
 Main (Homes RTP Auction RTP-Queue Quick-Buy Friends Orders Shard-Shop Sell Pay Teleport Stats Leaderboards Settings)
 Teleport -> player list (+ Add Player to List) -> "Teleport with X?" (Teleport to / Teleport here / Back)
 Pay      -> player list (+ Add Player to List) -> "Pay X" (1K 10K 35K 100K 180K 350K Custom Back) -> Custom: Amount + Continue / Back
 Settings -> Chat Notifications PvP Visuals Privacy Scoreboard General
 Add a Player -> Player Name input + Add to List / Back (separate lists for teleport and pay)
