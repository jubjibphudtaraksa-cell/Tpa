package com.kapom.menu;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.*;
import java.util.function.Consumer;

/**
 * Donut SMP style dialog menus.
 * Pages: Main -> Teleport list -> "Teleport with X?" / Add a Player
 *        Main -> Pay list -> "Pay X" amounts -> Custom amount / Add a Player
 *        Main -> Settings categories
 */
public class KapomMenuPlugin extends JavaPlugin {

    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (s instanceof Player p) mainMenu(p);
        return true;
    }

    // ---------- helpers ----------
    private static final ClickCallback.Options OPTS = ClickCallback.Options.builder()
            .uses(ClickCallback.UNLIMITED_USES).lifetime(Duration.ofMinutes(10)).build();

    private ActionButton btn(Component label, Consumer<Player> run) {
        return ActionButton.create(label, null, 200,
                DialogAction.customClick((view, aud) -> {
                    if (aud instanceof Player p) run.accept(p);
                }, OPTS));
    }

    private ActionButton btn(String label, Consumer<Player> run) {
        return btn(Component.text(label), run);
    }

    private ActionButton textBtn(Component label, java.util.function.BiConsumer<Player, String> run, String key) {
        return ActionButton.create(label, null, 200,
                DialogAction.customClick((view, aud) -> {
                    if (aud instanceof Player p) run.accept(p, view.getText(key));
                }, OPTS));
    }

    private void show(Player p, Component title, List<DialogBody> body, List<DialogInput> inputs,
                      List<ActionButton> buttons, ActionButton exit, int columns) {
        Dialog d = Dialog.create(f -> f.empty()
                .base(DialogBase.builder(title).body(body).inputs(inputs).canCloseWithEscape(true).build())
                .type(DialogType.multiAction(buttons, exit, columns)));
        p.showDialog(d);
    }

    private void run(Player p, String key, String player, String amount) {
        String cmd = getConfig().getString("commands." + key, key);
        cmd = cmd.replace("{player}", player == null ? "" : player)
                 .replace("{amount}", amount == null ? "" : amount);
        p.performCommand(cmd);
    }

    private static String short_(long v) {
        if (v >= 1_000_000) return (v / 1_000_000) + "M";
        if (v >= 1_000) return (v / 1_000) + "K";
        return String.valueOf(v);
    }

    // ---------- saved lists ----------
    private List<String> list(Player p, String kind) {
        return new ArrayList<>(data.getStringList(kind + "." + p.getUniqueId()));
    }

    private void addToList(Player p, String kind, String name) {
        List<String> l = list(p, kind);
        if (!l.contains(name)) l.add(name);
        data.set(kind + "." + p.getUniqueId(), l);
        try { data.save(dataFile); } catch (IOException e) { getLogger().warning(e.getMessage()); }
    }

    private List<String> names(Player p, String kind) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        for (Player o : Bukkit.getOnlinePlayers()) if (!o.equals(p)) out.add(o.getName());
        out.addAll(list(p, kind));
        out.remove(p.getName());
        return new ArrayList<>(out);
    }

    // ---------- page: main ----------
    public void mainMenu(Player p) {
        List<ActionButton> b = new ArrayList<>();
        b.add(btn("Homes", x -> run(x, "homes", null, null)));
        b.add(btn("RTP", x -> run(x, "rtp", null, null)));
        b.add(btn("Auction", x -> run(x, "auction", null, null)));
        b.add(btn("RTP Queue", x -> run(x, "rtp-queue", null, null)));
        b.add(btn("Quick Buy", x -> run(x, "quick-buy", null, null)));
        b.add(btn("Friends", x -> run(x, "friends", null, null)));
        b.add(btn("Orders", x -> run(x, "orders", null, null)));
        b.add(btn("Shard Shop", x -> run(x, "shard-shop", null, null)));
        b.add(btn("Sell", x -> run(x, "sell", null, null)));
        b.add(btn("Pay", this::payList));
        b.add(btn("Teleport", this::teleportList));
        b.add(btn("Stats", x -> run(x, "stats", null, null)));
        b.add(btn("Leaderboards", x -> run(x, "leaderboards", null, null)));
        b.add(btn("Settings", this::settings));
        show(p, Component.text(getConfig().getString("title", "Donut SMP")),
                List.of(), List.of(), b, null, 2);
    }

    // ---------- page: teleport list ----------
    private void teleportList(Player p) {
        List<ActionButton> b = new ArrayList<>();
        for (String n : names(p, "teleport")) b.add(btn(n, x -> teleportWith(x, n)));
        b.add(btn(Component.text("+ Add Player to List"), x -> addPlayer(x, "teleport")));
        show(p, Component.text("Teleport"), List.of(), List.of(), b,
                btn("Back", this::mainMenu), 2);
    }

    private void teleportWith(Player p, String name) {
        List<ActionButton> b = List.of(
                btn("Teleport to", x -> run(x, "tpa", name, null)),
                btn("Teleport here", x -> run(x, "tpahere", name, null)));
        show(p, Component.text("Teleport with " + name + "?"),
                List.of(DialogBody.plainMessage(Component.text(name))),
                List.of(), b, btn("Back", this::teleportList), 1);
    }

    // ---------- page: pay ----------
    private void payList(Player p) {
        List<ActionButton> b = new ArrayList<>();
        for (String n : names(p, "pay")) b.add(btn(n, x -> payAmount(x, n)));
        b.add(btn(Component.text("+ Add Player to List"), x -> addPlayer(x, "pay")));
        show(p, Component.text("Pay"), List.of(), List.of(), b,
                btn("Back", this::mainMenu), 2);
    }

    private void payAmount(Player p, String name) {
        List<ActionButton> b = new ArrayList<>();
        for (long v : getConfig().getLongList("pay-amounts")) {
            b.add(btn(Component.text("$ ", NamedTextColor.GREEN).append(Component.text(short_(v), NamedTextColor.WHITE)),
                    x -> run(x, "pay", name, String.valueOf(v))));
        }
        b.add(btn("Custom", x -> payCustom(x, name)));
        show(p, Component.text("Pay " + name),
                List.of(DialogBody.plainMessage(Component.text(name)),
                        DialogBody.plainMessage(Component.text("Choose an amount to pay", NamedTextColor.GRAY))),
                List.of(), b, btn("Back", x -> payList(x)), 2);
    }

    private void payCustom(Player p, String name) {
        List<ActionButton> b = List.of(
                textBtn(Component.text("Continue", NamedTextColor.GREEN), (x, txt) -> {
                    if (txt == null || !txt.matches("\\d+(\\.\\d+)?")) { payCustom(x, name); return; }
                    run(x, "pay", name, txt);
                }, "amount"));
        show(p, Component.text("Pay " + name),
                List.of(DialogBody.plainMessage(Component.text("Type the amount to pay " + name, NamedTextColor.GRAY))),
                List.of(DialogInput.text("amount", Component.text("Amount")).width(300).maxLength(16).build()),
                b, btn("Back", x -> payAmount(x, name)), 1);
    }

    // ---------- page: add player ----------
    private void addPlayer(Player p, String kind) {
        List<ActionButton> b = List.of(
                textBtn(Component.text("Add to List", NamedTextColor.GREEN), (x, txt) -> {
                    if (txt != null && !txt.isBlank()) addToList(x, kind, txt.trim());
                    if (kind.equals("pay")) payList(x); else teleportList(x);
                }, "name"));
        show(p, Component.text("Add a Player"),
                List.of(DialogBody.plainMessage(Component.text("Type a name to add to your "
                        + (kind.equals("pay") ? "pay" : "teleport") + " list", NamedTextColor.GRAY))),
                List.of(DialogInput.text("name", Component.text("Player Name")).width(300).maxLength(16).build()),
                b, btn("Back", x -> { if (kind.equals("pay")) payList(x); else teleportList(x); }), 1);
    }

    // ---------- page: settings ----------
    private void settings(Player p) {
        List<ActionButton> b = List.of(
                btn("Chat", x -> run(x, "settings-chat", null, null)),
                btn("Notifications", x -> run(x, "settings-notifications", null, null)),
                btn("PvP", x -> run(x, "settings-pvp", null, null)),
                btn("Visuals", x -> run(x, "settings-visuals", null, null)),
                btn("Privacy", x -> run(x, "settings-privacy", null, null)),
                btn("Scoreboard", x -> run(x, "settings-scoreboard", null, null)),
                btn("General", x -> run(x, "settings-general", null, null)));
        show(p, Component.text("Settings"),
                List.of(DialogBody.plainMessage(Component.text(
                        "Choose a category to change your " + getConfig().getString("title", "Donut SMP") + " settings",
                        NamedTextColor.GRAY))),
                List.of(), b, btn("Back", this::mainMenu), 2);
    }
}
