package hub.fiatx2.duel;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class DuelPlugin extends JavaPlugin implements Listener, CommandExecutor {

    enum State { COUNT, FIGHT, BETWEEN }

    static class Duel {
        final Player a, b;
        final int rounds, need;
        int round, sa, sb;
        State state = State.COUNT;
        boolean alive = true;
        final Map<UUID, ItemStack[]> inv = new HashMap<>();
        final Map<UUID, ItemStack[]> armor = new HashMap<>();
        final Map<UUID, Location> ret = new HashMap<>();
        final Map<UUID, GameMode> gm = new HashMap<>();

        Duel(Player a, Player b, int rounds) {
            this.a = a; this.b = b; this.rounds = rounds; this.need = rounds / 2 + 1;
        }
        boolean isA(Player p) { return p.getUniqueId().equals(a.getUniqueId()); }
        Player other(Player p) { return isA(p) ? b : a; }
    }

    record Request(UUID from, int rounds, long time) {}

    static class RoundsMenu implements InventoryHolder {
        final UUID target;
        Inventory inv;
        RoundsMenu(UUID target) { this.target = target; }
        @Override public Inventory getInventory() { return inv; }
    }

    private String lobbyTag, arenaWorld;
    private double[] spawnA, spawnB;
    private int countdown, queueRounds;

    private final Map<UUID, Duel> duels = new HashMap<>();
    private final Set<Duel> duelList = new HashSet<>();
    private final Map<UUID, Request> pending = new HashMap<>();
    private final LinkedList<UUID> queue = new LinkedList<>();
    private final Map<UUID, Long> cooldown = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        lobbyTag = getConfig().getString("lobby-tag", "lp");
        arenaWorld = getConfig().getString("arena-world", "sworld1");
        spawnA = toArr(getConfig().getDoubleList("spawn-a"), new double[]{137.5, 61, 44.5});
        spawnB = toArr(getConfig().getDoubleList("spawn-b"), new double[]{137.5, 61, 98.5});
        countdown = getConfig().getInt("countdown", 5);
        queueRounds = getConfig().getInt("queue-rounds", 5);

        getServer().getPluginManager().registerEvents(this, this);
        getCommand("accept").setExecutor(this);
        getCommand("deny").setExecutor(this);

        // ให้ไอเทม lobby ทุก 2 วิ
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) if (isLobby(p)) giveLobbyItems(p);
        }, 40L, 40L);
    }

    private static double[] toArr(List<Double> l, double[] def) {
        return l.size() == 3 ? new double[]{l.get(0), l.get(1), l.get(2)} : def;
    }

    // ================= helpers =================
    private boolean isLobby(Player p) {
        return p.getScoreboardTags().contains(lobbyTag) && !duels.containsKey(p.getUniqueId());
    }

    private Location spawn(boolean isA) {
        World w = Bukkit.getWorld(arenaWorld);
        if (w == null) return null;
        double[] s = isA ? spawnA : spawnB;
        return new Location(w, s[0], s[1], s[2], isA ? 0f : 180f, 0f);
    }

    private ItemStack named(Material m, String name, NamedTextColor color) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        it.setItemMeta(meta);
        return it;
    }

    private void giveLobbyItems(Player p) {
        if (p.getInventory().getItem(0) == null || p.getInventory().getItem(0).getType() != Material.DIAMOND_SWORD)
            p.getInventory().setItem(0, named(Material.DIAMOND_SWORD, "Sworld PVP", NamedTextColor.AQUA));
        if (p.getInventory().getItem(1) == null || p.getInventory().getItem(1).getType() != Material.IRON_SWORD)
            p.getInventory().setItem(1, named(Material.IRON_SWORD, "หาคู่", NamedTextColor.GRAY));
    }

    private void heal(Player p) {
        AttributeInstance mh = p.getAttribute(Attribute.MAX_HEALTH);
        p.setHealth(mh != null ? mh.getValue() : 20.0);
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.getActivePotionEffects().forEach(e -> p.removePotionEffect(e.getType()));
    }

    // เห็นแค่คู่ใครคู่มัน
    private void updateVisibility() {
        for (Player x : Bukkit.getOnlinePlayers()) {
            for (Player y : Bukkit.getOnlinePlayers()) {
                if (x == y) continue;
                Duel dx = duels.get(x.getUniqueId()), dy = duels.get(y.getUniqueId());
                boolean show = (dx == null && dy == null) || dx == dy;
                if (show) x.showPlayer(this, y); else x.hidePlayer(this, y);
            }
        }
    }

    // ================= lobby: หาคู่ / ท้า =================
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        ItemStack it = p.getInventory().getItemInMainHand();
        if (it.getType() != Material.IRON_SWORD || !isLobby(p)) return;
        e.setCancelled(true);
        toggleQueue(p);
    }

    private void toggleQueue(Player p) {
        if (queue.remove(p.getUniqueId())) {
            p.sendMessage(Component.text("ยกเลิกหาคู่แล้ว", NamedTextColor.RED));
            return;
        }
        while (!queue.isEmpty()) {
            Player other = Bukkit.getPlayer(queue.poll());
            if (other != null && other.isOnline() && isLobby(other) && other != p) {
                Bukkit.broadcast(Component.text(other.getName(), NamedTextColor.YELLOW)
                        .append(Component.text(" vs ", NamedTextColor.WHITE))
                        .append(Component.text(p.getName(), NamedTextColor.YELLOW))
                        .append(Component.text(" (Sworld PVP, ชนะ " + (queueRounds / 2 + 1) + " ก่อน)", NamedTextColor.GRAY)));
                startDuel(other, p, queueRounds);
                return;
            }
        }
        queue.add(p.getUniqueId());
        p.sendMessage(Component.text("กำลังหาคู่... (กดดาบเหล็กอีกครั้งเพื่อยกเลิก)", NamedTextColor.GREEN));
    }

    private void challengeHit(Player a, Player b) {
        long now = System.currentTimeMillis();
        if (now - cooldown.getOrDefault(a.getUniqueId(), 0L) < 2000) return;
        cooldown.put(a.getUniqueId(), now);
        RoundsMenu holder = new RoundsMenu(b.getUniqueId());
        Inventory inv = Bukkit.createInventory(holder, 27,
                Component.text("ท้า " + b.getName() + " - เลือก Rounds"));
        holder.inv = inv;
        for (int i = 1; i <= 20; i++) {
            ItemStack it = named(Material.PAPER, i + " rounds", NamedTextColor.GREEN);
            it.setAmount(i);
            inv.setItem(i - 1, it);
        }
        a.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof RoundsMenu m)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getInventory()) return;
        int slot = e.getSlot();
        if (slot < 0 || slot >= 20) return;
        p.closeInventory();
        sendChallenge(p, Bukkit.getPlayer(m.target), slot + 1);
    }

    private void sendChallenge(Player p, Player target, int rounds) {
        if (target == null || !target.isOnline() || !isLobby(target) || !isLobby(p)) {
            p.sendMessage(Component.text("ท้าไม่ได้ตอนนี้", NamedTextColor.RED));
            return;
        }
        pending.put(target.getUniqueId(), new Request(p.getUniqueId(), rounds, System.currentTimeMillis()));
        target.sendMessage(Component.text(p.getName(), NamedTextColor.YELLOW)
                .append(Component.text(" ท้า ", NamedTextColor.WHITE))
                .append(Component.text("Sworld PVP", NamedTextColor.AQUA))
                .append(Component.text(" " + rounds + " rounds", NamedTextColor.WHITE))
                .appendNewline()
                .append(Component.text("[ตกลง]", NamedTextColor.GREEN).clickEvent(ClickEvent.runCommand("/accept")))
                .append(Component.text("  "))
                .append(Component.text("[ปฏิเสธ]", NamedTextColor.RED).clickEvent(ClickEvent.runCommand("/deny")))
                .append(Component.text("   /accept  /deny", NamedTextColor.GRAY)));
        p.sendMessage(Component.text("ส่งคำท้าให้ " + target.getName() + " แล้ว", NamedTextColor.GREEN));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        boolean accept = cmd.getName().equalsIgnoreCase("accept");
        Request req = pending.remove(p.getUniqueId());
        if (req == null || System.currentTimeMillis() - req.time() > 60_000) {
            p.sendMessage(Component.text("ไม่มีคำท้า หรือหมดเวลาแล้ว", NamedTextColor.RED));
            return true;
        }
        Player from = Bukkit.getPlayer(req.from());
        if (from == null || !from.isOnline()) {
            p.sendMessage(Component.text("ผู้ท้าออกไปแล้ว", NamedTextColor.RED));
            return true;
        }
        if (!accept) {
            from.sendMessage(Component.text(p.getName() + " ปฏิเสธคำท้า", NamedTextColor.RED));
            return true;
        }
        if (!isLobby(from) || !isLobby(p)) {
            p.sendMessage(Component.text("เริ่มไม่ได้ตอนนี้", NamedTextColor.RED));
            return true;
        }
        startDuel(from, p, req.rounds());
        return true;
    }

    // ================= duel =================
    private void startDuel(Player a, Player b, int rounds) {
        if (spawn(true) == null) {
            String m = "ไม่พบโลก " + arenaWorld;
            a.sendMessage(Component.text(m, NamedTextColor.RED));
            b.sendMessage(Component.text(m, NamedTextColor.RED));
            return;
        }
        queue.remove(a.getUniqueId());
        queue.remove(b.getUniqueId());
        Duel d = new Duel(a, b, rounds);
        for (Player p : new Player[]{a, b}) {
            UUID id = p.getUniqueId();
            d.inv.put(id, p.getInventory().getContents().clone());
            d.armor.put(id, p.getInventory().getArmorContents().clone());
            d.ret.put(id, p.getLocation());
            d.gm.put(id, p.getGameMode());
            duels.put(id, d);
        }
        duelList.add(d);
        updateVisibility();
        startRound(d);
    }

    private void setup(Player p, Location loc) {
        p.setGameMode(GameMode.SURVIVAL);
        p.setCollidable(false);
        heal(p);
        p.getInventory().clear();
        p.getInventory().setHelmet(new ItemStack(Material.DIAMOND_HELMET));
        p.getInventory().setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
        p.getInventory().setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
        p.getInventory().setBoots(new ItemStack(Material.DIAMOND_BOOTS));
        p.getInventory().setItem(0, new ItemStack(Material.DIAMOND_SWORD));
        p.getInventory().setHeldItemSlot(0);
        p.teleport(loc);
    }

    private void startRound(Duel d) {
        if (!d.alive || !d.a.isOnline() || !d.b.isOnline()) return;
        d.round++;
        d.state = State.COUNT;
        setup(d.a, spawn(true));
        setup(d.b, spawn(false));
        tick(d, countdown);
    }

    private void tick(Duel d, int n) {
        if (!d.alive || d.state != State.COUNT) return;
        if (n > 0) {
            for (Player p : new Player[]{d.a, d.b}) {
                p.showTitle(Title.title(Component.text(String.valueOf(n), NamedTextColor.YELLOW), Component.empty(),
                        Title.Times.times(Duration.ZERO, Duration.ofMillis(1000), Duration.ZERO)));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1f);
            }
            Bukkit.getScheduler().runTaskLater(this, () -> tick(d, n - 1), 20L);
        } else {
            for (Player p : new Player[]{d.a, d.b}) {
                p.showTitle(Title.title(Component.text("FIGHT!", NamedTextColor.GREEN), Component.empty(),
                        Title.Times.times(Duration.ZERO, Duration.ofMillis(1000), Duration.ofMillis(250))));
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
            }
            d.state = State.FIGHT;
        }
    }

    // ล็อกตำแหน่งตอนนับถอยหลัง (หมุนหัวได้)
    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Duel d = duels.get(e.getPlayer().getUniqueId());
        if (d == null || d.state != State.COUNT) return;
        Location f = e.getFrom(), t = e.getTo();
        if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
            Location n = t.clone();
            n.setX(f.getX()); n.setY(f.getY()); n.setZ(f.getZ());
            e.setTo(n);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player v)) return;
        Player attacker = null;
        if (e instanceof EntityDamageByEntityEvent be) {
            Entity dmg = be.getDamager();
            if (dmg instanceof Projectile pr && pr.getShooter() instanceof Player s) dmg = s;
            if (dmg instanceof Player p) attacker = p;
        }
        Duel dv = duels.get(v.getUniqueId());
        if (dv == null) {
            if (v.getScoreboardTags().contains(lobbyTag)) {
                e.setCancelled(true);                       // lobby ไม่เสียเลือด
                if (attacker != null && isLobby(attacker) && isLobby(v)) challengeHit(attacker, v);
            }
            return;
        }
        if (dv.state != State.FIGHT) { e.setCancelled(true); return; }
        if (attacker != null && duels.get(attacker.getUniqueId()) != dv) { e.setCancelled(true); return; }
        if (v.getHealth() - e.getFinalDamage() <= 0) {      // ไม่ให้ตายจริง
            e.setCancelled(true);
            roundEnd(dv, dv.other(v));
        }
    }

    private void roundEnd(Duel d, Player winner) {
        if (d.state != State.FIGHT) return;
        d.state = State.BETWEEN;
        if (d.isA(winner)) d.sa++; else d.sb++;
        Component msg = Component.text("Round " + d.round + ": ", NamedTextColor.GRAY)
                .append(Component.text(winner.getName(), NamedTextColor.YELLOW))
                .append(Component.text(" ชนะ (" + d.sa + " - " + d.sb + ")", NamedTextColor.GRAY));
        d.a.sendMessage(msg);
        d.b.sendMessage(msg);
        if ((d.isA(winner) ? d.sa : d.sb) >= d.need)
            Bukkit.getScheduler().runTaskLater(this, () -> finish(d, winner), 40L);
        else
            Bukkit.getScheduler().runTaskLater(this, () -> startRound(d), 60L);
    }

    private void finish(Duel d, Player winner) {
        if (!d.alive) return;
        d.alive = false;
        d.state = State.BETWEEN;
        for (Player p : new Player[]{d.a, d.b}) {
            UUID id = p.getUniqueId();
            duels.remove(id);
            if (!p.isOnline()) continue;
            p.sendMessage(Component.text("🏆 " + winner.getName() + " ชนะ " + d.sa + " - " + d.sb, NamedTextColor.GOLD));
            p.showTitle(Title.title(
                    p.getUniqueId().equals(winner.getUniqueId())
                            ? Component.text("YOU WIN", NamedTextColor.GREEN)
                            : Component.text("YOU LOSE", NamedTextColor.RED),
                    Component.empty()));
            p.getInventory().clear();
            p.getInventory().setContents(d.inv.get(id));
            p.getInventory().setArmorContents(d.armor.get(id));
            p.setGameMode(d.gm.get(id));
            p.setCollidable(true);
            heal(p);
            p.teleport(d.ret.get(id));
        }
        duelList.remove(d);
        updateVisibility();
    }

    // ================= misc =================
    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        queue.remove(p.getUniqueId());
        pending.remove(p.getUniqueId());
        Duel d = duels.get(p.getUniqueId());
        if (d != null && d.alive) finish(d, d.other(p));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTask(this, () -> {
            updateVisibility();
            if (isLobby(e.getPlayer())) giveLobbyItems(e.getPlayer());
        });
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        if (duels.containsKey(p.getUniqueId())) { e.setCancelled(true); return; }
        Material t = e.getItemDrop().getItemStack().getType();
        if (isLobby(p) && (t == Material.DIAMOND_SWORD || t == Material.IRON_SWORD)) e.setCancelled(true);
    }
}
