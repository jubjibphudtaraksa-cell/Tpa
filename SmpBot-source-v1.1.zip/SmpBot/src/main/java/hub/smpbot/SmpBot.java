package hub.smpbot;

import com.destroystokyo.paper.profile.ProfileProperty;
import io.papermc.paper.datacomponent.item.ResolvableProfile;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Mannequin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SmpBot extends JavaPlugin implements Listener {

    private NamespacedKey idKey;      // ใหม่: เก็บ id ของบอท (string)
    private NamespacedKey legacyKey;  // เก่า: บอท SMP รุ่น 1.0 (byte)
    private final MiniMessage mm = MiniMessage.miniMessage();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        idKey = new NamespacedKey(this, "botid");
        legacyKey = new NamespacedKey(this, "smpbot");
        getServer().getPluginManager().registerEvents(this, this);
    }

    /** คืน id ของบอท หรือ null ถ้าไม่ใช่บอทของเรา */
    private String botId(Entity e) {
        if (!(e instanceof Mannequin)) return null;
        var pdc = e.getPersistentDataContainer();
        String id = pdc.get(idKey, PersistentDataType.STRING);
        if (id != null) return id;
        if (pdc.has(legacyKey, PersistentDataType.BYTE)) return "smp";
        return null;
    }

    private ConfigurationSection bot(String id) {
        return getConfig().getConfigurationSection("bots." + id);
    }

    private ResolvableProfile buildProfile(ConfigurationSection c) {
        ResolvableProfile.Builder b = ResolvableProfile.resolvableProfile();
        String value = c.getString("skin-value", "");
        String sig = c.getString("skin-signature", "");
        if (!value.isBlank() && !sig.isBlank()) {
            b.addProperty(new ProfileProperty("textures", value, sig));
        } else {
            b.name(c.getString("skin-name", "Notch"));
        }
        return b.build();
    }

    private void spawnBot(Location loc, String id, ConfigurationSection c) {
        loc.getWorld().spawn(loc, Mannequin.class, m -> {
            m.setProfile(buildProfile(c));
            m.setImmovable(true);
            m.setInvulnerable(true);
            m.setPersistent(true);
            m.setRemoveWhenFarAway(false);
            m.customName(mm.deserialize(c.getString("bot-name", id.toUpperCase(Locale.ROOT))));
            m.setCustomNameVisible(true);
            m.setDescription(mm.deserialize(c.getString("description", "")));
            m.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, id);
        });
    }

    @EventHandler
    public void onClick(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        String id = botId(e.getRightClicked());
        if (id == null) return;
        e.setCancelled(true);
        warp(e.getPlayer(), id);
    }

    private void warp(Player p, String id) {
        ConfigurationSection c = bot(id);
        if (c == null) {
            p.sendMessage(mm.deserialize("<red>ไม่พบการตั้งค่าบอท " + id));
            return;
        }
        String worldName = c.getString("world", id);
        World w = Bukkit.getWorld(worldName);
        if (w == null) {
            p.sendMessage(mm.deserialize(getConfig().getString("messages.world-not-found",
                    "<red>ไม่พบโลก %world%").replace("%world%", worldName)));
            return;
        }
        Location dest;
        if (c.getBoolean("custom-location.enabled", false)) {
            dest = new Location(w,
                    c.getDouble("custom-location.x"),
                    c.getDouble("custom-location.y"),
                    c.getDouble("custom-location.z"),
                    (float) c.getDouble("custom-location.yaw"),
                    (float) c.getDouble("custom-location.pitch"));
        } else {
            dest = w.getSpawnLocation().add(0.5, 0, 0.5);
        }
        p.teleportAsync(dest).thenAccept(ok -> {
            if (ok) {
                p.sendMessage(mm.deserialize(c.getString("teleported", "<green>เทเลพอร์ตแล้ว")));
            }
        });
    }

    private List<String> botIds() {
        ConfigurationSection s = getConfig().getConfigurationSection("bots");
        return s == null ? List.of() : new ArrayList<>(s.getKeys(false));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) return false;
        switch (a[0].toLowerCase()) {
            case "spawn" -> {
                if (!(s instanceof Player p)) { s.sendMessage("ใช้ในเกมเท่านั้น"); return true; }
                if (a.length < 2) { s.sendMessage("ใช้: /smpbot spawn <" + String.join("|", botIds()) + ">"); return true; }
                String id = a[1].toLowerCase();
                ConfigurationSection cfg = bot(id);
                if (cfg == null) { s.sendMessage("ไม่มีบอท id นี้ใน config"); return true; }
                spawnBot(p.getLocation(), id, cfg);
                s.sendMessage("สร้างบอท " + id + " แล้ว");
            }
            case "remove" -> {
                if (!(s instanceof Player p)) { s.sendMessage("ใช้ในเกมเท่านั้น"); return true; }
                p.getNearbyEntities(4, 4, 4).stream().filter(en -> botId(en) != null).findFirst()
                        .ifPresentOrElse(en -> { en.remove(); s.sendMessage("ลบแล้ว"); },
                                () -> s.sendMessage("ไม่พบบอทใกล้ๆ"));
            }
            case "reload" -> {
                reloadConfig();
                s.sendMessage("รีโหลดแล้ว (บอทเดิมต้องลบแล้วสร้างใหม่ถึงจะเปลี่ยนสกิน/ชื่อ)");
            }
            case "list" -> s.sendMessage("บอท: " + String.join(", ", botIds()));
            default -> { return false; }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return List.of("spawn", "remove", "reload", "list");
        if (a.length == 2 && a[0].equalsIgnoreCase("spawn")) return botIds();
        return List.of();
    }
}
