# KapomLink (ปลั๊กอิน)

Paper 1.21.11 / Java 21 / Maven

## Build
```
mvn clean package
```
ได้ไฟล์ `target/KapomLink-1.1.0.jar` → ใส่ในโฟลเดอร์ `plugins/`

## ตั้งค่า
1. รันเซิร์ฟเวอร์ 1 ครั้งเพื่อสร้าง `plugins/KapomLink/config.yml`
2. แก้ `backend.url` (ต้องเป็น `https://` เท่านั้น)
3. ตั้ง Secret (ยาวอย่างน้อย 16 ตัวอักษร) แนะนำให้ใช้ environment variable `KAPOM_API_SECRET` แทนการเขียนลง config
4. รีสตาร์ทเซิร์ฟเวอร์

ถ้า URL ไม่ใช่ https หรือ Secret ยังเป็นค่าเริ่มต้น ปลั๊กอินจะปิดตัวเองและไม่พิมพ์ Secret ลง console

## คำสั่ง
- `/verify <code>` – ยืนยันบัญชี (ส่ง UUID/ชื่อจากเซิร์ฟเวอร์เอง ไม่ใช่จากเว็บ)
- `/unlink` แล้วพิมพ์ `/unlink confirm` ภายใน 30 วินาที – ยกเลิกการเชื่อมบัญชี

## ส่งเจมส์อัตโนมัติ (ใหม่ใน 1.1.0)
- ทุก 15 วินาที (และตอนผู้เล่นเข้าเซิร์ฟ) ปลั๊กอินจะถามเว็บว่ามีออเดอร์เจมส์รอส่งไหม
- ถ้าผู้เล่นออนไลน์ ปลั๊กอินจะสั่ง `gems give <ชื่อผู้เล่น> <จำนวน>` จาก console แล้วแจ้งเว็บว่าส่งแล้ว
- ถ้าผู้เล่นออฟไลน์ ออเดอร์จะรอไว้จนกว่าเขาจะเข้าเซิร์ฟ
- ออเดอร์ที่ส่งในเกมแล้วแต่ยังแจ้งเว็บไม่สำเร็จ จะถูกจดไว้ใน `plugins/KapomLink/gems-unconfirmed.txt` เพื่อไม่ให้เจมส์ซ้ำ (ห้ามลบไฟล์นี้)
- ตั้งค่าได้ในหมวด `gems:` ของ `config.yml` (คำสั่ง, ต้องออนไลน์ไหม, ความถี่)
- ถ้าอัปเดตจาก 1.0.0 ให้เพิ่มหมวด `gems:` และข้อความ `messages.gems-received` ลงใน config.yml เดิม (หรือลบไฟล์ให้สร้างใหม่ แล้วใส่ url/secret กลับ)

## สัญญา API ที่ Backend ต้องรองรับ (ทำภายหลัง)
`POST {url}/api/link/verify` body: `{"code","uuid","username"}`
`POST {url}/api/link/unlink` body: `{"uuid"}`
`POST {url}/api/link/gems/pending` body: `{}` → `{"ok":true,"deliveries":[{"id","uuid","username","gems"}]}`
`POST {url}/api/link/gems/ack` body: `{"id","uuid"}`

Header ทุกคำขอ:
- `X-Kapom-Timestamp` (วินาที unix) – Backend ควรปฏิเสธถ้าห่างเกิน ~60 วินาที
- `X-Kapom-Nonce` – Backend ต้องจำและปฏิเสธ nonce ซ้ำ (กัน replay)
- `X-Kapom-Signature` = hex(HMAC-SHA256(secret, `timestamp\nnonce\npath\nbody`))

ตอบกลับ JSON: สำเร็จ `200 {"ok":true}` / ล้มเหลว `{"ok":false,"error":"<code>"}`
error code ที่ปลั๊กอินรู้จัก: `invalid_code`, `expired_code`, `used_code`, `too_many_attempts`, `already_linked`, `not_linked`, `rate_limited`

## หมายเหตุ
- Paper อาจบันทึกคำสั่ง `/verify XXXX` ลง console log ของเซิร์ฟเวอร์ เนื่องจากรหัสหมดอายุใน 5 นาทีและใช้ได้ครั้งเดียว ความเสี่ยงต่ำ แต่ซ่อนได้ด้วย log filter
- สถานะ Verified ไม่ควรใช้แจกไอเทม/ยศ และแยกจากการยืนยันการชำระเงิน
