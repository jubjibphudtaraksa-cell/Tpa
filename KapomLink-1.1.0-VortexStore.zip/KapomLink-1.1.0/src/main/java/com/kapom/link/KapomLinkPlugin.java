package com.kapom.link;

import org.bukkit.command.PluginCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;

public final class KapomLinkPlugin extends JavaPlugin implements Listener {

    private static final String PLACEHOLDER_SECRET = "CHANGE_ME_TO_A_LONG_RANDOM_SECRET";

    private BackendClient backend;
    private Messages messages;
    private int verifyCooldownSeconds;
    private int unlinkConfirmSeconds;
    private VerifyCommand verifyCommand;
    private UnlinkCommand unlinkCommand;
    private GemDeliveryTask gemDelivery;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        String url = getConfig().getString("backend.url", "").trim();
        String secret = System.getenv("KAPOM_API_SECRET");
        if (secret == null || secret.isBlank()) {
            secret = getConfig().getString("backend.api-secret", "").trim();
        }

        // The secret is never printed anywhere below.
        if (!url.toLowerCase().startsWith("https://")) {
            getLogger().severe("backend.url must start with https:// - disabling plugin.");
            disable();
            return;
        }
        if (secret.isBlank() || secret.equals(PLACEHOLDER_SECRET) || secret.length() < 16) {
            getLogger().severe("API secret is missing, still the placeholder, or shorter than 16 characters. "
                    + "Set backend.api-secret in config.yml or the KAPOM_API_SECRET environment variable. Disabling plugin.");
            disable();
            return;
        }

        int timeout = Math.max(2, Math.min(30, getConfig().getInt("backend.timeout-seconds", 8)));
        this.verifyCooldownSeconds = Math.max(1, getConfig().getInt("settings.verify-cooldown-seconds", 5));
        this.unlinkConfirmSeconds = Math.max(5, getConfig().getInt("settings.unlink-confirm-seconds", 30));
        this.messages = new Messages(getConfig());
        this.backend = new BackendClient(url, secret, Duration.ofSeconds(timeout));

        this.verifyCommand = new VerifyCommand(this);
        this.unlinkCommand = new UnlinkCommand(this);

        PluginCommand verify = getCommand("verify");
        PluginCommand unlink = getCommand("unlink");
        if (verify == null || unlink == null) {
            getLogger().severe("Commands missing from plugin.yml - disabling plugin.");
            disable();
            return;
        }
        verify.setExecutor(verifyCommand);
        unlink.setExecutor(unlinkCommand);
        unlink.setTabCompleter(unlinkCommand);

        getServer().getPluginManager().registerEvents(this, this);

        if (getConfig().getBoolean("gems.enabled", true)) {
            String command = getConfig().getString("gems.command", "gems give %player% %amount%").trim();
            boolean requireOnline = getConfig().getBoolean("gems.require-online", true);
            int poll = Math.max(5, Math.min(300, getConfig().getInt("gems.poll-seconds", 15)));
            this.gemDelivery = new GemDeliveryTask(this, command, requireOnline, poll);
            gemDelivery.start();
            getLogger().info("Gem delivery on: checking the website every " + poll + "s.");
        }

        getLogger().info("KapomLink enabled (backend host configured, secret hidden).");
    }

    @Override
    public void onDisable() {
        if (gemDelivery != null) gemDelivery.stop();
    }

    private void disable() {
        getServer().getPluginManager().disablePlugin(this);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (gemDelivery != null) gemDelivery.pollSoon();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (verifyCommand != null) verifyCommand.forget(event.getPlayer().getUniqueId());
        if (unlinkCommand != null) unlinkCommand.forget(event.getPlayer().getUniqueId());
    }

    public BackendClient backend() {
        return backend;
    }

    public Messages messages() {
        return messages;
    }

    public int verifyCooldownSeconds() {
        return verifyCooldownSeconds;
    }

    public int unlinkConfirmSeconds() {
        return unlinkConfirmSeconds;
    }
}
