package com.kapom.link;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public final class VerifyCommand implements CommandExecutor {

    private static final Pattern CODE_FORMAT = Pattern.compile("^[A-Za-z0-9]{4,32}$");

    private final KapomLinkPlugin plugin;
    private final Map<UUID, Long> lastAttempt = new ConcurrentHashMap<>();
    private final Set<UUID> inFlight = ConcurrentHashMap.newKeySet();

    public VerifyCommand(KapomLinkPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        Messages msg = plugin.messages();

        if (!(sender instanceof Player player)) {
            sender.sendMessage(msg.get("player-only"));
            return true;
        }
        if (args.length != 1) {
            player.sendMessage(msg.get("verify-usage"));
            return true;
        }
        String code = args[0].trim();
        if (!CODE_FORMAT.matcher(code).matches()) {
            player.sendMessage(msg.get("invalid-format"));
            return true;
        }

        // UUID and name come from the server, never from the website or the player.
        final UUID uuid = player.getUniqueId();
        final String name = player.getName();

        long now = System.currentTimeMillis();
        long cooldownMs = plugin.verifyCooldownSeconds() * 1000L;
        Long last = lastAttempt.get(uuid);
        if (last != null && now - last < cooldownMs) {
            player.sendMessage(msg.get("cooldown"));
            return true;
        }
        if (!inFlight.add(uuid)) {
            player.sendMessage(msg.get("busy"));
            return true;
        }
        lastAttempt.put(uuid, now);
        player.sendMessage(msg.get("checking"));

        // Async HTTP call; the reply is delivered back on the main thread.
        plugin.backend().verify(uuid, name, code).whenComplete((result, error) -> {
            ApiResult r = (error != null || result == null) ? ApiResult.error("network_error") : result;
            if (!plugin.isEnabled()) {
                inFlight.remove(uuid);
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                inFlight.remove(uuid);
                Player online = Bukkit.getPlayer(uuid);
                if (online == null) return;
                online.sendMessage(r.ok() ? plugin.messages().get("verify-success")
                                          : plugin.messages().error(r.errorCode()));
            });
        });
        return true;
    }

    public void forget(UUID uuid) {
        lastAttempt.remove(uuid);
    }
}
