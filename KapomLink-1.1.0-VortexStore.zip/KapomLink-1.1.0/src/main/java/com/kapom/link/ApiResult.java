package com.kapom.link;

/**
 * Result of a backend call.
 *
 * @param ok        true when the backend confirmed success
 * @param errorCode machine-readable error code (null when ok)
 */
public record ApiResult(boolean ok, String errorCode) {

    public static ApiResult success() {
        return new ApiResult(true, null);
    }

    public static ApiResult error(String code) {
        return new ApiResult(false, code == null || code.isBlank() ? "unknown" : code);
    }
}
