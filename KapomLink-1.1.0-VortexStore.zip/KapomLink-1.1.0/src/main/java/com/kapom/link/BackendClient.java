package com.kapom.link;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.HexFormat;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Talks to the Kapom SMP backend over HTTPS. All calls are asynchronous and never
 * block the main server thread.
 *
 * Every request is signed:
 *   X-Kapom-Timestamp : unix seconds
 *   X-Kapom-Nonce     : random hex (backend must reject reused nonces)
 *   X-Kapom-Signature : hex(HMAC-SHA256(secret, timestamp "\n" nonce "\n" path "\n" body))
 * The secret itself is never sent over the wire.
 */
public final class BackendClient {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final HttpClient http;
    private final String baseUrl;
    private final byte[] secret;
    private final Duration timeout;

    public BackendClient(String baseUrl, String secret, Duration timeout) {
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        this.secret = secret.getBytes(StandardCharsets.UTF_8);
        this.timeout = timeout;
        this.http = HttpClient.newBuilder()
                .connectTimeout(timeout)
                .followRedirects(HttpClient.Redirect.NEVER) // never forward signed requests elsewhere
                .build();
    }

    /** Ask the backend to link the code to this player. UUID/name come from the server, never the player. */
    public CompletableFuture<ApiResult> verify(UUID uuid, String playerName, String code) {
        JsonObject body = new JsonObject();
        body.addProperty("code", code);
        body.addProperty("uuid", uuid.toString());
        body.addProperty("username", playerName);
        return post("/api/link/verify", body);
    }

    public CompletableFuture<ApiResult> unlink(UUID uuid) {
        JsonObject body = new JsonObject();
        body.addProperty("uuid", uuid.toString());
        return post("/api/link/unlink", body);
    }

    /** Pending gem purchases waiting to be given in game. Completes with null on any failure. */
    public CompletableFuture<JsonArray> pendingGems() {
        return postJson("/api/link/gems/pending", new JsonObject()).thenApply(json -> {
            if (json == null || !json.has("deliveries") || !json.get("deliveries").isJsonArray()) return null;
            return json.getAsJsonArray("deliveries");
        });
    }

    /** Tell the backend a gem delivery was given, so it is never sent again. */
    public CompletableFuture<ApiResult> ackGems(long id, UUID uuid) {
        JsonObject body = new JsonObject();
        body.addProperty("id", id);
        body.addProperty("uuid", uuid.toString());
        return post("/api/link/gems/ack", body);
    }

    private CompletableFuture<ApiResult> post(String path, JsonObject body) {
        HttpRequest request = signedRequest(path, body);
        if (request == null) return CompletableFuture.completedFuture(ApiResult.error("unknown"));
        return http.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
                .thenApply(BackendClient::parse)
                .exceptionally(ex -> ApiResult.error("network_error"));
    }

    /** Signed POST that returns the JSON body when the backend answered 200 {"ok":true}, else null. */
    private CompletableFuture<JsonObject> postJson(String path, JsonObject body) {
        HttpRequest request = signedRequest(path, body);
        if (request == null) return CompletableFuture.completedFuture(null);
        return http.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
                .thenApply(response -> {
                    if (response.statusCode() != 200) return null;
                    try {
                        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                        boolean ok = json.has("ok") && json.get("ok").isJsonPrimitive() && json.get("ok").getAsBoolean();
                        return ok ? json : null;
                    } catch (Exception e) {
                        return null;
                    }
                })
                .exceptionally(ex -> null);
    }

    private HttpRequest signedRequest(String path, JsonObject body) {
        final String json = body.toString();
        final String timestamp = Long.toString(System.currentTimeMillis() / 1000L);
        final String nonce = randomHex(16);
        final String signature;
        try {
            signature = sign(timestamp + "\n" + nonce + "\n" + path + "\n" + json);
        } catch (Exception e) {
            return null;
        }

        try {
            return HttpRequest.newBuilder(URI.create(baseUrl + path))
                    .timeout(timeout)
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header("X-Kapom-Timestamp", timestamp)
                    .header("X-Kapom-Nonce", nonce)
                    .header("X-Kapom-Signature", signature)
                    .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                    .build();
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static ApiResult parse(HttpResponse<String> response) {
        int status = response.statusCode();
        String error = null;
        boolean ok = false;
        try {
            JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
            ok = json.has("ok") && json.get("ok").isJsonPrimitive() && json.get("ok").getAsBoolean();
            if (json.has("error") && json.get("error").isJsonPrimitive()) {
                error = json.get("error").getAsString();
            }
        } catch (Exception ignored) {
            // non-JSON body: fall through to status-based handling
        }
        if (status == 200 && ok) {
            return ApiResult.success();
        }
        if (error != null) {
            return ApiResult.error(error);
        }
        if (status == 429) return ApiResult.error("rate_limited");
        if (status >= 500) return ApiResult.error("server_error");
        return ApiResult.error("unknown");
    }

    private String sign(String data) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret, "HmacSHA256"));
        return HexFormat.of().formatHex(mac.doFinal(data.getBytes(StandardCharsets.UTF_8)));
    }

    private static String randomHex(int bytes) {
        byte[] b = new byte[bytes];
        RANDOM.nextBytes(b);
        return HexFormat.of().formatHex(b);
    }
}
