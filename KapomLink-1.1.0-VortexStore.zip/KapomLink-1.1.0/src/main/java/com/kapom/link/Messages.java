package com.kapom.link;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

/** Reads messages from config.yml (MiniMessage format). Only static config text is parsed, never player input. */
public final class Messages {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final FileConfiguration config;
    private final String prefix;

    public Messages(FileConfiguration config) {
        this.config = config;
        this.prefix = config.getString("messages.prefix", "");
    }

    public Component get(String key, Object... args) {
        String raw = config.getString("messages." + key, key);
        return MM.deserialize(prefix + format(raw, args));
    }

    public Component error(String code) {
        ConfigurationSection errors = config.getConfigurationSection("messages.errors");
        String raw = null;
        if (errors != null) {
            raw = errors.getString(code);
            if (raw == null) raw = errors.getString("unknown");
        }
        if (raw == null) raw = "<red>Something went wrong.</red>";
        return MM.deserialize(prefix + raw);
    }

    private static String format(String raw, Object... args) {
        if (args == null || args.length == 0) return raw;
        try {
            return String.format(raw, args);
        } catch (Exception e) {
            return raw;
        }
    }
}
