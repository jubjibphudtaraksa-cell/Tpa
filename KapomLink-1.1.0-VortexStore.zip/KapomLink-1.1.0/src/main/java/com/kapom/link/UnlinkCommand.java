package com.kapom.link;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** /unlink asks for confirmation; /unlink confirm (within the configured time) performs it. */
public final class UnlinkCommand implements CommandExecutor, TabCompleter {

    private final KapomLinkPlugin plugin;
    private final Map<UUID, Long> pending = new ConcurrentHashMap<>();
    private final Set<UUID> inFlight = ConcurrentHashMap.newKeySet();

    public UnlinkCommand(KapomLinkPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        Messages msg = plugin.messages();

        if (!(sender instanceof Player player)) {
            sender.sendMessage(msg.get("player-only"));
            return true;
        }
        final UUID uuid = player.getUniqueId();
        final boolean confirming = args.length == 1 && args[0].equalsIgnoreCase("confirm");

        if (!confirming) {
            pending.put(uuid, System.currentTimeMillis() + plugin.unlinkConfirmSeconds() * 1000L);
            player.sendMessage(msg.get("unlink-prompt", plugin.unlinkConfirmSeconds()));
            return true;
        }

        Long deadline = pending.remove(uuid);
        if (deadline == null || System.currentTimeMillis() > deadline) {
            player.sendMessage(msg.get("unlink-no-pending"));
            return true;
        }
        if (!inFlight.add(uuid)) {
            player.sendMessage(msg.get("busy"));
            return true;
        }

        plugin.backend().unlink(uuid).whenComplete((result, error) -> {
            ApiResult r = (error != null || result == null) ? ApiResult.error("network_error") : result;
            if (!plugin.isEnabled()) {
                inFlight.remove(uuid);
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                inFlight.remove(uuid);
                Player online = Bukkit.getPlayer(uuid);
                if (online == null) return;
                online.sendMessage(r.ok() ? plugin.messages().get("unlink-success")
                                          : plugin.messages().error(r.errorCode()));
            });
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1 && "confirm".startsWith(args[0].toLowerCase())) {
            return List.of("confirm");
        }
        return List.of();
    }

    public void forget(UUID uuid) {
        pending.remove(uuid);
    }
}
