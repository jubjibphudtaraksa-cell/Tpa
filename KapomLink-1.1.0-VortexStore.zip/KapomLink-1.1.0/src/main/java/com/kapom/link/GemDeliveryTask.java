package com.kapom.link;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

/**
 * Gives gems bought on the website.
 *
 * Every few seconds the plugin asks the website for pending gem orders (signed request),
 * runs the configured command (default: "gems give %player% %amount%") on the main thread,
 * then confirms each order back to the website so it is never given twice.
 *
 * Orders that were given in game but not yet confirmed are kept in gems-unconfirmed.txt,
 * so a crash or network error between "give" and "confirm" never gives the gems again.
 */
public final class GemDeliveryTask {

    private static final Pattern NAME_RE = Pattern.compile("^[A-Za-z0-9_.]{1,32}$");
    private static final int MAX_GEMS_PER_ORDER = 1_000_000;

    private final KapomLinkPlugin plugin;
    private final String commandTemplate;
    private final boolean requireOnline;
    private final int pollSeconds;
    private final Path unconfirmedFile;

    /** Order id -> player uuid: given in game, waiting for the website to confirm. */
    private final Map<Long, UUID> unconfirmed = new ConcurrentHashMap<>();
    /** Order ids currently being given, to avoid overlapping polls handling the same order. */
    private final Set<Long> inFlight = ConcurrentHashMap.newKeySet();
    private final AtomicBoolean polling = new AtomicBoolean(false);
    private BukkitTask task;

    public GemDeliveryTask(KapomLinkPlugin plugin, String commandTemplate, boolean requireOnline, int pollSeconds) {
        this.plugin = plugin;
        this.commandTemplate = commandTemplate;
        this.requireOnline = requireOnline;
        this.pollSeconds = pollSeconds;
        this.unconfirmedFile = plugin.getDataFolder().toPath().resolve("gems-unconfirmed.txt");
    }

    public void start() {
        loadUnconfirmed();
        long period = pollSeconds * 20L;
        task = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::poll, 100L, period);
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    /** Check right away (e.g. when a player joins). Safe to call from any thread. */
    public void pollSoon() {
        Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, this::poll, 40L);
    }

    private void poll() {
        if (!polling.compareAndSet(false, true)) return;
        try {
            confirmUnconfirmed();
            JsonArray deliveries = plugin.backend().pendingGems().join();
            if (deliveries == null) return;
            for (JsonElement el : deliveries) {
                if (el.isJsonObject()) handle(el.getAsJsonObject());
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Gem delivery poll failed: " + e.getClass().getSimpleName());
        } finally {
            polling.set(false);
        }
    }

    private void handle(JsonObject d) {
        final long id;
        final UUID uuid;
        final int gems;
        final String storedName;
        try {
            id = d.get("id").getAsLong();
            uuid = UUID.fromString(d.get("uuid").getAsString());
            gems = d.get("gems").getAsInt();
            storedName = d.has("username") ? d.get("username").getAsString() : "";
        } catch (Exception e) {
            return; // malformed entry: skip
        }
        if (id <= 0 || gems <= 0 || gems > MAX_GEMS_PER_ORDER) return;
        if (unconfirmed.containsKey(id) || !inFlight.add(id)) return;

        Bukkit.getScheduler().runTask(plugin, () -> {
            try {
                Player online = Bukkit.getPlayer(uuid);
                if (online == null && requireOnline) return; // wait until they join
                String name = online != null ? online.getName() : storedName;
                if (!NAME_RE.matcher(name).matches()) {
                    plugin.getLogger().warning("Gem order #" + id + " skipped: invalid player name.");
                    return;
                }
                String cmd = commandTemplate
                        .replace("%player%", name)
                        .replace("%amount%", Integer.toString(gems));
                if (cmd.startsWith("/")) cmd = cmd.substring(1);
                boolean ran = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
                if (!ran) {
                    plugin.getLogger().warning("Gem order #" + id + ": command failed, will retry.");
                    return;
                }
                unconfirmed.put(id, uuid);
                saveUnconfirmed();
                plugin.getLogger().info("Gem order #" + id + ": gave " + gems + " gems to " + name + ".");
                if (online != null) online.sendMessage(plugin.messages().get("gems-received", gems));
                Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> confirm(id, uuid));
            } finally {
                inFlight.remove(id);
            }
        });
    }

    private void confirmUnconfirmed() {
        for (Map.Entry<Long, UUID> e : new ArrayList<>(unconfirmed.entrySet())) {
            confirm(e.getKey(), e.getValue());
        }
    }

    private void confirm(long id, UUID uuid) {
        ApiResult r = plugin.backend().ackGems(id, uuid).join();
        // not_found = order no longer exists for this player; nothing left to confirm.
        if (r.ok() || "not_found".equals(r.errorCode())) {
            if (unconfirmed.remove(id) != null) saveUnconfirmed();
        }
    }

    private void loadUnconfirmed() {
        if (!Files.exists(unconfirmedFile)) return;
        try {
            for (String line : Files.readAllLines(unconfirmedFile, StandardCharsets.UTF_8)) {
                String[] parts = line.trim().split(" ");
                if (parts.length != 2) continue;
                try {
                    unconfirmed.put(Long.parseLong(parts[0]), UUID.fromString(parts[1]));
                } catch (IllegalArgumentException ignored) {
                    // skip bad line
                }
            }
        } catch (IOException e) {
            plugin.getLogger().warning("Could not read gems-unconfirmed.txt");
        }
    }

    private synchronized void saveUnconfirmed() {
        List<String> lines = new ArrayList<>();
        unconfirmed.forEach((id, uuid) -> lines.add(id + " " + uuid));
        try {
            Files.createDirectories(unconfirmedFile.getParent());
            Path tmp = unconfirmedFile.resolveSibling("gems-unconfirmed.txt.tmp");
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            Files.move(tmp, unconfirmedFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save gems-unconfirmed.txt");
        }
    }
}
