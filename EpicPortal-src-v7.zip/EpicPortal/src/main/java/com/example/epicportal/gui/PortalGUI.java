package com.example.epicportal.gui;

import com.example.epicportal.EpicPortal;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * GUI 54-slot (6 แถว) ที่แสดงบล็อกหญ้าตรงกลาง
 *
 * Layout (slot index):
 *  Row 1 [ 0- 8]: border (gray glass)
 *  Row 2 [ 9-17]: col 0,8 = border | col 1-7 = black glass
 *  Row 3 [18-26]: col 0,8 = border | 20=info | 22=GRASS | 24=SWORD | 31=action | rest = black glass
 *  Row 4 [27-35]: col 0,8 = border | col 1-7 = black glass
 *  Row 5 [36-44]: col 0,8 = border | col 1-7 = black glass
 *  Row 6 [45-53]: border (gray glass)
 */
public class PortalGUI implements InventoryHolder {

    // Slot constants
    public static final int SLOT_GRASS  = 22;   // บล็อกหญ้า (ตรงกลาง)
    public static final int SLOT_SWORD  = 24;   // ดาบ (วาปเข้าโลก LP ทันที)

    private final Inventory inventory;
    private final EpicPortal plugin;

    public PortalGUI(EpicPortal plugin, Player player) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, 54,
                Component.text("✦ Gateway — โลก SMP ✦")
                        .color(NamedTextColor.GOLD)
                        .decoration(TextDecoration.ITALIC, false));
        build(player);
    }

    // ── Build ────────────────────────────────────────────────────────────────

    private void build(Player player) {
        ItemStack black = pane(Material.BLACK_STAINED_GLASS_PANE);
        for (int i = 0; i < 54; i++) inventory.setItem(i, black);

        ItemStack gray = pane(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < 9; i++)  inventory.setItem(i, gray);
        for (int i = 45; i < 54; i++) inventory.setItem(i, gray);
        for (int r = 1; r <= 4; r++) {
            inventory.setItem(r * 9,     gray);
            inventory.setItem(r * 9 + 8, gray);
        }

        inventory.setItem(SLOT_GRASS, buildGrassItem());
        inventory.setItem(SLOT_SWORD, plugin.getSwordListener().createPortalSword());
    }

    private ItemStack buildGrassItem() {
        ItemStack item = new ItemStack(Material.GRASS_BLOCK);
        item.editMeta(meta -> {
            meta.displayName(Component.text("✦ เข้าสู่โลก SMP ✦")
                    .color(NamedTextColor.GREEN)
                    .decoration(TextDecoration.BOLD, true)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                    Component.empty(),
                    Component.text("► คลิกเพื่อวาปไปโลก SMP")
                            .color(NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false)));
        });
        return item;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** สร้าง stained glass pane ที่ไม่มีชื่อแสดง */
    private ItemStack pane(Material material) {
        ItemStack item = new ItemStack(material);
        item.editMeta(meta ->
            meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false)));
        return item;
    }

    @Override
    public Inventory getInventory() { return inventory; }
}
