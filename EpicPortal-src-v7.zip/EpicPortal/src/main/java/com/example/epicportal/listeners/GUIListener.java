package com.example.epicportal.listeners;

import com.example.epicportal.EpicPortal;
import com.example.epicportal.gui.PortalGUI;
import com.example.epicportal.managers.QueueManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public class GUIListener implements Listener {

    private final EpicPortal plugin;

    public GUIListener(EpicPortal plugin) {
        this.plugin = plugin;
    }

    /** จัดการการคลิก slot ใน Portal GUI */
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        // ตรวจสอบว่าเปิด Portal GUI อยู่
        if (!(event.getInventory().getHolder() instanceof PortalGUI)) return;

        // ยกเลิกเสมอ (ป้องกันการหยิบ item)
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;

        // ถ้าคลิก inventory ของผู้เล่นเอง (ส่วนล่าง) ให้ข้าม
        if (event.getClickedInventory() == null) return;
        if (!event.getClickedInventory().equals(event.getInventory())) return;

        int slot = event.getSlot();
        if (slot == PortalGUI.SLOT_GRASS) {
            player.closeInventory();
            plugin.teleportTo(player, QueueManager.TARGET_SMP);
        } else if (slot == PortalGUI.SLOT_SWORD) {
            player.closeInventory();
            plugin.teleportTo(player, QueueManager.TARGET_LP);
        }
    }

    /** ป้องกันการลากของเข้า Portal GUI */
    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getInventory().getHolder() instanceof PortalGUI)) return;
        event.setCancelled(true);
    }
}
