package com.example.epicportal.managers;

import com.example.epicportal.EpicPortal;

/** ชื่อปลายทาง/โลก: "smp" -> โลก SMP, "lp" -> โลก LP (PVP) — ไม่มีระบบคิวแล้ว วาปทันที */
public class QueueManager {

    public static final String TARGET_SMP = "smp";
    public static final String TARGET_LP  = "lp";

    private final EpicPortal plugin;

    public QueueManager(EpicPortal plugin) {
        this.plugin = plugin;
    }

    public String getWorldName(String target) {
        return plugin.getConfig().getString("worlds." + target,
                TARGET_LP.equals(target) ? "lp" : "world");
    }

    public String getDisplayName(String target) {
        return TARGET_LP.equals(target) ? "PVP" : "SMP";
    }
}
