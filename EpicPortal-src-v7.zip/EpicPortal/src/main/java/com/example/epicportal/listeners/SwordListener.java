package com.example.epicportal.listeners;

import com.example.epicportal.EpicPortal;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/** ดาบวาป: อยู่ในเมนูเข็มทิศ — คลิกแล้ววาปเข้าโลก lp ทันที */
public class SwordListener implements Listener {

    private final EpicPortal plugin;
    private final NamespacedKey swordKey;

    public SwordListener(EpicPortal plugin) {
        this.plugin = plugin;
        this.swordKey = new NamespacedKey(plugin, "portal_sword");
    }

    // ดาบอยู่ในเมนูเข็มทิศเท่านั้น — ไม่แจกในช่องอีกแล้ว และเก็บกวาดดาบเก่าที่ค้างอยู่

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        removeSword(event.getPlayer());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        removeSword(event.getPlayer());
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private boolean isEpicWorld(World world) {
        if (world == null) return false;
        return world.getName().equalsIgnoreCase(plugin.getConfig().getString("worlds.epic", "EPIC"));
    }

    public void removeSword(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isPortalSword(contents[i])) player.getInventory().setItem(i, null);
        }
    }

    public ItemStack createPortalSword() {
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        sword.editMeta(meta -> {
            meta.displayName(Component.text("⚔ ดาบวาป LP ⚔")
                    .color(NamedTextColor.RED)
                    .decoration(TextDecoration.BOLD, true)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(
                    Component.text("คลิกขวาเพื่อวาปเข้าโลก LP")
                            .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                    Component.text("เฉพาะโลก EPIC เท่านั้น")
                            .color(NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)));
            meta.setUnbreakable(true);
            meta.getPersistentDataContainer().set(swordKey, PersistentDataType.BOOLEAN, true);
        });
        return sword;
    }

    public boolean isPortalSword(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_SWORD || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(swordKey, PersistentDataType.BOOLEAN);
    }
}
