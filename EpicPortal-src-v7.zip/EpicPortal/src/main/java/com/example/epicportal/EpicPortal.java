package com.example.epicportal;

import com.example.epicportal.listeners.CompassListener;
import com.example.epicportal.listeners.GUIListener;
import com.example.epicportal.listeners.NpcListener;
import com.example.epicportal.listeners.ProtectionListener;
import com.example.epicportal.listeners.SwordListener;
import com.example.epicportal.managers.QueueManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public final class EpicPortal extends JavaPlugin {

    private static EpicPortal instance;
    private QueueManager queueManager;
    private CompassListener compassListener;
    private SwordListener swordListener;
    private ProtectionListener protectionListener;
    private NpcListener npcListener;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        queueManager = new QueueManager(this);
        compassListener = new CompassListener(this);

        swordListener = new SwordListener(this);

        protectionListener = new ProtectionListener(this);
        getServer().getPluginManager().registerEvents(compassListener, this);
        getServer().getPluginManager().registerEvents(protectionListener, this);
        getServer().getPluginManager().registerEvents(swordListener, this);
        npcListener = new NpcListener(this);
        getServer().getPluginManager().registerEvents(npcListener, this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);

        // /epicnpc command
        Objects.requireNonNull(getCommand("epicnpc")).setExecutor(this::cmdNpc);
        Objects.requireNonNull(getCommand("epicgive")).setExecutor(this::cmdGive);

        protectionListener.start();

        getLogger().info("EpicPortal enabled! EPIC=" + getConfig().getString("worlds.epic", "EPIC")
                + " -> SMP=" + getConfig().getString("worlds.smp", "world"));
    }

    @Override
    public void onDisable() {
        getLogger().info("EpicPortal disabled.");
    }

    // ── Commands ────────────────────────────────────────────────────────────

    /** /epicnpc <smp|pvp|remove> — สร้าง/ลบบอท (Mannequin ของ Minecraft ไม่ต้องใช้ Citizens) */
    private boolean cmdNpc(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command."));
            return true;
        }
        if (!player.hasPermission("epicportal.admin")) {
            player.sendMessage(Component.text("✘ คุณไม่มีสิทธิ์").color(NamedTextColor.RED));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(Component.text("ใช้: /epicnpc <smp|pvp|remove>").color(NamedTextColor.YELLOW));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "smp" -> createBot(player, QueueManager.TARGET_SMP);
            case "pvp", "lp" -> createBot(player, QueueManager.TARGET_LP);
            case "remove" -> {
                int n = npcListener.removeNearby(player, 5.0);
                player.sendMessage(n > 0
                        ? Component.text("✔ ลบบอท " + n + " ตัวแล้ว").color(NamedTextColor.GREEN)
                        : Component.text("ไม่พบบอทในระยะ 5 บล็อก").color(NamedTextColor.GRAY));
            }
            default -> player.sendMessage(Component.text("ใช้: /epicnpc <smp|pvp|remove>").color(NamedTextColor.YELLOW));
        }
        return true;
    }

    /** /epicgive [player] — แจกเข็มทิศ + ดาบวาป (ใช้เทสต์ได้ทุกโลก) */
    private boolean cmdGive(CommandSender sender, Command cmd, String label, String[] args) {
        Player target = args.length > 0 ? getServer().getPlayerExact(args[0])
                : (sender instanceof Player p ? p : null);
        if (target == null) {
            sender.sendMessage(Component.text("ใช้: /epicgive [ผู้เล่น]").color(NamedTextColor.YELLOW));
            return true;
        }
        compassListener.giveCompassIfMissing(target);
        sender.sendMessage(Component.text("✔ แจกเข็มทิศให้ " + target.getName() + " แล้ว").color(NamedTextColor.GREEN));
        return true;
    }

    private void createBot(Player player, String target) {
        String skin = getConfig().getString("npc.skins." + target,
                QueueManager.TARGET_LP.equals(target) ? "jeb_" : "Notch");
        npcListener.spawnBot(player, target, skin, ok -> player.sendMessage(ok
                ? Component.text("✔ สร้างบอท " + target.toUpperCase() + " แล้ว (สกิน " + skin + ")")
                        .color(NamedTextColor.GREEN)
                : Component.text("✘ สร้างบอทไม่สำเร็จ — ดูข้อความ error ในคอนโซลเซิร์ฟเวอร์")
                        .color(NamedTextColor.RED)));
    }

    /** วาปผู้เล่นไปโลกปลายทางทันที (smp หรือ lp) */
    public void teleportTo(Player player, String target) {
        QueueManager qm = getQueueManager();
        String name = qm.getDisplayName(target);
        String worldName = qm.getWorldName(target);
        World world = getServer().getWorld(worldName);

        if (world == null) {
            player.sendMessage(Component.text("✘ ไม่พบโลก " + worldName).color(NamedTextColor.RED));
            return;
        }
        if (player.getWorld().equals(world)) {
            player.sendMessage(Component.text("✔ คุณอยู่ในโลก " + name + " แล้ว!").color(NamedTextColor.GREEN));
            return;
        }
        player.sendMessage(Component.text("✈ กำลังพาคุณไปยังโลก " + name + "...").color(NamedTextColor.GREEN));
        player.teleport(world.getSpawnLocation());
    }

    // ── Getters ─────────────────────────────────────────────────────────────

    public static EpicPortal getInstance() { return instance; }
    public QueueManager getQueueManager() { return queueManager; }
    public SwordListener getSwordListener() { return swordListener; }
    public ProtectionListener getProtectionListener() { return protectionListener; }
    public CompassListener getCompassListener() { return compassListener; }
}
